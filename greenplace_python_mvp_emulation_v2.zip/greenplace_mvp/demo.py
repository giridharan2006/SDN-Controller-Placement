#!/usr/bin/env python3
"""Convenience entry point at the project root — run this to see everything.

Equivalent to `python scripts/run_all_demos.py`, just easier to find when
browsing the project for the first time.

Usage:
    python demo.py            # full run (~2-3 minutes)
    python demo.py --quick     # fast pass for a live demo (~30-60s)
"""
import subprocess
import sys
from pathlib import Path

if __name__ == "__main__":
    script = Path(__file__).resolve().parent / "scripts" / "run_all_demos.py"
    sys.exit(subprocess.call([sys.executable, str(script), *sys.argv[1:]]))
