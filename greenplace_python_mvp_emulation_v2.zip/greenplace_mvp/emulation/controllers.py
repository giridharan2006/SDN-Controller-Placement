"""Life cycle of the Ryu controller processes: start (wake), health checks, stop (sleep).

Each GreenPlace controller is a separate `ryu-manager` process with its own OpenFlow port on 127.0.0.1.
A controller is *ready* when its process is alive, its OpenFlow port accepts TCP connections and the app has
written a heartbeat. Health = alive + port open + fresh heartbeat.
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import socket
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

APP = Path(__file__).resolve().parent / "ryu_app" / "gp_controller.py"


def find_ryu_manager(explicit: str | None = None) -> str | None:
    """Explicit path > $GREENPLACE_RYU_MANAGER > ~/.venvs/greenplace-ryu/bin/ryu-manager > PATH."""
    cands = [explicit, os.environ.get("GREENPLACE_RYU_MANAGER"),
             str(Path.home() / ".venvs" / "greenplace-ryu" / "bin" / "ryu-manager"),
             shutil.which("ryu-manager")]
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:  # running under sudo: also look in the invoking user's home
        cands.insert(3, f"/home/{sudo_user}/.venvs/greenplace-ryu/bin/ryu-manager")
    for c in cands:
        if c and Path(c).is_file() and os.access(c, os.X_OK):
            return c
    return None


def port_open(port: int, host: str = "127.0.0.1", timeout: float = 0.05) -> bool:
    with socket.socket() as s:
        s.settimeout(timeout)
        return s.connect_ex((host, port)) == 0


def last_heartbeat(events_path: Path, label: str) -> float | None:
    """Timestamp of the newest heartbeat of controller `label` (reads the tail of the shared events file)."""
    try:
        with open(events_path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - 65536))
            lines = fh.read().decode(errors="ignore").splitlines()
    except FileNotFoundError:
        return None
    for line in reversed(lines):
        if '"heartbeat"' in line and f'"ctrl": "{label}"' in line:
            try:
                return json.loads(line)["ts"]
            except (ValueError, KeyError):
                continue
    return None


@dataclass
class ControllerProc:
    node: int
    port: int
    proc: subprocess.Popen
    t_start: float
    t_ready: float | None = None


@dataclass
class ControllerManager:
    run_dir: Path
    routes: dict
    ryu_manager: str
    base_port: int = 6653
    idle_timeout: int = 5
    hard_timeout: int = 15
    ready_timeout_s: float = 30.0
    stop_timeout_s: float = 5.0
    procs: dict = field(default_factory=dict)
    ports: dict = field(default_factory=dict)
    log: list = field(default_factory=list)     # lifecycle records -> controllers_lifecycle.csv

    @property
    def events_path(self) -> Path:
        return self.run_dir / "controller_events.jsonl"

    def assign_ports(self, pool):
        for i, c in enumerate(sorted(pool)):
            self.ports[int(c)] = self.base_port + i

    def start(self, node: int) -> float:
        """Wake controller `node`. Returns seconds from process start to ready; raises if not ready in time."""
        node = int(node)
        if node in self.procs:
            return 0.0
        port = self.ports[node]
        if port_open(port):
            raise RuntimeError(f"port {port} already in use; is an old controller still running? (try: sudo mn -c)")
        cfg_path = self.run_dir / f"ctrl_{node}.json"
        cfg_path.write_text(json.dumps({"label": str(node), "events_path": str(self.events_path),
                                        "routes": self.routes, "idle_timeout": self.idle_timeout,
                                        "hard_timeout": self.hard_timeout, "heartbeat_s": 0.5}))
        env = dict(os.environ, GP_EMU_CONFIG=str(cfg_path))
        logf = open(self.run_dir / f"ryu_{node}.log", "a")
        t0 = time.time()
        proc = subprocess.Popen([self.ryu_manager, "--ofp-listen-host", "127.0.0.1", "--ofp-tcp-listen-port",
                                 str(port), str(APP)], env=env, stdout=logf, stderr=subprocess.STDOUT,
                                start_new_session=True)
        cp = ControllerProc(node, port, proc, t0)
        self.procs[node] = cp
        t_port = None
        while time.time() - t0 < self.ready_timeout_s:
            if proc.poll() is not None:
                break
            if t_port is None and port_open(port):
                t_port = time.time()
            hb = last_heartbeat(self.events_path, str(node))
            if t_port is not None and hb is not None and hb >= t0:
                cp.t_ready = time.time()
                break
            time.sleep(0.01)
        if cp.t_ready is None:
            code = proc.poll()
            self.stop(node, reason="failed_start")
            raise RuntimeError(f"controller {node} not ready after {self.ready_timeout_s}s (exit code {code}); "
                               f"see {self.run_dir}/ryu_{node}.log")
        self.log.append({"event": "wake", "controller": node, "port": port, "pid": proc.pid, "t": t0,
                         "port_open_s": round(t_port - t0, 4), "ready_s": round(cp.t_ready - t0, 4)})
        return cp.t_ready - t0

    def stop(self, node: int, reason: str = "sleep") -> float:
        """Put controller `node` to sleep: SIGTERM, then SIGKILL after stop_timeout_s. Returns seconds taken."""
        cp = self.procs.pop(int(node), None)
        if cp is None:
            return 0.0
        t0 = time.time()
        forced = False
        if cp.proc.poll() is None:
            try:
                os.killpg(cp.proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                cp.proc.wait(timeout=self.stop_timeout_s)
            except subprocess.TimeoutExpired:
                forced = True
                os.killpg(cp.proc.pid, signal.SIGKILL)
                cp.proc.wait(timeout=5)
        dt = time.time() - t0
        self.log.append({"event": reason, "controller": int(node), "port": cp.port, "pid": cp.proc.pid, "t": t0,
                         "stop_s": round(dt, 4), "forced_kill": forced, "exit_code": cp.proc.returncode})
        return dt

    def health(self, node: int, max_heartbeat_age_s: float = 3.0) -> dict:
        cp = self.procs.get(int(node))
        if cp is None:
            return {"controller": int(node), "alive": False, "port_open": False, "heartbeat_age_s": None, "healthy": False}
        alive = cp.proc.poll() is None
        po = port_open(cp.port)
        hb = last_heartbeat(self.events_path, str(node))
        age = None if hb is None else time.time() - hb
        return {"controller": int(node), "alive": alive, "port_open": po,
                "heartbeat_age_s": None if age is None else round(age, 3),
                "healthy": alive and po and age is not None and age <= max_heartbeat_age_s}

    def pids(self) -> dict:
        return {n: cp.proc.pid for n, cp in self.procs.items()}

    def stop_all(self):
        for n in list(self.procs):
            self.stop(n, reason="teardown")
