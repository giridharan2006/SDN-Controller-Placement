#!/bin/sh
# Start Open vSwitch WITHOUT systemd and without the kernel module (containers / CI / VMs without openvswitch.ko).
# Switches must then use the userspace datapath (the runner picks it automatically: --datapath auto).
# On a normal Ubuntu desktop do NOT use this; use: sudo systemctl start openvswitch-switch
set -e
RUN=/var/run/openvswitch; DB=/etc/openvswitch/conf.db
mkdir -p "$RUN" /etc/openvswitch /var/log/openvswitch
[ -f "$DB" ] || ovsdb-tool create "$DB" /usr/share/openvswitch/vswitch.ovsschema
if ! ovs-vsctl --timeout=2 show >/dev/null 2>&1; then
  ovsdb-server "$DB" --remote=punix:$RUN/db.sock --remote=db:Open_vSwitch,Open_vSwitch,manager_options \
      --pidfile=$RUN/ovsdb-server.pid --detach --log-file=/var/log/openvswitch/ovsdb-server.log
  ovs-vsctl --no-wait init
  ovs-vswitchd --pidfile=$RUN/ovs-vswitchd.pid --detach --log-file=/var/log/openvswitch/ovs-vswitchd.log
fi
ovs-vsctl --timeout=5 show >/dev/null && echo "Open vSwitch running: $(ovs-vsctl --version | head -1)"
