"""Pool the runs of one emulation session into RESULTS.md + pooled_results.csv/json (no root needed).

    python -m emulation.report outputs/emulation/<session>
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from . import analysis as A


def _f(x, nd=1):
    return "–" if x is None else f"{x:.{nd}f}"


def pool(session: Path) -> list[dict]:
    groups: dict = {}
    for sj in sorted(session.glob("*/summary.json")):
        s = json.loads(sj.read_text())
        d = sj.parent
        g = groups.setdefault((s["topology"], s["handover_mode"]), {"runs": [], "ho": [], "bursts": [], "streams": [],
                                                                     "wake": [], "sleep": [], "probes": [], "res": []})
        g["runs"].append(s)
        g["ho"] += [h for h in A.read_csv(d / "handovers.csv") if h["initial"] == "False"]
        g["bursts"] += A.read_csv(d / "bursts.csv")
        g["streams"] += s["established_streams"]["streams"]
        lc = A.read_csv(d / "controllers_lifecycle.csv")
        n0 = len(json.loads((d / "plan.json").read_text())["steps"][0]["active"])   # initial starts are not wakes
        wakes = [r for r in lc if r["event"] == "wake"]
        g["wake"] += [float(r["ready_s"]) for r in wakes[n0:]]
        g["sleep"] += [float(r["stop_s"]) for r in lc if r["event"] == "sleep"]
        g["probes"] += A.read_csv(d / "probes.csv")
        g["res"].append(s["resources"])
    out = []
    for (topo, mode), g in sorted(groups.items()):
        runs = g["runs"]
        num = lambda v: None if v in ("", "None", None) else float(v)  # noqa: E731
        bph = {}
        for ph in ("before", "during", "after"):
            pk = [{"lost": b["lost"] == "True", "latency_ms": num(b["latency_ms"])} for b in g["bursts"]
                  if b["phase"] == ph]
            bph[ph] = A.loss_latency(pk)
        bg = {}
        for c in ("baseline", "affected"):
            pk = [{"lost": p["lost"] == "True", "latency_ms": num(p["latency_ms"])} for p in g["probes"] if p["cls"] == c]
            bg[c] = A.loss_latency(pk)
        ctrl_cpu = [v["cpu_mean"] for r in g["res"] for k, v in r.items() if k.startswith("controller:")]
        ctrl_cpu_ev = [v["cpu_mean_in_windows"] for r in g["res"] for k, v in r.items()
                       if k.startswith("controller:") and v["cpu_mean_in_windows"] is not None]
        ctrl_peak = [v["cpu_peak"] for r in g["res"] for k, v in r.items() if k.startswith("controller:")]
        ctrl_rss = [v["rss_mb_peak"] for r in g["res"] for k, v in r.items() if k.startswith("controller:")]
        ovs_cpu = [v["cpu_mean"] for r in g["res"] for k, v in r.items() if k.startswith("ovs:")]
        handovers_with_loss = sum(r["handover_bursts"]["handovers_with_burst_loss"] for r in runs)
        out.append({
            "topology": topo, "mode": mode, "runs": len(runs), "traces": " ".join(r["trace"] for r in runs),
            "reassign_scheduled": sum(r["schedule"]["reassignments"] for r in runs),
            "reassign_executed": sum(r["executed"]["reassignments"] for r in runs),
            "reassign_ready": sum(r["executed"]["reassignments_ready"] for r in runs),
            "sim_migrations": sum(r["simulation_reference"]["migrations"] for r in runs),
            "wakes": sum(r["executed"]["wakes"] for r in runs), "sleeps": sum(r["executed"]["sleeps"] for r in runs),
            "steps_verified": sum(r["executed"]["steps_verified"] for r in runs),
            "steps": sum(r["executed"]["steps"] for r in runs),
            "unhealthy_checks": sum(r["executed"]["unhealthy_checks"] for r in runs),
            "failures": sum(len(r["executed"]["failures"]) for r in runs),
            "handshake_ms": A.stats([num(h["handshake_ms"]) for h in g["ho"]]),
            "ready_ms": A.stats([num(h["ready_ms"]) for h in g["ho"]]),
            "old_closed_ms": A.stats([num(h["old_down_ms"]) for h in g["ho"]]),
            "wake_s": A.stats(g["wake"], nd=3), "sleep_ms": A.stats(g["sleep"], scale=1000),
            "burst": bph, "handovers_with_burst_loss": handovers_with_loss,
            "probes": bg,
            "stream_sent": sum(x["sent"] for x in g["streams"]), "stream_lost": sum(x["lost"] for x in g["streams"]),
            "stream_lost_in_windows": sum(x["lost_in_windows"] for x in g["streams"]),
            "stream_max_gap_ms": max((x["max_gap_ms"] or 0) for x in g["streams"]) if g["streams"] else None,
            "controller_cpu_mean": A.stats(ctrl_cpu), "controller_cpu_event_mean": A.stats(ctrl_cpu_ev),
            "controller_cpu_peak": max(ctrl_peak) if ctrl_peak else None,
            "controller_rss_peak_mb": max(ctrl_rss) if ctrl_rss else None,
            "ovs_cpu_mean": A.stats(ovs_cpu),
            "power": runs[0]["power"], "environment": runs[0]["environment"],
        })
    return out


def _gap_section(session: Path) -> list[str]:
    """Decomposition of established-stream pauses > 50 ms (emulation.stream_gaps)."""
    from .stream_gaps import run_gaps
    rows = []
    for d in sorted(p.parent for p in session.glob("*/streams.csv")):
        rows += run_gaps(d)
    if not rows:
        return ["", "No established-stream pause above 50 ms."]
    near = [r for r in rows if r["on_path_handover"]]
    sender = [r for r in rows if r["send_gap_ms"] is not None and r["send_gap_ms"] >= 40]
    transit = [r for r in rows if r["send_gap_ms"] is not None and r["send_gap_ms"] < 40]
    ex = [r["network_excess_ms"] for r in transit]
    nr = len({r["run"] for r in rows})
    nn = len({r["run"] for r in near})
    transit_txt = (f"{len(transit)} were delays in transit of {_f(min(ex))}–{_f(max(ex))} ms" if transit
                   else "none was a delay in transit")
    near_txt = (f"{len(near)} overlapped a hand-over of a switch on the stream's path ({nn} run{'s' * (nn != 1)}, "
                f"longest {_f(max(r['recv_gap_ms'] for r in near))} ms)" if near
                else "none overlapped a hand-over of a switch on the stream's path")
    return ["", "Established-stream pauses above 50 ms (`python -m emulation.stream_gaps`, details in "
            f"`stream_gaps.csv`): {len(rows)} pause{'s' * (len(rows) != 1)} in {nr} run{'s' * (nr != 1)}; "
            f"{len(sender)} started at the sender (the send timestamps show the same pause); {transit_txt}; "
            f"{near_txt}; packets lost inside pauses: {sum(r['lost_in_gap'] for r in rows)}."]


def markdown(rows: list[dict], session: Path) -> str:
    env = rows[0]["environment"] if rows else {}
    L = [f"# GreenPlace emulation results — session `{session.name}`", "",
         "**Measurement class: Mininet emulation** (software OpenFlow switches and Ryu controller processes on one "
         "host). These are not simulator outputs and not physical-hardware measurements.", "",
         f"Environment: kernel {env.get('kernel')}, {env.get('cpus')} vCPU ({env.get('cpu_model')}), "
         f"virtualization `{env.get('virtualization')}`, Mininet {env.get('mininet')}, {env.get('ovs')}, "
         f"{env.get('ryu')}, OVS datapath **{env.get('datapath')}**, link delays emulated: "
         f"**{env.get('link_delay_emulated')}**, control channel: {env.get('control_channel')}.", "",
         "## 1. Did the GreenPlace schedule execute?", "",
         "| Network | Mode | Runs (traces) | Reassignments executed / ready / scheduled (simulator) | Wakes / sleeps | "
         "Steps verified | Unhealthy checks | Failures |", "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r['topology']} | {r['mode']} | {r['runs']} ({r['traces']}) | {r['reassign_executed']} / "
                 f"{r['reassign_ready']} / {r['reassign_scheduled']} ({r['sim_migrations']:.0f}) | {r['wakes']} / "
                 f"{r['sleeps']} | {r['steps_verified']}/{r['steps']} | {r['unhealthy_checks']} | {r['failures']} |")
    L += ["", "## 2. Switch migration latency (ms, from the reassignment command)", "",
          "| Network | Mode | n | OpenFlow handshake median [p95, max] | Ready (table-miss + barrier) median [p95, max] | "
          "Old session closed median | Controller wake (s) median [max] | Controller sleep (ms) median |",
          "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        h, rd, o, w, s = r["handshake_ms"], r["ready_ms"], r["old_closed_ms"], r["wake_s"], r["sleep_ms"]
        L.append(f"| {r['topology']} | {r['mode']} | {h['n']} | {_f(h['median'])} [{_f(h['p95'])}, {_f(h['max'])}] | "
                 f"{_f(rd['median'])} [{_f(rd['p95'])}, {_f(rd['max'])}] | {_f(o['median'])} | "
                 f"{_f(w['median'], 3)} [{_f(w['max'], 3)}] | {_f(s['median'], 1)} |")
    L += ["", "## 3. Flow-setup disruption and packet loss", "",
          "New-flow bursts through each migrating switch (every packet is a new 5-tuple that needs a controller "
          "decision); phase is relative to that switch's own hand-over: before = sent before the command, during = "
          "command to new controller ready (+50 ms), after = later.", "",
          "| Network | Mode | Before: n / loss % / setup median ms | During: n / loss % / setup median [max] ms | "
          "After: n / loss % / setup median ms | Hand-overs with ≥1 lost burst packet |",
          "|---|---|---|---|---|---|"]
    for r in rows:
        b = r["burst"]
        L.append(f"| {r['topology']} | {r['mode']} | {b['before']['packets']} / {_f(b['before']['loss_pct'], 2)} / "
                 f"{_f(b['before']['latency_ms']['median'])} | {b['during']['packets']} / "
                 f"{_f(b['during']['loss_pct'], 2)} / {_f(b['during']['latency_ms']['median'])} "
                 f"[{_f(b['during']['latency_ms']['max'])}] | {b['after']['packets']} / {_f(b['after']['loss_pct'], 2)}"
                 f" / {_f(b['after']['latency_ms']['median'])} | {r['handovers_with_burst_loss']} / "
                 f"{r['reassign_executed']} |")
    L += ["", "Background new-flow probes (5/s per host, all host pairs) and established UDP streams "
              "(100 pkt/s, paths through the most-migrated switches):", "",
          "| Network | Mode | Baseline probes: n / loss % / setup median ms | Probes inside a window: n / loss % | "
          "Stream packets sent / lost / lost inside windows | Longest stream gap, whole run, any cause (ms) |", "|---|---|---|---|---|---|"]
    for r in rows:
        p = r["probes"]
        L.append(f"| {r['topology']} | {r['mode']} | {p['baseline']['packets']} / {_f(p['baseline']['loss_pct'], 2)} / "
                 f"{_f(p['baseline']['latency_ms']['median'])} | {p['affected']['packets']} / "
                 f"{_f(p['affected']['loss_pct'], 1)} | {r['stream_sent']} / {r['stream_lost']} / "
                 f"{r['stream_lost_in_windows']} | {_f(r['stream_max_gap_ms'])} |")
    L += _gap_section(session)
    L += ["", "## 4. Controller CPU and memory (psutil; % of one core)", "",
          "| Network | Mode | Controller CPU mean of process means [max] | Mean in the 1 s after an action | "
          "Peak sample | Peak RSS (MB) | ovs-vswitchd CPU mean |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        c, ce = r["controller_cpu_mean"], r["controller_cpu_event_mean"]
        L.append(f"| {r['topology']} | {r['mode']} | {_f(c['median'])} [{_f(c['max'])}] | {_f(ce['median'])} | "
                 f"{_f(r['controller_cpu_peak'])} | {_f(r['controller_rss_peak_mb'])} | "
                 f"{_f(r['ovs_cpu_mean']['median'])} |")
    pw = rows[0]["power"] if rows else {}
    L += ["", "## 5. Power", "",
          ("RAPL package power was measured (whole host, not per controller): see summary.json files."
           if pw.get("available") else f"**Not measured.** {pw.get('reason', '')}. No power figure is reported "
                                       "or estimated from these runs."), ""]
    return "\n".join(L)


def main(argv=None):
    session = Path((argv or sys.argv[1:])[0])
    rows = pool(session)
    (session / "pooled_results.json").write_text(json.dumps(rows, indent=1, default=str))
    flat = []
    for r in rows:
        flat.append({"topology": r["topology"], "mode": r["mode"], "runs": r["runs"],
                     "reassign_executed": r["reassign_executed"], "reassign_ready": r["reassign_ready"],
                     "steps_verified": f"{r['steps_verified']}/{r['steps']}",
                     "handshake_ms_median": r["handshake_ms"]["median"], "handshake_ms_p95": r["handshake_ms"]["p95"],
                     "ready_ms_median": r["ready_ms"]["median"], "ready_ms_p95": r["ready_ms"]["p95"],
                     "ready_ms_max": r["ready_ms"]["max"], "wake_s_median": r["wake_s"]["median"],
                     "burst_before_loss_pct": r["burst"]["before"]["loss_pct"],
                     "burst_during_n": r["burst"]["during"]["packets"],
                     "burst_during_loss_pct": r["burst"]["during"]["loss_pct"],
                     "burst_during_setup_ms_median": r["burst"]["during"]["latency_ms"]["median"],
                     "burst_after_loss_pct": r["burst"]["after"]["loss_pct"],
                     "baseline_setup_ms_median": r["probes"]["baseline"]["latency_ms"]["median"],
                     "stream_lost": r["stream_lost"], "controller_cpu_mean_median": r["controller_cpu_mean"]["median"],
                     "controller_rss_peak_mb": r["controller_rss_peak_mb"], "power_measured": r["power"]["available"]})
    A.write_csv(session / "pooled_results.csv", flat)
    (session / "RESULTS.md").write_text(markdown(rows, session))
    print((session / "RESULTS.md").read_text())


if __name__ == "__main__":
    main()
