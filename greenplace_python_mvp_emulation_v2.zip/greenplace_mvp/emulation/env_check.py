"""Check what the emulation needs and say exactly what is missing.

    python -m emulation.env_check            (as a normal user: reports; some checks need root)
    sudo python3 -m emulation.env_check
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from .controllers import find_ryu_manager
from .monitor import rapl_status


def _run(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr).strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)


def netem_available() -> tuple[bool, str]:
    """Try to attach a netem qdisc to a throw-away dummy/veth device (root only)."""
    if os.geteuid() != 0:
        return False, "unknown (needs root to test)"
    if shutil.which("tc") is None or shutil.which("ip") is None:
        return False, "iproute2 (ip/tc) not installed"
    _run(["ip", "link", "del", "gpnetem0"])
    rc, out = _run(["ip", "link", "add", "gpnetem0", "type", "veth", "peer", "name", "gpnetem1"])
    if rc != 0:
        return False, f"cannot create veth: {out}"
    rc, out = _run(["tc", "qdisc", "add", "dev", "gpnetem0", "root", "netem", "delay", "1ms"])
    _run(["ip", "link", "del", "gpnetem0"])
    return (rc == 0), ("ok" if rc == 0 else f"netem qdisc unavailable ({out}); link delays cannot be emulated. "
                                             "On Ubuntu: sudo apt install linux-modules-extra-$(uname -r); sudo modprobe sch_netem")


def ovs_status() -> dict:
    if shutil.which("ovs-vsctl") is None:
        return {"ok": False, "detail": "ovs-vsctl not found (sudo apt install openvswitch-switch)"}
    rc, out = _run(["ovs-vsctl", "--timeout=3", "show"])
    if rc != 0:
        return {"ok": False, "detail": f"ovsdb/ovs-vswitchd not reachable: {out}. Start it: sudo systemctl start "
                                       "openvswitch-switch (or emulation/start_ovs_userspace.sh in a container)"}
    _, ver = _run(["ovs-vsctl", "--version"])
    kmod = Path("/sys/module/openvswitch").exists()
    return {"ok": True, "version": ver.splitlines()[0] if ver else "?", "kernel_module": kmod,
            "datapath": "kernel" if kmod else "user (netdev; kernel module not loaded)"}


def check() -> dict:
    res = {"python": sys.version.split()[0], "kernel": platform.release(), "root": os.geteuid() == 0}
    try:
        import mininet.net  # noqa: F401
        from mininet.net import VERSION
        res["mininet"] = {"ok": True, "version": VERSION}
    except Exception as e:  # noqa: BLE001
        res["mininet"] = {"ok": False, "detail": f"python3 cannot import mininet ({e}); sudo apt install mininet"}
    res["ovs"] = ovs_status()
    res["ethtool"] = {"ok": shutil.which("ethtool") is not None,
                      "detail": "needed to disable checksum offload on host interfaces (sudo apt install ethtool)"}
    rm = find_ryu_manager()
    if rm:
        rc, out = _run([rm, "--version"])
        res["ryu"] = {"ok": rc == 0, "path": rm, "version": out.splitlines()[-1] if out else "?"}
    else:
        res["ryu"] = {"ok": False, "detail": "ryu-manager not found; see emulation/README.md (isolated Python 3.9 venv)"}
    ok, why = netem_available()
    res["netem"] = {"ok": ok, "detail": why}
    res["rapl"] = rapl_status()
    rc, virt = _run(["systemd-detect-virt"])
    res["virtualization"] = virt if virt else "unknown"
    res["ready"] = bool(res["root"] and res["mininet"]["ok"] and res["ovs"]["ok"] and res["ryu"]["ok"]
                        and res["ethtool"]["ok"])
    return res


if __name__ == "__main__":
    r = check()
    print(json.dumps(r, indent=1))
    if not r["ready"]:
        print("\nNOT READY:", "; ".join(k for k in ("root", "mininet", "ovs", "ryu", "ethtool")
                                         if not (r[k] if isinstance(r[k], bool) else r[k]["ok"])), file=sys.stderr)
        sys.exit(1)
