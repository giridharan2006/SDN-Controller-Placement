"""Minimal Ryu app: counts switch (re)connections and packet-in messages. UNTESTED (see README)."""
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, DEAD_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3


class Counter(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.connects = {}
        self.packet_in = 0

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def on_state(self, ev):
        dpid = ev.datapath.id
        self.connects[dpid] = self.connects.get(dpid, 0) + (1 if ev.state == MAIN_DISPATCHER else 0)
        self.logger.info("switch %s state=%s total_connects=%s", dpid, ev.state, self.connects[dpid])

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def on_packet_in(self, ev):
        self.packet_in += 1
