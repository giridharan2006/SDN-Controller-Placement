# GreenPlace emulation: Mininet + Open vSwitch + Ryu

This package deploys GreenPlace's own controller pool on a real OpenFlow control plane. It replays the runtime
manager's sleep/wake and switch-migration schedule and measures:

1. switch migration (hand-over) latency;
2. flow-setup disruption and packet loss during hand-overs;
3. controller CPU and memory, plus CPU package power where the hardware exposes RAPL.

**Status (31 Oct 2026):** implemented and executed on Abilene and NSFNET. The results of that session are in
[`outputs/emulation/session_20261031/RESULTS.md`](../outputs/emulation/session_20261031/RESULTS.md), with a summary at the
end of this file. The environment had limits (no netem, userspace OVS datapath, no RAPL), and they are listed below.

## Three kinds of numbers: do not mix them

| Class | Where it comes from | Examples |
|---|---|---|
| **Simulation** | `greenplace/` (runtime manager, power model) | migration *counts*, modelled watts, all paper tables |
| **Mininet emulation** (this package) | real OVS switches, real Ryu processes, real packets, all on one host | hand-over ms, packet loss, flow-setup ms, controller CPU% |
| **Physical hardware** | measured on physical devices | none so far. RAPL, if available, is host-CPU package power and not a network device |

Every `summary.json` carries `measurement_class` and a separate `simulation_reference` block (the simulator's numbers
for the same pool and trace), so the two classes are never merged.

## What is reused and what is new

Nothing in `greenplace/` was changed. `emulation/schedule.py` calls the existing code:
- **Pool:** `baselines.nsga2_front` (3-objective NSGA-II) + `selection.select_migration_aware`. This is the same pick as
  `scripts/place_on_topology.py` and the study's `greenplace` method.
- **Schedule:** `runtime.RuntimeManager.step`. The awake set and switch→controller assignment are recorded for every step.
- **Check against the simulator:** `validate_plan()` checks that the emulated reassignments equal the simulator's
  migration count at every step. The run aborts if they differ.

| File | Role |
|---|---|
| `schedule.py` | GreenPlace pool + runtime schedule → per-step `wake` / `reassign` / `sleep` actions |
| `topo_spec.py` | Zoo graph → switch/host names, DPIDs, port numbers, loop-free shortest-delay forwarding tables |
| `ryu_app/gp_controller.py` | Ryu app (OF 1.3), one per controller process: MASTER role request, table-miss + barrier ("ready"), hop-by-hop reactive 5-tuple forwarding, timestamped event log + heartbeat |
| `controllers.py` | controller process life cycle: start (= wake; waits for port + heartbeat), health (alive + port + fresh heartbeat), stop (= sleep; SIGTERM, then SIGKILL after 5 s) |
| `traffic_probe.py` | stdlib-only UDP tool run inside Mininet hosts: receiver, new-flow probes, established stream |
| `monitor.py` | psutil sampler (per controller, ovs-vswitchd, host) + RAPL reader that refuses to guess |
| `analysis.py` | log → measurements (pure Python, unit-tested) |
| `runner.py` | the automated experiment (root) |
| `report.py` | pools the runs of a session → `RESULTS.md`, `pooled_results.csv/json` |
| `stream_gaps.py` | read-only decomposition of established-stream pauses: sender pause, transit delay, or overlap with an on-path hand-over → `stream_gaps.csv`, `stream_gaps_summary.json` |
| `env_check.py` | reports what is installed and what is missing |
| `start_ovs_userspace.sh` | starts OVS without systemd and without the kernel module (containers only) |
| `mininet_topo.py`, `ryu_counter.py` | the earlier, never-run harness, kept for history. **Superseded**: it started no controllers and never slept one |

## How a run works

1. Build the plan: GreenPlace pool, then the runtime manager over a 96-step trace (`--traces kind:seed`).
2. Build the topology in Mininet with one OVS switch per node (`s{i+1}`, dpid i+1, fail-mode secure, OpenFlow 1.3) and
   one host per switch (`h{i+1}`, 10.0.0.{i+1}). Static ARP, IPv6 off, checksum offload off. Links get netem delay
   equal to the GreenPlace propagation delay when netem exists.
3. Step 0: start the awake controllers and attach every switch. This initial attach is not counted as a migration.
4. Traffic runs for the whole replay. No sender starts until every receiver has reported, through a ready file
   written after its socket is bound, that it is listening:
   - **Background new-flow probes:** 5 per second from every host, round-robin to all others, with a fresh source
     port each time.
   - **3 established streams:** 100 pkt/s, on the longest paths through the switches that migrate most.
5. Each step runs in the runtime manager's order:
   1. **Wake:** start the Ryu process and wait until it is ready.
   2. **Reassign:** move every switch whose controller changes.
      - `bbm` (break-before-make): `ovs-vsctl set-controller sX <new>`.
      - `mbb` (make-before-break): set both old and new; the new controller requests MASTER; when the new controller
        is ready, remove the old one.
   3. **Sleep:** stop controllers that no longer own any switch.

   Before each reassignment, a **hand-over burst** of 50 new flows per second runs from the migrating switch's host to
   a one-hop neighbour, from 0.3 s before the command to 0.7 s after.
6. Verification after every step:
   - **OVS:** the switch has exactly one target, the scheduled one.
   - **Controller side:** that controller holds a live, ready session for the switch.
   - **Health:** every awake controller is checked.
   - **End of run:** `is_connected` is checked in OVS.
7. Steps are time-compressed: 0.25 s for a step without actions and 4 s for a step with actions. The model's
   15-minute step is not emulated in real time.

## Metric definitions

| Metric | Definition |
|---|---|
| handshake_ms | `set-controller` issued → OpenFlow FEATURES reply at the new controller |
| ready_ms | → barrier reply after the MASTER role request and the table-miss rule (the switch can now get new flows set up) |
| old_session_closed_ms | → the old controller sees the session drop (in `mbb` this happens after the old target is removed) |
| wake (s) | `ryu-manager` process start → OpenFlow port accepting **and** first heartbeat. This is a software start, not a server boot |
| sleep (ms) | SIGTERM → process exit |
| burst before / during / after | new-flow packets through the migrating switch, labelled relative to its own hand-over (during = command → ready + 50 ms) |
| setup ms | one-way delay of a new-flow packet = all hop-by-hop packet-ins + flow-mods + forwarding (hosts share one clock) |
| baseline probes | background probes whose path is ≥ 2 s away from every hand-over window on that path |
| CPU % | psutil `cpu_percent` of the controller process tree, as % of one core, sampled every 0.25 s |

## Setup on Ubuntu 24.04 (keeps ROS 2 Jazzy untouched)

Mininet and OVS come from apt. Ryu goes into its own Python 3.9 virtualenv; Ryu 4.34 does not run on Python ≥ 3.10.
None of these steps touches the ROS 2 Python 3.12 environment, `/opt/ros`, or your shell rc files.

```bash
# 1. system packages (Mininet uses the system python3; OVS runs as a service)
sudo apt install mininet openvswitch-switch ethtool iproute2
sudo systemctl start openvswitch-switch
sudo modprobe sch_netem || sudo apt install linux-modules-extra-$(uname -r)   # for link delays (netem)

# 2. Ryu in an isolated Python 3.9 venv (uv downloads a private CPython 3.9; nothing system-wide changes)
curl -LsSf https://astral.sh/uv/install.sh | sh          # or: pipx install uv
uv venv -p 3.9 ~/.venvs/greenplace-ryu
~/.venvs/greenplace-ryu/bin/python -m ensurepip
~/.venvs/greenplace-ryu/bin/python -m pip install "setuptools<58" "pbr==5.4.5" "eventlet==0.30.2"
~/.venvs/greenplace-ryu/bin/python -m pip install --no-build-isolation "ryu==4.34"
~/.venvs/greenplace-ryu/bin/ryu-manager --version         # -> ryu-manager 4.34

# 3. project dependencies for the runner, installed for root's system python3 (the runner runs under sudo)
sudo apt install python3-networkx python3-numpy python3-psutil python3-scipy python3-pandas python3-matplotlib
#    (or create a separate venv with --system-site-packages so it can still import mininet)

# 4. check, then run
sudo -E python3 -m emulation.env_check
sudo -E python3 scripts/run_emulation.py --topology Abilene Nsfnet \
     --traces diurnal:0 diurnal:1 bursty:0 noisy:0 --handover bbm mbb
python3 -m emulation.report outputs/emulation/<session>     # re-pool any time (no root)
```

The runner looks for Ryu at `--ryu-manager`, then `$GREENPLACE_RYU_MANAGER`, then `~/.venvs/greenplace-ryu/bin/ryu-manager`
(and the same path under `$SUDO_USER`'s home), then `PATH`.

Notes:
- **ROS 2:** OVS and Mininet create their own bridges, veths and namespaces and leave your normal interfaces and ROS
  domains alone. Mininet hosts are isolated namespaces, so DDS discovery traffic does not enter them. If anything is
  left over after a crash: `sudo mn -c`.
- **RAPL power** on an Intel laptop: the runner reads `/sys/class/powercap/intel-rapl:*/energy_uj` as root. This is
  CPU package power of the whole host, background load included, so it is reported as host power and never attributed
  to a single controller.
- **Containers / VMs without `openvswitch.ko`:** run `sudo emulation/start_ovs_userspace.sh`. The runner then uses the
  userspace datapath (`--datapath auto`).

## Outputs: `outputs/emulation/<session>/<topology>_<trace>_<mode>/`

| File | Contents |
|---|---|
| `summary.json` | all measurements of the run + environment + simulation reference |
| `handovers.csv` | one row per hand-over (incl. initial attach): t_cmd, t_features, t_ready, t_old_down, handshake/ready/old_down ms |
| `handover_disruption.csv` | per hand-over: probes in window, burst before/during/after counts, loss, setup ms |
| `bursts.csv`, `probes.csv` | every new-flow packet: send/recv time, lost, setup ms, phase / class |
| `streams.csv` | per established stream: sent, lost, lost in windows, longest gap, path |
| `steps.csv` | per step: awake set, wake/sleep, switches moved, switches verified |
| `controller_health.csv`, `controllers_lifecycle.csv` | health checks; every start/stop with timings, PIDs, exit codes |
| `resources.csv` | 0.25 s samples: controller CPU/RSS, ovs-vswitchd CPU/RSS, host CPU/memory, RAPL W if available |
| `controller_events.jsonl`, `ryu_*.log`, `run.log` | raw controller events, Ryu stdout/stderr, runner log |
| `plan.json`, `topology_spec.json` | the replayed GreenPlace schedule; ports, routes, host IPs |

Session level: `environment.json`, `command.txt`, `session_summary.csv/json`, `pooled_results.csv/json`, `RESULTS.md`.

## Tests

`tests/test_emulation.py` covers:
- the schedule against the simulator;
- loop-free routing on Abilene and NSFNET;
- every analysis function on synthetic logs;
- the traffic tool on loopback;
- the controller life cycle with a stub controller;
- a check that the Ryu app compiles;
- a check that the RAPL reader never makes up numbers.

These run without root. A real Mininet integration test (3 switches, two controllers, one `bbm` and one `mbb`
hand-over, then traffic) runs with:
```bash
sudo -E GREENPLACE_EMU_IT=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q tests/test_emulation.py
```

## Results of session `session_20261031` (Mininet emulation, 31 Oct 2026)

The full tables are in `outputs/emulation/session_20261031/RESULTS.md`.

- **Setup:** Abilene (11 switches, pool of 4) and NSFNET (13 switches, pool of 5); GreenPlace proxy pick, placement
  seed 0; traces diurnal 0 and 1, bursty 0 and noisy 0; both hand-over modes. That makes 16 runs.
- **Environment:** a 2-vCPU cloud VM with userspace OVS, no link delays and a loopback control channel.

- **The schedule ran as planned.** All 212 scheduled reassignments were executed and became ready, matching the
  simulator's 212. All 42 controller wakes and 42 sleeps were carried out. In all 1536 steps every switch was on its
  scheduled controller, with zero unhealthy checks and zero failures.
- **Hand-over latency:** command → new controller ready has a median of 22–28 ms (p95 32–53 ms, max 61 ms). The
  OpenFlow handshake alone has a median of 20–25 ms. `bbm` and `mbb` take about the same time to become ready.
  Waking a controller (process start → ready) takes 0.35–0.51 s median.
- **Flow-setup disruption:**
  - **Break-before-make:** new flows that hit a migrating switch during its hand-over were lost at 18.5% (Abilene,
    65 of 352) and 13.6% (NSFNET, 8 of 59). Before the hand-over the loss was 0–0.5%, and after it 0%.
  - **Make-before-break:** loss during the hand-over was 4.3% and 4.7%. The remaining losses come with OpenFlow
    `IS_SLAVE` errors: the old controller, already demoted, tries to install flows for packet-ins it received in the
    race window, and the switch rejects them.
  - **Setup time of new flows that got through:** 7–12 ms median during a hand-over against 5–9 ms before or after
    it.
- **Established flows:** **0 of 158,984** stream packets were lost, because a switch keeps its flow table while its
  controller changes (fail-mode secure). Packets did sometimes arrive in bursts after a pause, and the longest pauses
  were 190 ms (Abilene, `bbm`) and 173 ms (NSFNET, `bbm`). These two maxima are what the "Longest stream gap" column
  of RESULTS.md reports (whole run, any cause), and both occurred away from any hand-over.
  `python -m emulation.stream_gaps` decomposes every pause above 50 ms (45 in all; `stream_gaps.csv`):
  - **26 of 45 started at the sender.** The sender process itself stopped sending for about as long as the pause, so
    the network was not involved.
  - **19 of 45 were delays in transit** of 41–106 ms. On Abilene, 30 of the 32 pauses happened at the same moment
    as a pause in another stream. Those streams share switches s7, s8 and s11, and here every switch runs inside one
    `ovs-vswitchd` process, so a shared-switch delay cannot be told apart from a host-wide stall.
  - **10 pauses overlapped a hand-over of a switch on that stream's path** (from 0.5 s before the command to 1 s after
    ready). They fell in 5 of 16 runs, and their per-run maxima were 56–94 ms. This is where the earlier "5 runs,
    56–94 ms" statement came from.
  - **Rate near and away from hand-overs:** 0.037 pauses per stream-second near on-path hand-overs against 0.025
    elsewhere (binomial p = 0.31, 45 events).
  - **No packet was lost in any pause.**

  Reading: these pauses are timing variation on the 2-vCPU host (process scheduling and the userspace datapath), not
  a migration-caused interruption of established flows. With this few events, a small extra delay near hand-overs
  cannot be ruled out.
- **Controller CPU / memory:** each Ryu process used 3–6% of a core on average and 7–13% in the second after an
  action. The ~100% peaks are the Python start-up of a newly woken controller. Peak RSS was ≈49 MB per controller.
  `ovs-vswitchd` (userspace datapath) used 69–79% of a core throughout, which is a property of this datapath.
- **Power:** not measured, because the VM has no RAPL interface.

**Validation session `session_20261031_validation`.** This was run after the receiver-readiness fix: Abilene and
NSFNET, diurnal:0, both modes, 4 runs. All 32 reassignments, 6 wakes and 6 sleeps were executed, and 384/384 steps
were verified. All receivers were ready within 0.12–0.18 s. No established-stream packet was lost; the 5 pauses above
50 ms all started at the sender, and none overlapped a hand-over. With only 2–14 hand-overs per cell, its
flow-disruption percentages are too small a sample to quote.

## Limitations (read before quoting any number)

- **No link propagation delay in the 31 Oct session.** The VM's kernel has no `sch_netem`. On your Ubuntu machine,
  netem will be found and links get the GreenPlace delays; that changes flow-setup times, so rerun before quoting them.
- **The control channel is loopback.** Controllers and switches run on one host, so switch-to-controller propagation
  delay (the thing GreenPlace bounds) is **not** in the hand-over times. A real WAN adds about one RTT per handshake
  message.
- **Userspace OVS datapath** (no `openvswitch.ko` in the VM). `ovs-vswitchd` busy-polls and uses most of a core, and
  on a 2-vCPU VM CPU contention adds jitter to every timing. With the kernel datapath on real hardware, latencies will
  differ.
- **Steps are time-compressed.** Each sleep/wake is a process start/stop (≈0.3–0.4 s), not a server or VM power
  transition.
- **Hop-by-hop reactive forwarding** is a deliberate worst case for flow setup: every hop asks its own controller.
  Proactive or path-wide installation would show less disruption.
- **The counts are not independent of the simulator.** Migration counts equal the simulator's by construction,
  because the schedule is replayed. The emulation measures the cost of each migration, not how many there are.
- **Power:** none was measured in the 31 Oct session, because the VM has no RAPL. On hardware, RAPL is host CPU
  package power, not controller or switch power.
- **Small sample:** 2 small networks, 4 traces, 1 placement seed.
