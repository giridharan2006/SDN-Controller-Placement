"""Deploy a GreenPlace placement on Mininet and replay the runtime manager's migration schedule.

UNTESTED -- written without access to Mininet/OVS/Ryu (see emulation/README.md). Requires root.
"""
import argparse, json, sys, time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from greenplace.topology import load_zoo_topology  # noqa: E402


def export_schedule(gml, placement, capacity, bound_ms):
    """Run the simulator's RuntimeManager and return [(t, {switch: controller})] for deployment."""
    from greenplace.config import DelayConfig, PowerModel, RuntimeConfig
    from greenplace.delay import DelayEngine
    from greenplace.runtime import RuntimeManager
    from greenplace.traffic import get_trace
    g, _ = load_zoo_topology(gml)
    rm = RuntimeManager(g, set(placement), PowerModel(), DelayConfig(bound_ms),
                        RuntimeConfig(controller_capacity=capacity), delay_engine=DelayEngine(g))
    sched = []
    for t, load in enumerate(get_trace("diurnal", 0, 96)):
        rm.step(t, float(load))
        sched.append((t, dict(rm.prev_assignment)))
    return sched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gml", required=True)
    ap.add_argument("--placement", required=True, help="JSON list of controller node ids")
    ap.add_argument("--capacity", type=int, required=True)
    ap.add_argument("--bound-ms", type=float, required=True)
    ap.add_argument("--step-seconds", type=float, default=2.0, help="wall-clock seconds per trace step")
    a = ap.parse_args()
    from mininet.net import Mininet
    from mininet.node import RemoteController, OVSSwitch
    from mininet.link import TCLink
    g, _ = load_zoo_topology(a.gml)
    placement = json.loads(Path(a.placement).read_text())
    sched = export_schedule(a.gml, placement, a.capacity, a.bound_ms)
    net = Mininet(controller=None, switch=OVSSwitch, link=TCLink, autoSetMacs=True)
    sw = {n: net.addSwitch(f"s{n}") for n in g.nodes}
    for u, v, d in g.edges(data=True):
        net.addLink(sw[u], sw[v], delay=f"{d['delay']}ms")
    ctrl = {c: net.addController(f"c{c}", controller=RemoteController, ip="127.0.0.1", port=6653 + i)
            for i, c in enumerate(placement)}
    net.start()
    migrations, current = 0, {}
    for t, assign in sched:
        for node, c in assign.items():
            if current.get(node) != c:
                sw[node].vsctl(f"set-controller {sw[node].name} tcp:127.0.0.1:{ctrl[c].port}")
                migrations += current.get(node) is not None
                current[node] = c
        time.sleep(a.step_seconds)
    print(json.dumps({"emulated_migrations": migrations}))
    net.stop()


if __name__ == "__main__":
    main()
