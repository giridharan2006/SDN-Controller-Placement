"""Automated Mininet + Open vSwitch + Ryu experiment runner for GreenPlace (run as root).

    sudo python3 -m emulation.runner                                   # Abilene + NSFNET, defaults below
    sudo python3 -m emulation.runner --topology Abilene --traces diurnal:0 bursty:0 --handover bbm mbb

For every (topology, traffic trace, hand-over mode) it
  1. builds GreenPlace's pool and the runtime manager's per-step schedule (emulation.schedule -> unchanged
     greenplace code),
  2. deploys the Zoo topology in Mininet (OVS switches, one host per switch, netem link delays if available),
  3. starts one Ryu process per awake controller, replays wake / reassign / sleep step by step, and verifies after
     every step that each switch is connected to exactly the controller the schedule requires,
  4. runs new-flow probes and established UDP streams the whole time, samples controller/OVS CPU and memory
     (and RAPL package power only where readable),
  5. writes CSV/JSON/logs to outputs/emulation/<session>/<run>/ and a session summary.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import subprocess
import sys
import time
from datetime import datetime
from functools import partial
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from emulation import analysis as A                       # noqa: E402
from emulation.controllers import ControllerManager, find_ryu_manager  # noqa: E402
from emulation.env_check import check as env_check        # noqa: E402
from emulation.monitor import ResourceMonitor             # noqa: E402
from emulation.schedule import build_plan, validate_plan  # noqa: E402
from emulation.topo_spec import TopoSpec, build_spec, host_ip, host_mac  # noqa: E402
from greenplace.topology import load_zoo_topology         # noqa: E402

PROBE = Path(__file__).resolve().parent / "traffic_probe.py"
log = logging.getLogger("gp-emu")


# ---------------------------------------------------------------------------------------------- OVS helpers
def vsctl(*args, timeout=10) -> str:
    r = subprocess.run(["ovs-vsctl", f"--timeout={timeout}", *args], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"ovs-vsctl {' '.join(args)} failed: {r.stderr.strip()}")
    return r.stdout


def ovs_controller_state() -> dict:
    """bridge -> [[target, is_connected], ...] as OVS itself reports it."""
    ctl = json.loads(vsctl("-f", "json", "--columns=_uuid,target,is_connected", "list", "controller"))
    br = json.loads(vsctl("-f", "json", "--columns=name,controller", "list", "bridge"))
    cmap = {r[0][1]: [r[1], r[2]] for r in ctl["data"]}
    res = {}
    for name, c in br["data"]:
        uu = [c[1]] if c[0] == "uuid" else [x[1] for x in c[1]]
        res[name] = [cmap[u] for u in uu if u in cmap]
    return res


def target(port: int) -> str:
    return f"tcp:127.0.0.1:{port}"


# ---------------------------------------------------------------------------------------------- network
def build_network(g, spec: TopoSpec, datapath: str, link_delay: bool):
    from mininet.link import Link, TCLink
    from mininet.net import Mininet
    from mininet.node import OVSSwitch
    net = Mininet(topo=None, build=False, controller=None, autoSetMacs=False, autoStaticArp=False)
    Sw = partial(OVSSwitch, datapath=datapath, protocols="OpenFlow13", failMode="secure")
    sw, hosts = {}, {}
    for i in spec.nodes:
        sw[i] = net.addSwitch(spec.sw(i), cls=Sw, dpid="%016x" % spec.dpid(i))
        hosts[i] = net.addHost(spec.host(i), ip=host_ip(i) + "/16", mac=host_mac(i))
        net.addLink(hosts[i], sw[i], port2=1, cls=Link)
    for u, v, pu, pv, d in spec.links:
        if link_delay:
            net.addLink(sw[u], sw[v], port1=pu, port2=pv, cls=TCLink, delay=f"{d:.3f}ms")
        else:
            net.addLink(sw[u], sw[v], port1=pu, port2=pv, cls=Link)
    net.build()
    for h in hosts.values():
        h.cmd("sysctl -qw net.ipv6.conf.all.disable_ipv6=1 net.ipv6.conf.default.disable_ipv6=1")
        # Checksum offload must be off: with the OVS userspace datapath, veth TX offload leaves UDP checksums
        # unfilled and the receiving host drops every datagram (InCsumErrors). Harmless with the kernel datapath.
        for intf in h.intfList():
            h.cmd(f"ethtool -K {intf} tx off rx off >/dev/null 2>&1")
    for s in sw.values():
        s.start([])
    net.staticArp()
    return net, sw, hosts


def choose_streams(plan, spec: TopoSpec, k: int) -> list[tuple[int, int]]:
    """Established streams over the switches that migrate most often (longest path through each)."""
    moves: dict = {}
    for s in plan.steps:
        if s.t > 0:
            for u, _, _ in s.reassign:
                moves[u] = moves.get(u, 0) + 1
    hot = sorted(moves, key=lambda u: (-moves[u], u)) or list(spec.nodes)
    pairs, used = [], set()
    for sw_ in hot:
        cands = [(len(p), a, b) for (a, b), p in spec.paths.items() if a != b and sw_ in p and a not in used]
        if cands:
            _, a, b = max(cands)
            pairs.append((a, b))
            used.add(a)
        if len(pairs) >= k:
            break
    return pairs


# ---------------------------------------------------------------------------------------------- one run
def run_one(gml: Path, trace_kind: str, trace_seed: int, mode: str, a, out_dir: Path, env: dict) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(out_dir / "run.log")
    fh.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d %(levelname)s %(message)s", "%H:%M:%S"))
    log.addHandler(fh)
    try:
        return _run_one(gml, trace_kind, trace_seed, mode, a, out_dir, env)
    finally:
        log.removeHandler(fh)
        fh.close()


def _run_one(gml, trace_kind, trace_seed, mode, a, out_dir, env):
    t_wall0 = time.time()
    plan = build_plan(gml, trace_kind, trace_seed, a.placement_seed)
    errs = validate_plan(plan)
    (out_dir / "plan.json").write_text(json.dumps(plan.to_dict(), indent=1))
    if errs:
        raise RuntimeError("plan inconsistent with simulator: " + "; ".join(errs))
    g, meta = load_zoo_topology(gml)
    spec = build_spec(g)
    (out_dir / "topology_spec.json").write_text(json.dumps(
        {"links": spec.links, "routes": spec.routes_json(), "hosts": {spec.host(i): host_ip(i) for i in spec.nodes}},
        indent=1))
    log.info("run %s: %s, trace %s:%d, mode %s, pool %s, %d scheduled reassignments (simulator: %d)",
             out_dir.name, plan.topology, trace_kind, trace_seed, mode, plan.pool, plan.n_reassignments,
             plan.sim_summary["migrations"])

    net, sw, hosts = build_network(g, spec, env["datapath"], env["link_delay"])
    cm = ControllerManager(out_dir, spec.routes_json(), a.ryu_manager, idle_timeout=a.flow_idle_timeout,
                           hard_timeout=a.flow_hard_timeout)
    cm.assign_ports(plan.pool)
    mon = ResourceMonitor(out_dir / "resources.csv", cm.pids, interval=a.monitor_interval,
                          measure_power=not a.no_power)
    handovers, step_rows, health_rows, traffic_procs, recv_procs, failures = [], [], [], [], [], []
    current: dict = {}

    def connect(node, to, frm, step_t):
        """Hand switch `node` from controller frm (None = initial attach) to controller `to`."""
        name = spec.sw(node)
        rec = {"step": step_t, "switch": node, "dpid": spec.dpid(node), "from": frm, "to": to, "mode": mode,
               "initial": frm is None}
        rec["t_cmd"] = time.time()
        if frm is None or mode == "bbm":
            vsctl("set-controller", name, target(cm.ports[to]))
        else:  # make-before-break: add the new controller next to the old one; remove the old one once ready
            vsctl("set-controller", name, target(cm.ports[frm]), target(cm.ports[to]))
        rec["t_cmd_done"] = time.time()
        current[node] = to
        return rec

    def wait_ready(recs, timeout=a.handover_timeout):
        """Block until every hand-over in recs has its barrier reply at the new controller (or timeout)."""
        pending = list(recs)
        deadline = time.time() + timeout
        while pending and time.time() < deadline:
            evs = A.read_events(cm.events_path)
            A.match_handovers(pending, evs)
            pending = [r for r in pending if not r["ok"]]
            if pending:
                time.sleep(0.005)
        return pending

    def finish_mbb(recs):
        for r in recs:
            if mode == "mbb" and r["from"] is not None:
                r["t_old_removed"] = time.time()
                vsctl("set-controller", spec.sw(r["switch"]), target(cm.ports[r["to"]]))

    def verify(step_t, expected):
        """Controller side: each switch's expected controller has a live, ready session; OVS: single right target."""
        evs = A.read_events(cm.events_path)
        live = {}
        for e in evs:
            if e.get("dpid") is not None and e["ev"] in ("ready", "down"):
                live[(str(e["ctrl"]), int(e["dpid"]))] = e["ev"] == "ready"
        ovs = ovs_controller_state()
        ok, bad = 0, []
        for node, c in expected.items():
            tg = [t for t, _ in ovs.get(spec.sw(node), [])]
            good = tg == [target(cm.ports[c])] and live.get((str(c), spec.dpid(node)), False)
            ok += good
            if not good:
                bad.append({"switch": node, "expected": c, "ovs_targets": tg})
        return ok, bad

    try:
        mon.start()
        steps = plan.steps
        # ---- step 0: initial deployment (not counted as migrations)
        s0 = steps[0]
        for c in s0.active:
            cm.start(c)
        init = [connect(u, c, None, 0) for u, c in sorted(s0.assignment.items())]
        missing = wait_ready(init)
        if missing:
            raise RuntimeError(f"initial attach failed for switches {[r['switch'] for r in missing]}")
        ok, bad = verify(0, s0.assignment)
        step_rows.append({"t": 0, "awake": " ".join(map(str, s0.active)), "wake": "", "sleep": "", "moved": 0,
                          "switches_ok": ok, "switches": len(s0.assignment), "bad": json.dumps(bad)})
        handovers.extend(init)

        # ---- traffic for the whole replay
        n_event = sum(1 for s in steps[1:] if s.wake or s.sleep or s.reassign)
        est = a.warmup_s + n_event * (a.event_step_s + 1.5) + (len(steps) - 1 - n_event) * (a.idle_step_s + 0.1) \
            + a.cooldown_s + 30
        t_until = time.time() + est
        for i, h in hosts.items():
            recv_procs.append(h.popen([sys.executable, str(PROBE), "recv", "--out", str(out_dir / f"recv_{i}.csv"),
                                          "--ready-file", str(out_dir / f"recv_{i}.ready"),
                                          "--until", f"{t_until + 3:.3f}"]))
        # start no sender before every receiver has bound its socket (a fixed sleep raced with process start-up)
        t_wait = time.time()
        while not all((out_dir / f"recv_{i}.ready").exists() for i in hosts):
            dead = [i for i, p in zip(hosts, recv_procs) if p.poll() is not None]
            if dead or time.time() - t_wait > 30:
                raise RuntimeError(f"traffic receivers not ready (exited: {dead}) after {time.time() - t_wait:.1f}s")
            time.sleep(0.01)
        log.info("all %d receivers ready after %.2f s", len(hosts), time.time() - t_wait)
        all_ips = [host_ip(i) for i in spec.nodes]
        for i, h in hosts.items():
            dsts = ",".join(ip for ip in all_ips if ip != host_ip(i))
            traffic_procs.append(h.popen([sys.executable, str(PROBE), "probes", "--dsts", dsts, "--rate",
                                          str(a.probe_rate), "--out", str(out_dir / f"probes_{i}.csv"),
                                          "--until", f"{t_until:.3f}"]))
        streams = choose_streams(plan, spec, a.streams)
        for k, (src, dst) in enumerate(streams):
            traffic_procs.append(hosts[src].popen([sys.executable, str(PROBE), "stream", "--dst", host_ip(dst),
                                                   "--rate", str(a.stream_rate), "--sport-lo", str(10000 + k),
                                                   "--out", str(out_dir / f"stream_{src}.csv"),
                                                   "--until", f"{t_until:.3f}"]))
        time.sleep(a.warmup_s)

        # ---- replay steps 1..T
        burst_meta, burst_count = [], {}
        event_windows = []
        for s in steps[1:]:
            t_step = time.time()
            if s.reassign and a.burst_rate > 0:
                # hand-over bursts: high-rate NEW-FLOW probes whose first hop is the migrating switch, started
                # burst_pre_s before the reassignment commands and running burst_post_s after them
                moving = {x for x, _, _ in s.reassign}
                for u, _, _ in s.reassign[: a.max_bursts_per_step]:
                    # one-hop destination (prefer a neighbour that is not itself migrating), so the burst loads only
                    # the migrating switch and one neighbour and does not saturate the host
                    nbrs = sorted(g.neighbors(u), key=lambda v: (v in moving, v))
                    dst = int(nbrs[0])
                    k = burst_count.get(u, 0)
                    burst_count[u] = k + 1
                    lo = 40000 + (k * 500) % 19000
                    seq_base = 1_000_000 + len(burst_meta) * 10_000
                    f = out_dir / f"burst_{u}_{s.t}.csv"
                    traffic_procs.append(hosts[u].popen([
                        sys.executable, str(PROBE), "probes", "--kind", "B", "--dsts", host_ip(dst), "--rate",
                        str(a.burst_rate), "--sport-lo", str(lo), "--sport-hi", str(lo + 499), "--seq-base",
                        str(seq_base), "--out", str(f),
                        "--until", f"{time.time() + a.burst_pre_s + a.burst_post_s:.3f}"]))
                    burst_meta.append({"switch": u, "step": s.t, "dst": dst, "file": f.name})
                time.sleep(a.burst_pre_s)
            if s.wake or s.sleep or s.reassign:
                event_windows.append((time.time(), time.time() + 1.0))
            for c in s.wake:
                cm.start(c)
            recs = [connect(u, c_new, c_old, s.t) for u, c_old, c_new in s.reassign]
            missing = wait_ready(recs)
            finish_mbb(recs)
            for r in missing:
                failures.append({"step": s.t, "switch": r["switch"], "error": "hand-over not ready before timeout"})
            if recs and mode == "mbb":
                time.sleep(0.05)
            for c in s.sleep:
                cm.stop(c)
            handovers.extend(recs)
            ok, bad = verify(s.t, s.assignment)
            if bad:   # OVS / controller events can lag by a few ms: re-check once before declaring a failure
                time.sleep(0.2)
                ok, bad = verify(s.t, s.assignment)
            for c in s.active:
                hh = cm.health(c)
                hh["t"], hh["step"] = round(time.time(), 3), s.t
                health_rows.append(hh)
                if not hh["healthy"]:
                    failures.append({"step": s.t, "controller": c, "error": f"unhealthy: {hh}"})
            step_rows.append({"t": s.t, "awake": " ".join(map(str, s.active)), "wake": " ".join(map(str, s.wake)),
                              "sleep": " ".join(map(str, s.sleep)), "moved": len(recs), "switches_ok": ok,
                              "switches": len(s.assignment), "bad": json.dumps(bad)})
            if s.wake or s.sleep or s.reassign:
                log.info("t=%d wake=%s sleep=%s moved=%d verified %d/%d", s.t, s.wake, s.sleep, len(recs), ok,
                         len(s.assignment))
            dwell = a.event_step_s if (s.wake or s.sleep or s.reassign) else a.idle_step_s
            rest = dwell - (time.time() - t_step)
            if rest > 0:
                time.sleep(rest)
        t_settle_end = time.time()
        time.sleep(a.cooldown_s)

        # ---- final OVS view (is_connected is refreshed lazily by ovs-vswitchd)
        final_ok, t0 = 0, time.time()
        while time.time() - t0 < 15:
            st = ovs_controller_state()
            final_ok = sum(1 for u, c in steps[-1].assignment.items()
                           if st.get(spec.sw(u)) == [[target(cm.ports[c]), True]])
            if final_ok == len(steps[-1].assignment):
                break
            time.sleep(0.5)
    finally:
        # senders first, then (after in-flight packets have arrived) receivers; SIGTERM makes them flush their CSVs
        for group in (traffic_procs, recv_procs):
            for p in group:
                try:
                    p.terminate()
                except Exception:  # noqa: BLE001
                    pass
            for p in group:
                try:
                    p.wait(timeout=5)
                except Exception:  # noqa: BLE001
                    p.kill()
            time.sleep(1.0)
        mon.stop()
        cm.stop_all()
        net.stop()

    # ---------------------------------------------------------------- analysis
    events = A.read_events(cm.events_path)
    A.match_handovers(handovers, events)
    mig = [h for h in handovers if not h["initial"]]
    windows = A.windows_from_handovers(mig)
    win_all = [w for ws in windows.values() for w in ws]
    ip2node = spec.ip_to_node()
    recv_rows = []
    for i in spec.nodes:
        recv_rows += A.read_csv(out_dir / f"recv_{i}.csv")
    probes, stream_pkts = [], {}
    for i in spec.nodes:
        probes += A.join_traffic(A.read_csv(out_dir / f"probes_{i}.csv"), recv_rows, host_ip(i))
    for src, dst in streams:
        stream_pkts[(src, dst)] = A.join_traffic(A.read_csv(out_dir / f"stream_{src}.csv"), recv_rows, host_ip(src))
    A.classify_packets(probes, spec.paths, ip2node, windows, settle_end=t_settle_end)
    per_ho = A.per_handover_disruption(mig, probes)
    bursts = []
    for b in burst_meta:
        pk = A.join_traffic(A.read_csv(out_dir / b["file"]), recv_rows, host_ip(b["switch"]))
        ho = next((h for h in mig if h["step"] == b["step"] and h["switch"] == b["switch"]), None)
        A.burst_phases(pk, ho)
        for p_ in pk:
            p_["switch"], p_["step"] = b["switch"], b["step"]
        bursts += pk
    burst_by_phase = {ph: A.loss_latency([p for p in bursts if p["phase"] == ph])
                      for ph in ("before", "during", "after")}
    per_ho_burst = A.per_handover_bursts(mig, bursts)
    stream_res = []
    for (src, dst), pk in stream_pkts.items():
        path = spec.paths[(src, dst)]
        pk = [p for p in pk if p["send_ts"] <= t_settle_end]
        r = A.stream_gaps(pk, [w for s_ in path for w in windows.get(s_, [])])
        r.update(src=spec.host(src), dst=spec.host(dst), path=" ".join(spec.sw(x) for x in path),
                 migrations_on_path=sum(len(windows.get(s_, [])) for s_ in path))
        stream_res.append(r)
    res_rows = A.read_csv(out_dir / "resources.csv")
    power_rows = [float(r["cpu_percent"]) for r in res_rows if r["kind"] == "power"]
    resources = A.resource_summary([r for r in res_rows if r["kind"] != "power"], event_windows)
    lifecycle = cm.log
    wakes = [x for x in lifecycle if x["event"] == "wake"]
    sleeps = [x for x in lifecycle if x["event"] == "sleep"]

    # ---- CSV outputs
    A.write_csv(out_dir / "handovers.csv", handovers,
                ["step", "switch", "dpid", "from", "to", "mode", "initial", "t_cmd", "t_cmd_done", "t_features",
                 "t_ready", "t_old_down", "t_old_removed", "handshake_ms", "ready_ms", "old_down_ms", "ok"])
    A.write_csv(out_dir / "handover_disruption.csv", [dict(x, **y) for x, y in zip(per_ho, per_ho_burst)])
    A.write_csv(out_dir / "bursts.csv", bursts, ["switch", "step", "src", "dst", "sport", "seq", "send_ts", "recv_ts",
                                                 "lost", "latency_ms", "phase"])
    A.write_csv(out_dir / "steps.csv", step_rows)
    A.write_csv(out_dir / "controller_health.csv", health_rows)
    A.write_csv(out_dir / "controllers_lifecycle.csv", lifecycle,
                ["event", "controller", "port", "pid", "t", "port_open_s", "ready_s", "stop_s", "forced_kill",
                 "exit_code"])
    A.write_csv(out_dir / "probes.csv", [dict(p, affected_switches=" ".join(map(str, p.get("affected_switches", []))))
                                         for p in probes],
                ["kind", "src", "dst", "sport", "seq", "send_ts", "recv_ts", "lost", "latency_ms", "cls",
                 "affected_switches"])
    A.write_csv(out_dir / "streams.csv", stream_res)

    by_cls = {c: A.loss_latency([p for p in probes if p["cls"] == c]) for c in ("affected", "near", "baseline")}
    summary = {
        "measurement_class": "Mininet emulation (software switches and controllers on one host) - NOT hardware",
        "run": out_dir.name, "topology": plan.topology, "switches": plan.n_switches, "links": plan.n_links,
        "trace": f"{trace_kind}:{trace_seed}", "placement_seed": a.placement_seed, "handover_mode": mode,
        "pool": plan.pool, "capacity": plan.capacity, "delay_bound_ms": round(plan.bound_ms, 3),
        "environment": env,
        "simulation_reference": {"label": "GreenPlace simulator on the same pool and trace (SIMULATION)",
                                 **plan.sim_summary},
        "schedule": {"steps": len(plan.steps), "reassignments": plan.n_reassignments,
                     "wakes": sum(len(s.wake) for s in plan.steps[1:]),
                     "sleeps": sum(len(s.sleep) for s in plan.steps[1:])},
        "executed": {"reassignments": len(mig), "reassignments_ready": sum(1 for h in mig if h["ok"]),
                     "wakes": len(wakes) - len(plan.steps[0].active), "sleeps": len(sleeps),
                     "steps_verified": sum(1 for r in step_rows if r["switches_ok"] == r["switches"]),
                     "steps": len(step_rows), "final_ovs_is_connected": f"{final_ok}/{plan.n_switches}",
                     "unhealthy_checks": sum(1 for h in health_rows if not h["healthy"]), "failures": failures},
        "handover_latency_ms": {"handshake": A.stats([h["handshake_ms"] for h in mig]),
                                "ready": A.stats([h["ready_ms"] for h in mig]),
                                "old_session_closed": A.stats([h["old_down_ms"] for h in mig])},
        "controller_wake_s": A.stats([w["ready_s"] for w in wakes[len(plan.steps[0].active):]], nd=3),
        "controller_wake_all_starts_s": A.stats([w["ready_s"] for w in wakes], nd=3),
        "controller_sleep_s": A.stats([x["stop_s"] for x in sleeps], nd=4),
        "new_flow_probes": {"rate_per_host_pps": a.probe_rate, **{c: v for c, v in by_cls.items()},
                            "excluded_tail": sum(1 for p in probes if p["cls"] == "excluded_tail")},
        "handovers_with_probe_loss": sum(1 for r in per_ho if r["lost"]),
        "handover_bursts": {"rate_pps": a.burst_rate, "pre_s": a.burst_pre_s, "post_s": a.burst_post_s,
                            "bursts": len(burst_meta), **burst_by_phase,
                            "handovers_with_burst_loss": sum(1 for r in per_ho_burst if r["burst_during_lost"])},
        "resource_windows": "cpu_mean_in_windows = first 1 s after the actions of a step with wake/sleep/reassign "
                            "(includes hand-over burst traffic); cpu_mean_outside = all other samples",
        "established_streams": {"rate_pps": a.stream_rate, "streams": stream_res},
        "resources": resources,
        "power": ({"available": True, "what": "RAPL CPU package power of the whole host (all processes)",
                   "w": A.stats(power_rows)} if power_rows else
                  {"available": False, "reason": env.get("rapl", {}).get("reason", "not measured")}),
        "wall_clock_s": round(time.time() - t_wall0, 1),
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=1, default=str))
    log.info("done: %d/%d hand-overs ready, steps verified %d/%d, handshake median %s ms, affected-probe loss %s%%, "
             "baseline loss %s%%", summary["executed"]["reassignments_ready"], len(mig),
             summary["executed"]["steps_verified"], len(step_rows), summary["handover_latency_ms"]["handshake"]["median"],
             by_cls["affected"]["loss_pct"], by_cls["baseline"]["loss_pct"])
    return summary


# ---------------------------------------------------------------------------------------------- CLI
def resolve_gml(name: str) -> Path:
    p = Path(name)
    if p.suffix == ".gml" and p.exists():
        return p
    for d in (ROOT / "data" / "real_topologies", ROOT / "data" / "topologies"):
        for f in d.glob("*.gml"):
            if f.stem.lower() == name.lower():
                return f
    raise FileNotFoundError(f"topology {name} not found under data/real_topologies")


def environment(a) -> dict:
    chk = env_check()
    if not chk["ready"]:
        raise SystemExit("Emulation prerequisites missing:\n" + json.dumps(chk, indent=1) +
                         "\nSee emulation/README.md for setup.")
    datapath = a.datapath
    if datapath == "auto":
        datapath = "kernel" if chk["ovs"]["kernel_module"] else "user"
    link_delay = {"on": True, "off": False, "auto": chk["netem"]["ok"]}[a.link_delay]
    if link_delay and not chk["netem"]["ok"]:
        raise SystemExit("--link-delay on requested but netem is unavailable: " + chk["netem"]["detail"])
    cpu_model = ""
    try:
        cpu_model = next(l.split(":", 1)[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name"))
    except (OSError, StopIteration):
        pass
    return {"kernel": platform.release(), "python": chk["python"], "mininet": chk["mininet"]["version"],
            "ovs": chk["ovs"]["version"], "ryu": chk["ryu"]["version"], "ryu_manager": a.ryu_manager,
            "datapath": datapath, "link_delay_emulated": link_delay, "netem": chk["netem"]["detail"],
            "rapl": chk["rapl"], "virtualization": chk["virtualization"], "cpus": os.cpu_count(),
            "cpu_model": cpu_model, "control_channel": "TCP over loopback 127.0.0.1 (no control-path delay)",
            "link_delay": link_delay}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--topology", nargs="+", default=["Abilene", "Nsfnet"])
    ap.add_argument("--traces", nargs="+", default=["diurnal:0"], help="kind:seed (kinds as in greenplace.traffic)")
    ap.add_argument("--handover", nargs="+", choices=["bbm", "mbb"], default=["bbm", "mbb"],
                    help="bbm = break-before-make (replace target); mbb = make-before-break (add, role MASTER, remove)")
    ap.add_argument("--placement-seed", type=int, default=0)
    ap.add_argument("--datapath", choices=["auto", "kernel", "user"], default="auto")
    ap.add_argument("--link-delay", choices=["auto", "on", "off"], default="auto")
    ap.add_argument("--ryu-manager", default=None)
    ap.add_argument("--probe-rate", type=float, default=5.0, help="new-flow probes per second per host")
    ap.add_argument("--stream-rate", type=float, default=100.0, help="packets/s per established stream")
    ap.add_argument("--streams", type=int, default=3)
    ap.add_argument("--burst-rate", type=float, default=50.0, help="new-flow probes/s through each migrating switch "
                                                                    "around its hand-over (0 = off)")
    ap.add_argument("--burst-pre-s", type=float, default=0.3)
    ap.add_argument("--burst-post-s", type=float, default=0.7)
    ap.add_argument("--max-bursts-per-step", type=int, default=4)
    ap.add_argument("--idle-step-s", type=float, default=0.25, help="wall-clock length of a step with no action")
    ap.add_argument("--event-step-s", type=float, default=4.0, help="wall-clock length of a step with actions")
    ap.add_argument("--warmup-s", type=float, default=4.0)
    ap.add_argument("--cooldown-s", type=float, default=3.0)
    ap.add_argument("--handover-timeout", type=float, default=10.0)
    ap.add_argument("--flow-idle-timeout", type=int, default=5)
    ap.add_argument("--flow-hard-timeout", type=int, default=0, help="0 = none (established streams keep their flow)")
    ap.add_argument("--monitor-interval", type=float, default=0.25)
    ap.add_argument("--no-power", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "outputs" / "emulation"))
    ap.add_argument("--session", default=None, help="session folder name (default: timestamp)")
    a = ap.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
    if os.geteuid() != 0:
        raise SystemExit("Mininet needs root: run with sudo (see emulation/README.md).")
    a.ryu_manager = find_ryu_manager(a.ryu_manager)
    env = environment(a)
    session = Path(a.out) / (a.session or datetime.now().strftime("%Y%m%d_%H%M%S"))
    session.mkdir(parents=True, exist_ok=True)
    (session / "environment.json").write_text(json.dumps(env, indent=1))
    (session / "command.txt").write_text(" ".join(sys.argv) + "\n")
    subprocess.run(["mn", "-c"], capture_output=True)
    rows = []
    for topo in a.topology:
        gml = resolve_gml(topo)
        for tr in a.traces:
            kind, _, seed = tr.partition(":")
            for mode in a.handover:
                name = f"{gml.stem}_{kind}{seed or 0}_{mode}"
                try:
                    s = run_one(gml, kind, int(seed or 0), mode, a, session / name, env)
                    rows.append({"run": name, "status": "ok", **_flat(s)})
                except Exception as e:  # noqa: BLE001  -- record and continue with the next run
                    log.exception("run %s failed", name)
                    rows.append({"run": name, "status": f"FAILED: {e}"})
                    subprocess.run(["mn", "-c"], capture_output=True)
    A.write_csv(session / "session_summary.csv", rows,
                sorted({k for r in rows for k in r}, key=lambda k: (k not in ("run", "status"), k)))
    (session / "session_summary.json").write_text(json.dumps(rows, indent=1, default=str))
    try:
        from emulation.report import main as report_main
        report_main([str(session)])
    except Exception:  # noqa: BLE001 -- the per-run files are already written; pooling can be redone later
        log.exception("pooling the session failed; rerun: python -m emulation.report %s", session)
    log.info("session written to %s", session)
    return 0 if all(r["status"] == "ok" for r in rows) else 1


def _flat(s: dict) -> dict:
    hl, np_, hb = s["handover_latency_ms"], s["new_flow_probes"], s["handover_bursts"]
    return {"topology": s["topology"], "trace": s["trace"], "mode": s["handover_mode"], "pool": " ".join(map(str, s["pool"])),
            "datapath": s["environment"]["datapath"], "link_delay": s["environment"]["link_delay_emulated"],
            "reassign_scheduled": s["schedule"]["reassignments"], "reassign_executed": s["executed"]["reassignments"],
            "reassign_ready": s["executed"]["reassignments_ready"], "sim_migrations": s["simulation_reference"]["migrations"],
            "wakes": s["executed"]["wakes"], "sleeps": s["executed"]["sleeps"],
            "steps_verified": f'{s["executed"]["steps_verified"]}/{s["executed"]["steps"]}',
            "handshake_ms_median": hl["handshake"]["median"], "handshake_ms_p95": hl["handshake"]["p95"],
            "ready_ms_median": hl["ready"]["median"], "ready_ms_max": hl["ready"]["max"],
            "wake_s_median": s["controller_wake_s"]["median"], "sleep_s_median": s["controller_sleep_s"]["median"],
            "probe_affected_n": np_["affected"]["packets"], "probe_affected_loss_pct": np_["affected"]["loss_pct"],
            "probe_affected_setup_ms_median": np_["affected"]["latency_ms"]["median"],
            "probe_baseline_n": np_["baseline"]["packets"], "probe_baseline_loss_pct": np_["baseline"]["loss_pct"],
            "probe_baseline_setup_ms_median": np_["baseline"]["latency_ms"]["median"],
            "burst_before_n": hb["before"]["packets"], "burst_before_loss_pct": hb["before"]["loss_pct"],
            "burst_before_setup_ms_median": hb["before"]["latency_ms"]["median"],
            "burst_during_n": hb["during"]["packets"], "burst_during_loss_pct": hb["during"]["loss_pct"],
            "burst_during_setup_ms_median": hb["during"]["latency_ms"]["median"],
            "burst_during_setup_ms_max": hb["during"]["latency_ms"]["max"],
            "burst_after_n": hb["after"]["packets"], "burst_after_loss_pct": hb["after"]["loss_pct"],
            "burst_after_setup_ms_median": hb["after"]["latency_ms"]["median"],
            "stream_lost_total": sum(x["lost"] for x in s["established_streams"]["streams"]),
            "stream_lost_in_windows": sum(x["lost_in_windows"] for x in s["established_streams"]["streams"]),
            "power_available": s["power"]["available"], "wall_clock_s": s["wall_clock_s"]}


if __name__ == "__main__":
    sys.exit(main())
