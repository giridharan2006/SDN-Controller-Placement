"""Turn the raw logs of one emulation run into measurements (pure Python, unit-tested on synthetic logs).

Definitions (all times are wall-clock seconds on the emulation host)
  hand-over of switch s from A to B, command issued at t_cmd:
    handshake_ms  = first OpenFlow FEATURES reply of s at B after t_cmd            - t_cmd
    ready_ms      = first barrier reply of s at B after t_cmd (table-miss installed) - t_cmd
    old_down_ms   = A notices the session to s closed                               - t_cmd   (break-before-make)
  disruption window of s = [t_cmd, t_ready + guard]
  a NEW-FLOW probe is "affected" by a hand-over if s is on its path and it was sent inside s's window;
  a probe is "baseline" if s is on its path and it was sent at least `clear_s` away from every window of any switch
  on its path.
"""
from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path


# ---------------------------------------------------------------------------------------------- loading
def read_events(path: Path) -> list[dict]:
    out = []
    p = Path(path)
    if not p.exists():
        return out
    for line in p.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def read_csv(path: Path) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    with open(p, newline="") as fh:
        return list(csv.DictReader(fh))


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None):
    fields = fields or (list(rows[0].keys()) if rows else [])
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _q(xs, f):
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * f
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def stats(xs, scale=1.0, nd=2) -> dict:
    xs = [x * scale for x in xs if x is not None]
    if not xs:
        return {"n": 0, "median": None, "p95": None, "min": None, "max": None, "mean": None}
    return {"n": len(xs), "median": round(statistics.median(xs), nd), "p95": round(_q(xs, 0.95), nd),
            "min": round(min(xs), nd), "max": round(max(xs), nd), "mean": round(statistics.fmean(xs), nd)}


# ---------------------------------------------------------------------------------------------- hand-overs
def match_handovers(handovers: list[dict], events: list[dict], timeout_s: float = 30.0) -> list[dict]:
    """Attach controller-side timings to each hand-over record (in place, also returned)."""
    by_key: dict = {}
    for e in events:
        if e.get("dpid") is None:
            continue
        by_key.setdefault((str(e["ctrl"]), int(e["dpid"]), e["ev"]), []).append(e["ts"])
    for v in by_key.values():
        v.sort()

    def first_after(ctrl, dpid, ev, t0):
        for ts in by_key.get((str(ctrl), int(dpid), ev), []):
            if t0 <= ts <= t0 + timeout_s:
                return ts
        return None

    for h in handovers:
        t0 = h["t_cmd"]
        tf = first_after(h["to"], h["dpid"], "features", t0)
        tr = first_after(h["to"], h["dpid"], "ready", t0)
        td = first_after(h["from"], h["dpid"], "down", t0 - 0.001) if h.get("from") is not None else None
        h["t_features"], h["t_ready"], h["t_old_down"] = tf, tr, td
        h["handshake_ms"] = None if tf is None else round((tf - t0) * 1000, 3)
        h["ready_ms"] = None if tr is None else round((tr - t0) * 1000, 3)
        h["old_down_ms"] = None if td is None else round((td - t0) * 1000, 3)
        h["ok"] = tr is not None
    return handovers


# ---------------------------------------------------------------------------------------------- traffic
def join_traffic(sent: list[dict], recv: list[dict], src_ip: str) -> list[dict]:
    """sent rows of one host + all recv rows -> per-packet rows with recv_ts/latency (None if lost)."""
    got = {}
    for r in recv:
        if r["src"] == src_ip:
            got[(r["kind"], int(r["seq"]))] = float(r["recv_ts"])
    out = []
    for s in sent:
        ts = float(s["send_ts"])
        rt = got.get((s["kind"], int(s["seq"])))
        out.append({"kind": s["kind"], "src": src_ip, "dst": s["dst"], "sport": int(s["sport"]), "seq": int(s["seq"]),
                    "send_ts": ts, "recv_ts": rt, "lost": rt is None,
                    "latency_ms": None if rt is None else round((rt - ts) * 1000, 3)})
    return out


def windows_from_handovers(handovers: list[dict], guard_s: float = 0.05, missing_s: float = 5.0) -> dict:
    """switch node -> list of (start, end) disruption windows. A failed hand-over gets a `missing_s` window."""
    w: dict = {}
    for h in handovers:
        end = (h["t_ready"] + guard_s) if h.get("t_ready") else h["t_cmd"] + missing_s
        w.setdefault(int(h["switch"]), []).append((h["t_cmd"], end))
    return w


def classify_packets(pkts: list[dict], paths: dict, ip_to_node: dict, windows: dict, clear_s: float = 2.0,
                     settle_end: float | None = None):
    """Label each packet affected (sent inside a window of a switch on its path), baseline (clear of all windows of
    switches on its path by clear_s), or neither. Packets sent after settle_end are excluded (end-of-run tail)."""
    for p in pkts:
        if settle_end is not None and p["send_ts"] > settle_end:
            p["cls"] = "excluded_tail"
            continue
        path = paths[(ip_to_node[p["src"]], ip_to_node[p["dst"]])]
        t = p["send_ts"]
        affected, near = [], False
        for s in path:
            for a, b in windows.get(s, []):
                if a <= t <= b:
                    affected.append(s)
                if a - clear_s <= t <= b + clear_s:
                    near = True
        p["affected_switches"] = affected
        p["cls"] = "affected" if affected else ("near" if near else "baseline")
    return pkts


def loss_latency(pkts: list[dict]) -> dict:
    n = len(pkts)
    lost = sum(1 for p in pkts if p["lost"])
    return {"packets": n, "lost": lost, "loss_pct": round(100 * lost / n, 3) if n else None,
            "latency_ms": stats([p["latency_ms"] for p in pkts if not p["lost"]])}


def per_handover_disruption(handovers: list[dict], probes: list[dict]) -> list[dict]:
    rows = []
    for i, h in enumerate(handovers):
        end = (h["t_ready"] + 0.05) if h.get("t_ready") else h["t_cmd"] + 5.0
        aff = [p for p in probes if h["switch"] in p.get("affected_switches", []) and h["t_cmd"] <= p["send_ts"] <= end]
        ll = loss_latency(aff)
        rows.append({"handover": i, "switch": h["switch"], "probes_in_window": ll["packets"], "lost": ll["lost"],
                     "loss_pct": ll["loss_pct"], "setup_ms_median": ll["latency_ms"]["median"],
                     "setup_ms_max": ll["latency_ms"]["max"]})
    return rows


def stream_gaps(pkts: list[dict], windows_on_path: list) -> dict:
    """For one established stream: loss and longest inter-arrival gap, overall and inside hand-over windows."""
    rec = sorted(p["recv_ts"] for p in pkts if not p["lost"])
    gaps = [b - a for a, b in zip(rec, rec[1:])]
    in_w = [p for p in pkts if any(a <= p["send_ts"] <= b for a, b in windows_on_path)]
    return {"sent": len(pkts), "lost": sum(p["lost"] for p in pkts),
            "max_gap_ms": round(max(gaps) * 1000, 2) if gaps else None,
            "sent_in_windows": len(in_w), "lost_in_windows": sum(p["lost"] for p in in_w)}


def resource_summary(rows: list[dict], windows_all: list) -> dict:
    """Mean/peak CPU% and RSS per controller, OVS and host; CPU split inside vs outside hand-over windows."""
    out: dict = {}
    for r in rows:
        key = f'{r["kind"]}:{r["id"]}'
        t = float(r["t"])
        inside = any(a <= t <= b for a, b in windows_all)
        d = out.setdefault(key, {"cpu": [], "cpu_in": [], "cpu_out": [], "rss": []})
        try:
            c = float(r["cpu_percent"])
        except (TypeError, ValueError):
            continue
        d["cpu"].append(c)
        (d["cpu_in"] if inside else d["cpu_out"]).append(c)
        if r.get("rss_mb"):
            d["rss"].append(float(r["rss_mb"]))
    res = {}
    for k, d in out.items():
        res[k] = {"samples": len(d["cpu"]),
                  "cpu_mean": round(statistics.fmean(d["cpu"]), 2) if d["cpu"] else None,
                  "cpu_peak": round(max(d["cpu"]), 2) if d["cpu"] else None,
                  "cpu_mean_in_windows": round(statistics.fmean(d["cpu_in"]), 2) if d["cpu_in"] else None,
                  "cpu_mean_outside": round(statistics.fmean(d["cpu_out"]), 2) if d["cpu_out"] else None,
                  "rss_mb_mean": round(statistics.fmean(d["rss"]), 1) if d["rss"] else None,
                  "rss_mb_peak": round(max(d["rss"]), 1) if d["rss"] else None}
    return res


# ---------------------------------------------------------------------------------------------- hand-over bursts
def burst_phases(pkts: list[dict], ho: dict | None, guard_s: float = 0.05):
    """Label burst packets relative to THEIR hand-over: before (sent before t_cmd), during (t_cmd .. t_ready+guard),
    after. If the hand-over never became ready, everything from t_cmd on is 'during'."""
    for p in pkts:
        if ho is None:
            p["phase"] = "unmatched"
            continue
        end = ho["t_ready"] + guard_s if ho.get("t_ready") else float("inf")
        t = p["send_ts"]
        p["phase"] = "before" if t < ho["t_cmd"] else ("during" if t <= end else "after")
    return pkts


def per_handover_bursts(handovers: list[dict], bursts: list[dict]) -> list[dict]:
    rows = []
    for h in handovers:
        mine = [p for p in bursts if p["switch"] == h["switch"] and p["step"] == h["step"]]
        r = {}
        for ph in ("before", "during", "after"):
            ll = loss_latency([p for p in mine if p["phase"] == ph])
            r[f"burst_{ph}_n"] = ll["packets"]
            r[f"burst_{ph}_lost"] = ll["lost"]
            r[f"burst_{ph}_setup_ms_median"] = ll["latency_ms"]["median"]
            r[f"burst_{ph}_setup_ms_max"] = ll["latency_ms"]["max"]
        rows.append(r)
    return rows
