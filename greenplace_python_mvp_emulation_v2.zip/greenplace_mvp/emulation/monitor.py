"""Resource monitoring during an emulation run: per-controller CPU and memory (psutil), Open vSwitch CPU, host CPU,
and -- only where the hardware exposes it -- CPU package energy via Linux RAPL (powercap).

Power is NEVER estimated here. If RAPL is not readable, the run records `power: unavailable` with the reason.
RAPL measures the whole CPU package (all processes), so it cannot be attributed to one controller; it is reported
as host package power, with idle-baseline and during-run averages.
"""
from __future__ import annotations

import csv
import glob
import os
import threading
import time
from pathlib import Path

import psutil


def rapl_domains() -> list[Path]:
    """Top-level RAPL package domains (intel-rapl:N) that expose energy_uj."""
    return sorted(Path(p).parent for p in glob.glob("/sys/class/powercap/intel-rapl:*/energy_uj")
                  if Path(p).parent.name.count(":") == 1)


def rapl_status() -> dict:
    doms = rapl_domains()
    if not doms:
        return {"available": False, "reason": "no /sys/class/powercap/intel-rapl:* domains (VM, non-Intel/AMD-RAPL "
                                              "CPU, or powercap driver not loaded)"}
    try:
        for d in doms:
            int((d / "energy_uj").read_text())
    except PermissionError:
        return {"available": False, "reason": "energy_uj not readable (needs root on kernels >= 5.10)"}
    except OSError as e:
        return {"available": False, "reason": f"energy_uj read error: {e}"}
    return {"available": True, "domains": [d.name for d in doms],
            "names": [(d / "name").read_text().strip() if (d / "name").exists() else d.name for d in doms]}


class RaplReader:
    def __init__(self):
        self.doms = rapl_domains()
        self.maxr = {d: int((d / "max_energy_range_uj").read_text()) if (d / "max_energy_range_uj").exists() else 2**32
                     for d in self.doms}
        self.last = {d: int((d / "energy_uj").read_text()) for d in self.doms}
        self.t_last = time.time()

    def read_watts(self) -> float:
        """Average package power (W, all domains summed) since the previous call; handles counter wrap."""
        now = time.time()
        total_uj = 0
        for d in self.doms:
            v = int((d / "energy_uj").read_text())
            dv = v - self.last[d]
            if dv < 0:
                dv += self.maxr[d]
            total_uj += dv
            self.last[d] = v
        dt, self.t_last = now - self.t_last, now
        return total_uj / 1e6 / dt if dt > 0 else float("nan")


def find_pids(name: str) -> list[int]:
    out = []
    for p in psutil.process_iter(["name", "cmdline"]):
        try:
            if p.info["name"] == name:
                out.append(p.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return out


class ResourceMonitor(threading.Thread):
    """Samples every `interval` s into resources.csv:
       t, kind (controller|ovs|host|power), id, cpu_percent, rss_mb, extra
    cpu_percent for a process is percent of ONE core (can exceed 100 on multi-core); host cpu is percent of all cores."""

    def __init__(self, out_csv: Path, pid_source, interval: float = 0.25, measure_power: bool = True):
        super().__init__(daemon=True)
        self.out_csv, self.pid_source, self.interval = Path(out_csv), pid_source, interval
        self.stop_evt = threading.Event()
        self.procs: dict = {}
        self.power = rapl_status() if measure_power else {"available": False, "reason": "disabled by --no-power"}
        self.rapl = RaplReader() if self.power["available"] else None
        self.rows = 0

    def _proc(self, key, pid):
        p = self.procs.get(key)
        if p is None or p.pid != pid:
            try:
                p = psutil.Process(pid)
                p.cpu_percent(None)          # prime
                self.procs[key] = p
            except psutil.NoSuchProcess:
                return None
        return p

    @staticmethod
    def _tree_usage(p):
        """CPU% and RSS of a process plus its children (ryu-manager may fork helpers)."""
        cpu, rss = p.cpu_percent(None), p.memory_info().rss
        for ch in p.children(recursive=True):
            try:
                rss += ch.memory_info().rss
            except psutil.NoSuchProcess:
                pass
        return cpu, rss

    def run(self):
        psutil.cpu_percent(None)
        with open(self.out_csv, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["t", "kind", "id", "cpu_percent", "rss_mb", "extra"])
            while not self.stop_evt.is_set():
                t = time.time()
                for node, pid in list(self.pid_source().items()):
                    p = self._proc(("c", node), pid)
                    if p is None:
                        continue
                    try:
                        cpu, rss = self._tree_usage(p)
                        w.writerow([f"{t:.3f}", "controller", node, f"{cpu:.1f}", f"{rss / 2**20:.1f}", pid])
                    except psutil.NoSuchProcess:
                        pass
                for pid in find_pids("ovs-vswitchd"):
                    p = self._proc(("ovs", pid), pid)
                    if p is not None:
                        try:
                            w.writerow([f"{t:.3f}", "ovs", "ovs-vswitchd", f"{p.cpu_percent(None):.1f}",
                                        f"{p.memory_info().rss / 2**20:.1f}", pid])
                        except psutil.NoSuchProcess:
                            pass
                vm = psutil.virtual_memory()
                w.writerow([f"{t:.3f}", "host", "all", f"{psutil.cpu_percent(None):.1f}",
                            f"{(vm.total - vm.available) / 2**20:.1f}", os.cpu_count()])
                if self.rapl is not None:
                    w.writerow([f"{t:.3f}", "power", "rapl_package_w", f"{self.rapl.read_watts():.3f}", "", ""])
                self.rows += 1
                fh.flush()
                self.stop_evt.wait(self.interval)

    def stop(self):
        self.stop_evt.set()
        self.join(timeout=5)
