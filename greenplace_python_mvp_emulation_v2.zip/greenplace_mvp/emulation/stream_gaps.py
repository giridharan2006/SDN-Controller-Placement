"""Decompose established-stream receive gaps (read-only analysis of an existing session's raw files).

For every gap between consecutive received packets of a stream that exceeds --threshold-ms it reports:
  recv_gap_ms   receive-side gap (what streams.csv max_gap_ms is the maximum of)
  send_gap_ms   gap between the SEND timestamps of the same two packets. If send_gap ≈ recv_gap, the sender process
                itself did not run (host scheduling), so the network was not interrupted.
  network_excess_ms = recv_gap - send_gap: extra delay added between sender and receiver (switches/controllers)
  latency_after_ms  one-way delay of the first packet after the gap
  lost_in_gap       packets sent inside the gap that never arrived
  on_path_handover  the gap overlaps [t_cmd - 0.5 s, t_ready + 1 s] of a hand-over of a switch ON the stream's path
  any_handover      same, for any switch (this is the looser test used in an earlier, ad-hoc summary)
  concurrent_streams number of OTHER streams of the run with a gap > threshold overlapping this one (host-wide stall)

    python -m emulation.stream_gaps outputs/emulation/<session> [--threshold-ms 50]
writes <session>/stream_gaps.csv and stream_gaps_summary.json; nothing else is modified.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from . import analysis as A


def run_gaps(run_dir: Path, threshold_ms: float = 50.0, pre_s: float = 0.5, post_s: float = 1.0) -> list[dict]:
    spec = json.loads((run_dir / "topology_spec.json").read_text())
    ip2host = {ip: h for h, ip in spec["hosts"].items()}
    plan = json.loads((run_dir / "plan.json").read_text())
    n = plan["n_switches"]
    ho = [h for h in A.read_csv(run_dir / "handovers.csv") if h["initial"] == "False"]
    wins = [(int(h["switch"]), float(h["t_cmd"]) - pre_s, (float(h["t_ready"]) if h["t_ready"] else float(h["t_cmd"]) + 5)
             + post_s) for h in ho]
    streams = A.read_csv(run_dir / "streams.csv")
    recv = []
    for i in range(n):
        recv += [r for r in A.read_csv(run_dir / f"recv_{i}.csv") if r["kind"] == "S"]
    out = []
    for st in streams:
        src_node = int(st["src"][1:]) - 1
        path = [int(x[1:]) - 1 for x in st["path"].split()]
        src_ip = next(ip for ip, h in ip2host.items() if h == st["src"])
        sent = {int(r["seq"]): float(r["send_ts"]) for r in A.read_csv(run_dir / f"stream_{src_node}.csv")}
        got = sorted((float(r["recv_ts"]), int(r["seq"])) for r in recv if r["src"] == src_ip)
        for (ra, sa), (rb, sb) in zip(got, got[1:]):
            g = (rb - ra) * 1000
            if g <= threshold_ms:
                continue
            send_gap = (sent[sb] - sent[sa]) * 1000 if sa in sent and sb in sent else None
            lost_in = sum(1 for q in range(sa + 1, sb) if q in sent) - sum(1 for _, q in got if sa < q < sb)
            out.append({
                "run": run_dir.name, "stream": f'{st["src"]}->{st["dst"]}', "t_start": round(ra, 3),
                "t_end": round(rb, 3), "recv_gap_ms": round(g, 2),
                "send_gap_ms": None if send_gap is None else round(send_gap, 2),
                "network_excess_ms": None if send_gap is None else round(g - send_gap, 2),
                "latency_after_ms": round((rb - sent[sb]) * 1000, 2) if sb in sent else None,
                "lost_in_gap": lost_in,
                "on_path_handover": any(s in path and a <= rb and ra <= b for s, a, b in wins),
                "any_handover": any(a <= rb and ra <= b for _, a, b in wins),
            })
    for g in out:
        g["concurrent_streams"] = sum(1 for h in out if h is not g and h["stream"] != g["stream"]
                                      and h["t_start"] <= g["t_end"] and g["t_start"] <= h["t_end"])
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("session")
    ap.add_argument("--threshold-ms", type=float, default=50.0)
    a = ap.parse_args(argv)
    session = Path(a.session)
    rows = []
    for d in sorted(p.parent for p in session.glob("*/streams.csv")):
        rows += run_gaps(d, a.threshold_ms)
    A.write_csv(session / "stream_gaps.csv", rows,
                ["run", "stream", "t_start", "t_end", "recv_gap_ms", "send_gap_ms", "network_excess_ms",
                 "latency_after_ms", "lost_in_gap", "on_path_handover", "any_handover", "concurrent_streams"])
    ex = [r["network_excess_ms"] for r in rows if r["network_excess_ms"] is not None]
    summ = {
        "threshold_ms": a.threshold_ms, "gaps": len(rows),
        "runs_with_gaps": sorted({r["run"] for r in rows}),
        "runs_with_gap_near_any_handover": sorted({r["run"] for r in rows if r["any_handover"]}),
        "runs_with_gap_near_on_path_handover": sorted({r["run"] for r in rows if r["on_path_handover"]}),
        "gaps_near_on_path_handover": sum(r["on_path_handover"] for r in rows),
        "max_recv_gap_ms": max((r["recv_gap_ms"] for r in rows), default=None),
        "max_network_excess_ms": max(ex, default=None),
        "network_excess_ms": A.stats(ex),
        "lost_in_gaps": sum(r["lost_in_gap"] for r in rows),
    }
    (session / "stream_gaps_summary.json").write_text(json.dumps(summ, indent=1))
    print(json.dumps(summ, indent=1))
    return rows


if __name__ == "__main__":
    main()
