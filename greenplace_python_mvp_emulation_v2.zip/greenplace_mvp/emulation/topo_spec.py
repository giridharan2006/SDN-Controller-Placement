"""Mininet-independent description of the emulated network: names, datapath IDs, port numbers, host addresses and
loop-free per-destination forwarding tables (shortest propagation-delay paths).

Conventions
  switch for graph node i : name s{i+1}, dpid i+1
  host attached to node i : name h{i+1}, IP 10.0.0.{i+1}/16 (10.0.{(i+1)//256}.{(i+1)%256} beyond 254), port 1 of s{i+1}
  inter-switch links      : ports 2, 3, ... on each switch, in sorted edge order
"""
from __future__ import annotations

from dataclasses import dataclass, field

import networkx as nx


def host_ip(i: int) -> str:
    k = i + 1
    return f"10.0.{k // 256}.{k % 256}"


def host_mac(i: int) -> str:
    k = i + 1
    return "00:00:00:00:%02x:%02x" % (k // 256, k % 256)


@dataclass
class TopoSpec:
    nodes: list                                   # graph node ids (ints 0..n-1)
    links: list                                   # [(u, v, port_u, port_v, delay_ms)]
    routes: dict = field(default_factory=dict)    # dpid -> {dst_ip: out_port}
    paths: dict = field(default_factory=dict)     # (src_node, dst_node) -> [node, ..., node]

    @staticmethod
    def sw(i: int) -> str:
        return f"s{i + 1}"

    @staticmethod
    def host(i: int) -> str:
        return f"h{i + 1}"

    @staticmethod
    def dpid(i: int) -> int:
        return i + 1

    def node_of_dpid(self, dpid: int) -> int:
        return dpid - 1

    def ip_to_node(self) -> dict:
        return {host_ip(i): i for i in self.nodes}

    def routes_json(self) -> dict:
        return {str(d): r for d, r in self.routes.items()}


def build_spec(g: nx.Graph) -> TopoSpec:
    nodes = sorted(int(n) for n in g.nodes)
    next_port = {n: 2 for n in nodes}                 # port 1 is the host port
    port = {}                                         # (u, v) -> port on u towards v
    links = []
    for u, v in sorted((min(a, b), max(a, b)) for a, b in g.edges()):
        pu, pv = next_port[u], next_port[v]
        next_port[u] += 1
        next_port[v] += 1
        port[(u, v)], port[(v, u)] = pu, pv
        links.append((u, v, pu, pv, float(g[u][v].get("delay", 1.0))))
    spec = TopoSpec(nodes=nodes, links=links)
    # one shortest-path tree per destination => forwarding is loop-free and consistent hop by hop
    routes = {TopoSpec.dpid(n): {} for n in nodes}
    for dst in nodes:
        paths = nx.single_source_dijkstra_path(g, dst, weight="delay")   # dst -> x ; reverse = x -> dst
        ip = host_ip(dst)
        routes[TopoSpec.dpid(dst)][ip] = 1
        for src, pth in paths.items():
            fwd = list(reversed(pth))                  # src ... dst
            spec.paths[(int(src), int(dst))] = [int(x) for x in fwd]
            if src != dst:
                routes[TopoSpec.dpid(int(src))][ip] = port[(int(src), int(fwd[1]))]
    spec.routes = routes
    return spec


def follow(spec: TopoSpec, src: int, dst: int, max_hops: int = 10_000) -> list:
    """Walk the forwarding tables from switch src to the host of dst; returns the switch sequence (raises on loops)."""
    by_port = {}
    for u, v, pu, pv, _ in spec.links:
        by_port[(u, pu)] = v
        by_port[(v, pv)] = u
    ip, cur, seen = host_ip(dst), src, []
    while True:
        if cur in seen or len(seen) > max_hops:
            raise ValueError(f"forwarding loop from {src} to {dst}: {seen + [cur]}")
        seen.append(cur)
        out = spec.routes[TopoSpec.dpid(cur)][ip]
        if out == 1:
            return seen
        cur = by_port[(cur, out)]
