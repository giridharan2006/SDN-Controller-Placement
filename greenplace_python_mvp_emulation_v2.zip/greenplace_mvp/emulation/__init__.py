"""GreenPlace Mininet + Open vSwitch + Ryu emulation.

Pure-Python parts (schedule, topology spec, routing, analysis) import nothing from Mininet or Ryu and are unit-tested.
`emulation.runner` drives a real Mininet network and must be run as root; the Ryu app in `ryu_app/` runs inside
`ryu-manager` (its own virtualenv, see README).
"""
