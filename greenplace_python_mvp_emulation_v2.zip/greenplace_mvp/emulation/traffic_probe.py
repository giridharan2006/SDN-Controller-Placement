#!/usr/bin/env python3
"""Standalone UDP traffic tool run inside Mininet hosts (Python 3 standard library only).

  recv   --port P --out recv.csv --until T            log every datagram: kind,src,sport,seq,send_ts,recv_ts
         [--ready-file F]  F is created (atomically) only AFTER the socket is bound: wait for it before sending
         [--expect N]      exit as soon as N datagrams have been logged (--until stays the safety deadline)
  probes --dsts IP[,IP...] --rate R --out sent.csv    NEW-FLOW probes (--kind B for hand-over bursts): every packet
                                                       uses a fresh source port, so it is a new 5-tuple and needs a
                                                       controller decision on every hop
  stream --dst IP --rate R --out sent.csv              ESTABLISHED flow: fixed source port, constant rate
Senders stop at --until (unix time) and/or after --count packets (at least one is required); they write
kind,dst,sport,seq,send_ts. --count makes a sender independent of when its process actually starts.
All hosts share the kernel clock (network namespaces), so send/receive timestamps are directly comparable.
"""
import argparse
import csv
import os
import signal
import socket
import struct
import sys
import time

HDR = struct.Struct("!cIdH")          # kind ('P' probe / 'S' stream), seq, send_ts, src port (for checking)
PAD = b"\0" * 64


def recv(a):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 << 20)
    s.bind(("0.0.0.0", a.port))
    s.settimeout(0.5)
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["kind", "src", "sport", "seq", "send_ts", "recv_ts"])
        fh.flush()
        if a.ready_file:                       # readiness = socket bound and output file open
            tmp = a.ready_file + ".tmp"
            with open(tmp, "w") as rf:
                rf.write(f"{os.getpid()} {time.time():.6f}\n")
            os.replace(tmp, a.ready_file)
        n = 0
        while time.time() < a.until and (a.expect is None or n < a.expect):
            try:
                data, (src, sport) = s.recvfrom(2048)
            except socket.timeout:
                continue
            t = time.time()
            if len(data) < HDR.size:
                continue
            kind, seq, ts, _ = HDR.unpack_from(data)
            w.writerow([kind.decode(), src, sport, seq, f"{ts:.6f}", f"{t:.6f}"])
            n += 1
            if n % 200 == 0:
                fh.flush()


def _more(a, i) -> bool:
    """Sender loop condition: deadline (if any) not reached and packet budget (if any) not used up."""
    return (a.until is None or time.time() < a.until) and (a.count is None or i < a.count)


def _pace(start, i, rate):
    nxt = start + i / rate
    d = nxt - time.time()
    if d > 0:
        time.sleep(d)


def probes(a):
    dsts = a.dsts.split(",")
    port_lo, port_hi = a.sport_lo, a.sport_hi
    sport = port_lo
    kind = a.kind.encode()
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["kind", "dst", "sport", "seq", "send_ts"])
        start, i = time.time(), 0
        while _more(a, i):
            _pace(start, i, a.rate)
            dst = dsts[i % len(dsts)]
            seq = a.seq_base + i
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", sport))
                ts = time.time()
                s.sendto(HDR.pack(kind, seq, ts, sport) + PAD, (dst, a.port))
                w.writerow([a.kind, dst, sport, seq, f"{ts:.6f}"])
            except OSError as e:
                print(f"probe send error port {sport}: {e}", file=sys.stderr)
            finally:
                s.close()
            sport = port_lo if sport >= port_hi else sport + 1
            i += 1


def stream(a):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", a.sport_lo))
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["kind", "dst", "sport", "seq", "send_ts"])
        start, i = time.time(), 0
        while _more(a, i):
            _pace(start, i, a.rate)
            ts = time.time()
            try:
                s.sendto(HDR.pack(b"S", i, ts, a.sport_lo) + PAD, (a.dst, a.port))
                w.writerow(["S", a.dst, a.sport_lo, i, f"{ts:.6f}"])
            except OSError as e:
                print(f"stream send error: {e}", file=sys.stderr)
            i += 1
            if i % 200 == 0:
                fh.flush()


class _Stop(Exception):
    pass


def _on_term(signum, frame):
    raise _Stop()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["recv", "probes", "stream"])
    ap.add_argument("--port", type=int, default=9000)
    ap.add_argument("--out", required=True)
    ap.add_argument("--until", type=float, default=None, help="stop at this unix time")
    ap.add_argument("--count", type=int, default=None, help="senders: stop after this many packets")
    ap.add_argument("--expect", type=int, default=None, help="recv: exit after this many datagrams")
    ap.add_argument("--ready-file", default=None, help="recv: create this file once the socket is bound")
    ap.add_argument("--dsts", default="")
    ap.add_argument("--dst", default="")
    ap.add_argument("--rate", type=float, default=10.0, help="packets per second")
    ap.add_argument("--sport-lo", type=int, default=20000)
    ap.add_argument("--sport-hi", type=int, default=39999)
    ap.add_argument("--kind", default="P", help="one letter: P background probe, B hand-over burst probe")
    ap.add_argument("--seq-base", type=int, default=0, help="first sequence number (keeps bursts distinguishable)")
    a = ap.parse_args(argv)
    if a.mode == "recv" and a.until is None:
        ap.error("recv needs --until (safety deadline)")
    if a.mode != "recv" and a.until is None and a.count is None:
        ap.error("senders need --until and/or --count")
    signal.signal(signal.SIGTERM, _on_term)      # stop cleanly: the with-blocks flush and close the CSV files
    signal.signal(signal.SIGINT, _on_term)
    try:
        {"recv": recv, "probes": probes, "stream": stream}[a.mode](a)
    except _Stop:
        pass


if __name__ == "__main__":
    main()
