"""GreenPlace emulation controller (Ryu app, OpenFlow 1.3).

One instance of this app runs in each controller process. It
  * on switch connect: requests the MASTER role (so a make-before-break hand-over demotes the old controller),
    installs a table-miss rule (send to controller) and sends a barrier; the barrier reply marks the switch "ready",
  * forwards IPv4 traffic reactively and hop by hop: on a packet-in it installs a 5-tuple flow on that switch only,
    using a precomputed loop-free next-hop table, and sends the packet out,
  * appends timestamped JSON events (features / role / ready / down / heartbeat) to an events file.

Config: JSON file named by the environment variable GP_EMU_CONFIG:
  {"label": "4", "events_path": "...", "routes": {"<dpid>": {"<dst ip>": out_port}},
   "idle_timeout": 5, "hard_timeout": 15, "heartbeat_s": 0.5}

Runs under ryu-manager (Ryu 4.34, Python 3.9 virtualenv); it must not import the greenplace package.
"""
import json
import os
import time

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, DEAD_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from ryu.lib import hub
from ryu.lib.packet import ether_types, ipv4, packet, tcp, udp
from ryu.ofproto import ofproto_v1_3


class GreenPlaceController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(GreenPlaceController, self).__init__(*args, **kwargs)
        with open(os.environ["GP_EMU_CONFIG"]) as fh:
            cfg = json.load(fh)
        self.label = str(cfg["label"])
        self.routes = {int(k): v for k, v in cfg["routes"].items()}
        self.idle = int(cfg.get("idle_timeout", 5))
        self.hard = int(cfg.get("hard_timeout", 15))
        self.hb = float(cfg.get("heartbeat_s", 0.5))
        self.fh = open(cfg["events_path"], "a", buffering=1)
        self.counters = {"packet_in": 0, "flow_mod": 0, "no_route": 0, "non_ip": 0}
        self.datapaths = {}
        self._log("start", None, pid=os.getpid())
        hub.spawn(self._heartbeat)

    # ------------------------------------------------------------------ logging
    def _log(self, ev, dpid, **kw):
        rec = {"ts": time.time(), "ctrl": self.label, "ev": ev, "dpid": dpid}
        rec.update(kw)
        self.fh.write(json.dumps(rec) + "\n")

    def _heartbeat(self):
        while True:
            self._log("heartbeat", None, switches=sorted(self.datapaths), **self.counters)
            hub.sleep(self.hb)

    # ------------------------------------------------------------------ connection life cycle
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def on_features(self, ev):
        dp = ev.msg.datapath
        ofp, parser = dp.ofproto, dp.ofproto_parser
        self._log("features", dp.id)
        # MASTER role with a strictly increasing generation id: a newer controller always wins
        gen = int(time.time() * 1e6)
        dp.send_msg(parser.OFPRoleRequest(dp, ofp.OFPCR_ROLE_MASTER, gen))
        miss = parser.OFPFlowMod(dp, priority=0, match=parser.OFPMatch(),
                                 instructions=[parser.OFPInstructionActions(
                                     ofp.OFPIT_APPLY_ACTIONS,
                                     [parser.OFPActionOutput(ofp.OFPP_CONTROLLER, ofp.OFPCML_NO_BUFFER)])])
        dp.send_msg(miss)
        dp.send_msg(parser.OFPBarrierRequest(dp))

    @set_ev_cls(ofp_event.EventOFPRoleReply, MAIN_DISPATCHER)
    def on_role(self, ev):
        self._log("role", ev.msg.datapath.id, role=int(ev.msg.role))

    @set_ev_cls(ofp_event.EventOFPBarrierReply, MAIN_DISPATCHER)
    def on_barrier(self, ev):
        dp = ev.msg.datapath
        if dp.id not in self.datapaths:
            self.datapaths[dp.id] = dp
            self._log("ready", dp.id)

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def on_state(self, ev):
        dp = ev.datapath
        if ev.state == DEAD_DISPATCHER and dp.id is not None:
            self.datapaths.pop(dp.id, None)
            self._log("down", dp.id)

    @set_ev_cls(ofp_event.EventOFPErrorMsg, [CONFIG_DISPATCHER, MAIN_DISPATCHER])
    def on_error(self, ev):
        m = ev.msg
        self._log("of_error", m.datapath.id, type=int(m.type), code=int(m.code))

    # ------------------------------------------------------------------ reactive hop-by-hop forwarding
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def on_packet_in(self, ev):
        msg = ev.msg
        dp = msg.datapath
        ofp, parser = dp.ofproto, dp.ofproto_parser
        self.counters["packet_in"] += 1
        pkt = packet.Packet(msg.data)
        ip = pkt.get_protocol(ipv4.ipv4)
        if ip is None:
            self.counters["non_ip"] += 1
            return
        out_port = self.routes.get(dp.id, {}).get(ip.dst)
        if out_port is None:
            self.counters["no_route"] += 1
            return
        fields = {"eth_type": ether_types.ETH_TYPE_IP, "ipv4_src": ip.src, "ipv4_dst": ip.dst, "ip_proto": ip.proto}
        u, t = pkt.get_protocol(udp.udp), pkt.get_protocol(tcp.tcp)
        if u is not None:
            fields.update(udp_src=u.src_port, udp_dst=u.dst_port)
        elif t is not None:
            fields.update(tcp_src=t.src_port, tcp_dst=t.dst_port)
        actions = [parser.OFPActionOutput(out_port)]
        dp.send_msg(parser.OFPFlowMod(dp, priority=10, match=parser.OFPMatch(**fields),
                                      idle_timeout=self.idle, hard_timeout=self.hard,
                                      instructions=[parser.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]))
        self.counters["flow_mod"] += 1
        dp.send_msg(parser.OFPPacketOut(dp, buffer_id=ofp.OFP_NO_BUFFER, in_port=msg.match["in_port"],
                                        actions=actions, data=msg.data))
