"""Turn GreenPlace's own placement + runtime manager into an emulation action plan.

Nothing here re-implements placement or runtime logic: the pool comes from the same NSGA-II front and
migration-aware pick that `scripts/place_on_topology.py` and the study use (`baselines.nsga2_front` +
`selection.select_migration_aware`), and the per-step awake set / assignment come from
`greenplace.runtime.RuntimeManager.step`, i.e. exactly what the simulator does.

Action order inside a step (mirrors what a real deployment must do):
  1. WAKE controllers that become active (waking is never delayed),
  2. REASSIGN every switch whose controller changes (a migration),
  3. SLEEP controllers that are no longer active, only after they own no switches.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from pathlib import Path

from greenplace import baselines as B
from greenplace.benchmark import BenchConfig, derive_settings
from greenplace.config import DelayConfig, PowerModel, RuntimeConfig
from greenplace.lifecycle import simulate
from greenplace.runtime import RuntimeManager
from greenplace.selection import select_migration_aware
from greenplace.topology import load_zoo_topology
from greenplace.traffic import get_trace


@dataclass
class Step:
    t: int
    load: float
    active: list                  # awake controllers after this step (sorted node ids)
    assignment: dict              # switch -> controller after this step
    wake: list = field(default_factory=list)
    sleep: list = field(default_factory=list)
    reassign: list = field(default_factory=list)   # [(switch, from_controller, to_controller)]
    sim_migrations: int = 0       # what the simulator counted for this step
    feasible: bool = True


@dataclass
class Plan:
    topology: str
    n_switches: int
    n_links: int
    pool: list
    capacity: int
    bound_ms: float
    trace_kind: str
    trace_seed: int
    placement_seed: int
    steps: list
    sim_summary: dict             # greenplace.lifecycle.simulate() on the same pool/trace (SIMULATION numbers)

    def to_dict(self) -> dict:
        d = asdict(self)
        for s in d["steps"]:
            s["assignment"] = {str(k): v for k, v in s["assignment"].items()}
        return d

    @property
    def n_reassignments(self) -> int:
        return sum(len(s.reassign) for s in self.steps if s.t > 0)


def greenplace_pool(g, cfg: BenchConfig | None = None, seed: int = 0):
    """GreenPlace's controller pool for graph g: 3-objective NSGA-II front + migration-aware pick (pool mode)."""
    cfg = cfg or BenchConfig()
    st = derive_settings(g, cfg)
    cap, bound = st["capacity"], st["bound_ms"]
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(bound))
    k_floor = math.ceil(g.number_of_nodes() / cap)
    cover = len(B.greedy_cover(p, 1))
    k_max = min(g.number_of_nodes(), max(k_floor, cover) + cfg.extra_pool)
    front = B.nsga2_front(p, k_floor, k_max, seed, True, cfg.nsga_pop, cfg.nsga_gens)
    pick = select_migration_aware(front, cfg.energy_slack)
    if pick is None:
        raise RuntimeError("GreenPlace found no delay-feasible pool for this topology")
    return sorted(int(c) for c in pick.controllers), p, cap, bound


def build_plan(gml: str | Path, trace_kind: str = "diurnal", trace_seed: int = 0, placement_seed: int = 0,
               pool: list | None = None, cfg: BenchConfig | None = None) -> Plan:
    cfg = cfg or BenchConfig()
    g, meta = load_zoo_topology(gml)
    if pool is None:
        pool, p, cap, bound = greenplace_pool(g, cfg, placement_seed)
    else:
        st = derive_settings(g, cfg)
        cap, bound = st["capacity"], st["bound_ms"]
        p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(bound))
    trace = get_trace(trace_kind, trace_seed, cfg.trace_len)
    rt = RuntimeConfig(controller_capacity=cap, timesteps=len(trace), load_ema_alpha=0.3, min_dwell_steps=2)
    rm = RuntimeManager(p.graph, set(pool), p.power, p.delay_config, rt, delay_engine=p.engine)
    steps, prev_active, prev_assign = [], set(), {}
    for t, load in enumerate(trace):
        r = rm.step(t, float(load))
        active = set(int(c) for c in rm.active)
        assign = {int(k): int(v) for k, v in rm.prev_assignment.items()}
        st_ = Step(t=t, load=float(load), active=sorted(active), assignment=assign,
                   wake=sorted(active - prev_active), sleep=sorted(prev_active - active),
                   reassign=[(u, prev_assign.get(u), c) for u, c in sorted(assign.items()) if prev_assign.get(u) != c],
                   sim_migrations=int(r.migrations), feasible=bool(r.feasible))
        steps.append(st_)
        prev_active, prev_assign = active, assign
    sim = simulate(p, set(pool), cap, trace)
    return Plan(topology=meta["name"], n_switches=meta["n"], n_links=meta["m"], pool=list(pool), capacity=cap,
                bound_ms=float(bound), trace_kind=trace_kind, trace_seed=trace_seed, placement_seed=placement_seed,
                steps=steps, sim_summary={k: float(v) for k, v in sim.items()})


def validate_plan(plan: Plan) -> list[str]:
    """Consistency checks between the plan and the simulator; returns a list of problems (empty = OK)."""
    errs = []
    owners = {}
    for s in plan.steps:
        if set(s.assignment.values()) - set(s.active):
            errs.append(f"t={s.t}: a switch is assigned to a sleeping controller")
        if len(s.assignment) != plan.n_switches:
            errs.append(f"t={s.t}: {len(s.assignment)} switches assigned, expected {plan.n_switches}")
        moved = len(s.reassign) if s.t > 0 else 0
        if moved != s.sim_migrations:
            errs.append(f"t={s.t}: plan moves {moved} switches, simulator counted {s.sim_migrations}")
        for c in s.sleep:
            if c in s.assignment.values():
                errs.append(f"t={s.t}: controller {c} put to sleep while still owning switches")
        owners = s.assignment
    total = plan.n_reassignments
    if abs(total - plan.sim_summary["migrations"]) > 1e-9:
        errs.append(f"plan has {total} reassignments, simulator reports {plan.sim_summary['migrations']}")
    return errs
