# GreenPlace study v3 - results summary (auto-generated)

46 Topology Zoo networks, 10 seeds, 8 traffic scenarios. Unit of analysis = topology (seed means); Holm-adjusted p within families.

## Static placement: gap to the MIP lower bound (free-assignment optimum)

| method | mean gap % | median % | reaches bound | infeasible nets |
|---|---|---|---|---|
| exact_mip | 0.7 | 0.0 | 26/46 | 0 |
| ga_energy | 1.8 | 1.1 | 9/46 | 3 |
| greenplace_energypick | 3.5 | 1.3 | 7/46 | 0 |
| nsga3 | 3.6 | 1.5 | 10/46 | 0 |
| nsga2_2obj | 4.2 | 1.8 | 7/46 | 0 |
| nsga2_2obj_migsel | 5.6 | 3.0 | 7/46 | 0 |
| nsga3_migsel | 7.4 | 4.4 | 5/46 | 0 |
| greenplace | 7.4 | 4.1 | 3/46 | 0 |
| k_center | 11.7 | 8.9 | 5/46 | 0 |
| greedy_cover | 11.8 | 9.1 | 6/46 | 0 |
| random | 13.7 | 8.8 | 4/46 | 0 |
| enplace | 13.8 | 3.1 | 17/46 | 0 |
| k_median | 15.0 | 7.5 | 15/46 | 0 |
| mopso | 34.3 | 29.3 | 2/46 | 0 |
| greco | 39.7 | 29.8 | 0/46 | 0 |
| betweenness | 169.2 | 110.9 | 5/46 | 0 |

## Lifecycle (diurnal scenario, shared runtime manager)

| method | energy W | migrations | state changes | saving vs always-on % | delay violations |
|---|---|---|---|---|---|
| simnsga | 951.9 | 4.9 | 3.3 | 8.4 | 0.0 |
| simnsga_sil | 870.5 | 27.8 | 8.4 | 13.9 | 0.0 |
| greenplace | 935.9 | 39.3 | 9.0 | 12.3 | 0.0 |
| greco | 1084.3 | 39.5 | 7.7 | 8.1 | 0.0 |
| nsga3_migsel | 934.0 | 42.1 | 9.4 | 12.3 | 0.0 |
| greenplace_sil | 921.8 | 42.3 | 9.6 | 13.3 | 0.0 |
| k_center | 959.9 | 46.6 | 8.4 | 10.2 | 0.0 |
| greenplace_energypick | 930.1 | 51.2 | 9.3 | 11.4 | 0.0 |
| nsga2_2obj_migsel | 940.2 | 53.7 | 10.1 | 11.9 | 0.0 |
| nsga2_2obj | 933.9 | 55.8 | 9.5 | 11.0 | 0.0 |
| random | 963.5 | 55.9 | 10.4 | 13.8 | 0.0 |
| nsga3 | 929.7 | 55.9 | 9.7 | 11.5 | 0.0 |
| exact_mip | 934.3 | 58.0 | 9.2 | 10.8 | 0.0 |
| k_median | 951.6 | 59.7 | 11.1 | 11.7 | 0.0 |
| ga_energy | 926.2 | 61.4 | 10.1 | 11.4 | 0.0 |
| enplace | 942.5 | 67.0 | 11.4 | 11.8 | 0.0 |
| mopso | 986.8 | 67.9 | 13.7 | 15.5 | 0.0 |
| greedy_cover | 942.9 | 69.1 | 11.3 | 12.1 | 0.0 |
| betweenness | 1028.6 | 162.9 | 87.3 | 50.9 | 0.0 |

## GreenPlace vs baselines - migrations (negative = fewer for GreenPlace)

| baseline | mean % [95% CI] | median % | fewer/tie/more | Holm p | Cliff's delta |
|---|---|---|---|---|---|
| nsga2_2obj | -23.0 [-31.7, -13.9] | -19.8 | 33/2/11 | <0.001 | -0.22 |
| exact_mip | -12.3 [-25.6, 2.2] | -10.2 | 28/2/16 | 0.016 | -0.14 |
| nsga3 | -23.3 [-32.5, -14.5] | -18.4 | 33/4/9 | <0.001 | -0.22 |
| mopso | -33.4 [-43.3, -23.4] | -30.2 | 37/0/9 | <0.001 | -0.33 |
| enplace | -17.6 [-35.9, 4.8] | -30.5 | 35/2/9 | <0.001 | -0.29 |
| greedy_cover | -30.3 [-41.2, -19.5] | -29.6 | 32/2/12 | <0.001 | -0.29 |
| greco | 31.0 [-3.3, 78.0] | 0.0 | 21/2/23 | 0.967 | 0.11 |
| ga_energy | -25.7 [-34.7, -16.5] | -26.7 | 38/1/7 | <0.001 | -0.24 |
| k_median | -16.6 [-34.8, 5.7] | -28.7 | 34/2/10 | <0.001 | -0.26 |
| k_center | 54.3 [-0.9, 130.6] | -2.0 | 24/3/19 | 0.397 | -0.03 |
| betweenness | -58.0 [-67.0, -48.1] | -66.3 | 41/1/4 | <0.001 | -0.58 |
| random | -25.1 [-35.7, -14.4] | -27.8 | 35/1/10 | <0.001 | -0.20 |

## Traffic scenarios (GreenPlace vs 2-objective NSGA-II, migrations)

| scenario | GreenPlace | NSGA-II | MIP set | GP vs NSGA-II % | Holm p | elastic saving % |
|---|---|---|---|---|---|---|
| diurnal | 39.3 | 55.8 | 58.0 | -23.0 | <0.001 | 12.9 |
| two_peak | 64.1 | 86.0 | 89.4 | -20.2 | <0.001 | 12.9 |
| flash_crowd | 43.3 | 62.2 | 65.3 | -23.6 | <0.001 | 11.9 |
| bursty | 95.1 | 120.2 | 121.7 | -18.1 | <0.001 | 15.9 |
| trend | 38.0 | 57.7 | 63.7 | -23.5 | <0.001 | 10.5 |
| noisy | 86.4 | 118.0 | 124.1 | -22.6 | <0.001 | 12.7 |
| geant | 13.1 | 19.7 | 21.3 | -23.3 | <0.001 | 6.4 |
| abilene | 17.7 | 22.0 | 22.2 | -5.3 | 0.002 | 20.2 |

## Front quality (pool mode)

| algo | hypervolume | IGD | front size |
|---|---|---|---|
| greenplace | 0.960 | 0.053 | 13.1 |
| mopso | 0.564 | 0.343 | 11.4 |
| nsga2_2obj | 0.717 | 0.206 | 9.3 |
| nsga3 | 0.941 | 0.083 | 13.4 |

## Selection rules (candidate table)

| rule | migrations diurnal | migrations unseen | energy diurnal W |
|---|---|---|---|
| min_energy | 51.1 | 65.7 | 930.1 |
| proxy | 39.3 | 51.3 | 935.8 |
| sil | 42.3 | 54.7 | 921.8 |
| surrogate | 47.3 | 60.0 | 935.8 |
| oracle | 42.1 | 55.7 | 921.6 |
| random | 61.2 | 76.1 | 960.5 |

Proxy-vs-realised Spearman rho = 0.21 (CI [0.09, 0.31]).

## Scale study (gap to MIP lower bound, %)

| network | n | MIP status | MIP s | MIP set | NSGA-II | GreenPlace | EnPlace-style |
|---|---|---|---|---|---|---|---|
| Interoute | 90 | Optimal | 1.8 | 6.1 | 15.0 | 21.1 | 5.3 |
| Deltacom | 99 | Optimal | 0.7 | 2.1 | 10.0 | 20.9 | 7.8 |
| syn100 | 100 | Optimal | 0.6 | 0.4 | 5.7 | 16.3 | 16.2 |
| Pern | 127 | Optimal | 0.9 | 0.0 | 21.6 | 35.0 | 0.0 |
| Colt | 146 | Optimal | 1.6 | 16.4 | 22.2 | 25.8 | 10.1 |
| Cogentco | 180 | Optimal | 2.6 | 2.1 | 19.3 | 18.4 | 4.2 |
| syn200 | 200 | Optimal | 2.9 | 0.5 | 25.8 | 44.7 | 78.8 |
| syn300 | 300 | Optimal | 17.2 | 0.3 | 42.0 | 63.2 | 99.2 |
| syn400 | 400 | Optimal | 35.8 | 0.2 | 66.4 | 88.2 | 123.3 |
| Kdl | 709 | Feasible (time limit) | 155.6 | 63.8 | 167.4 | 199.5 | 185.5 |
