# GreenPlace emulation results — session `session_20261031_validation`

**Measurement class: Mininet emulation** (software OpenFlow switches and Ryu controller processes on one host). These are not simulator outputs and not physical-hardware measurements.

Environment: kernel 6.18.44-fc-v185, 2 vCPU (Intel(R) Xeon(R) Processor @ 2.10GHz), virtualization `docker`, Mininet 2.3.0, ovs-vsctl (Open vSwitch) 3.3.9, ryu-manager 4.34, OVS datapath **user**, link delays emulated: **False**, control channel: TCP over loopback 127.0.0.1 (no control-path delay).

## 1. Did the GreenPlace schedule execute?

| Network | Mode | Runs (traces) | Reassignments executed / ready / scheduled (simulator) | Wakes / sleeps | Steps verified | Unhealthy checks | Failures |
|---|---|---|---|---|---|---|---|
| Abilene | bbm | 1 (diurnal:0) | 14 / 14 / 14 (14) | 2 / 2 | 96/96 | 0 | 0 |
| Abilene | mbb | 1 (diurnal:0) | 14 / 14 / 14 (14) | 2 / 2 | 96/96 | 0 | 0 |
| Nsfnet | bbm | 1 (diurnal:0) | 2 / 2 / 2 (2) | 1 / 1 | 96/96 | 0 | 0 |
| Nsfnet | mbb | 1 (diurnal:0) | 2 / 2 / 2 (2) | 1 / 1 | 96/96 | 0 | 0 |

## 2. Switch migration latency (ms, from the reassignment command)

| Network | Mode | n | OpenFlow handshake median [p95, max] | Ready (table-miss + barrier) median [p95, max] | Old session closed median | Controller wake (s) median [max] | Controller sleep (ms) median |
|---|---|---|---|---|---|---|---|
| Abilene | bbm | 14 | 29.1 [46.9, 53.0] | 30.2 [51.3, 53.8] | 18.9 | 0.567 [0.680] | 6.5 |
| Abilene | mbb | 14 | 21.6 [36.4, 50.0] | 24.3 [39.6, 51.8] | 126.8 | 0.373 [0.404] | 2.5 |
| Nsfnet | bbm | 2 | 14.0 [14.9, 14.9] | 15.7 [16.8, 16.9] | 11.5 | 0.496 [0.496] | 2.2 |
| Nsfnet | mbb | 2 | 27.6 [33.6, 34.2] | 36.4 [36.6, 36.7] | 53.6 | 0.299 [0.299] | 7.6 |

## 3. Flow-setup disruption and packet loss

New-flow bursts through each migrating switch (every packet is a new 5-tuple that needs a controller decision); phase is relative to that switch's own hand-over: before = sent before the command, during = command to new controller ready (+50 ms), after = later.

| Network | Mode | Before: n / loss % / setup median ms | During: n / loss % / setup median [max] ms | After: n / loss % / setup median ms | Hand-overs with ≥1 lost burst packet |
|---|---|---|---|---|---|
| Abilene | bbm | 364 / 0.82 / 10.8 | 42 / 21.43 / 12.1 [45.0] | 246 / 0.00 / 7.5 | 9 / 14 |
| Abilene | mbb | 300 / 0.33 / 7.3 | 56 / 5.36 / 10.9 [22.6] | 303 / 0.00 / 7.1 | 3 / 14 |
| Nsfnet | bbm | 51 / 0.00 / 7.4 | 6 / 33.33 / 3.7 [5.4] | 41 / 0.00 / 4.8 | 2 / 2 |
| Nsfnet | mbb | 42 / 0.00 / 6.3 | 9 / 11.11 / 5.2 [19.3] | 48 / 0.00 / 4.9 | 1 / 2 |

Background new-flow probes (5/s per host, all host pairs) and established UDP streams (100 pkt/s, paths through the most-migrated switches):

| Network | Mode | Baseline probes: n / loss % / setup median ms | Probes inside a window: n / loss % | Stream packets sent / lost / lost inside windows | Longest stream gap, whole run, any cause (ms) |
|---|---|---|---|---|---|
| Abilene | bbm | 1713 / 0.00 / 8.9 | 21 / 4.8 | 12814 / 0 / 0 | 97.6 |
| Abilene | mbb | 1718 / 0.00 / 9.8 | 13 / 0.0 | 12802 / 0 / 0 | 46.4 |
| Nsfnet | bbm | 2216 / 0.00 / 11.3 | 0 / – | 3514 / 0 / 0 | 28.9 |
| Nsfnet | mbb | 2213 / 0.00 / 10.4 | 0 / – | 3512 / 0 / 0 | 29.9 |

Established-stream pauses above 50 ms (`python -m emulation.stream_gaps`, details in `stream_gaps.csv`): 5 pauses in 1 run; 5 started at the sender (the send timestamps show the same pause); none was a delay in transit; none overlapped a hand-over of a switch on the stream's path; packets lost inside pauses: 0.

## 4. Controller CPU and memory (psutil; % of one core)

| Network | Mode | Controller CPU mean of process means [max] | Mean in the 1 s after an action | Peak sample | Peak RSS (MB) | ovs-vswitchd CPU mean |
|---|---|---|---|---|---|---|
| Abilene | bbm | 6.0 [9.9] | 13.3 | 65.9 | 48.9 | 80.3 |
| Abilene | mbb | 5.4 [9.1] | 11.6 | 80.4 | 48.7 | 74.6 |
| Nsfnet | bbm | 3.4 [7.9] | 6.8 | 98.8 | 48.6 | 53.0 |
| Nsfnet | mbb | 3.2 [7.4] | 7.7 | 66.1 | 48.8 | 54.6 |

## 5. Power

**Not measured.** no /sys/class/powercap/intel-rapl:* domains (VM, non-Intel/AMD-RAPL CPU, or powercap driver not loaded). No power figure is reported or estimated from these runs.
