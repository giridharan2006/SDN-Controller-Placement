# GreenPlace emulation results — session `session_20261031`

**Measurement class: Mininet emulation** (software OpenFlow switches and Ryu controller processes on one host). These are not simulator outputs and not physical-hardware measurements.

Environment: kernel 6.18.44-fc-v185, 2 vCPU (Intel(R) Xeon(R) Processor @ 2.10GHz), virtualization `docker`, Mininet 2.3.0, ovs-vsctl (Open vSwitch) 3.3.9, ryu-manager 4.34, OVS datapath **user**, link delays emulated: **False**, control channel: TCP over loopback 127.0.0.1 (no control-path delay).

## 1. Did the GreenPlace schedule execute?

| Network | Mode | Runs (traces) | Reassignments executed / ready / scheduled (simulator) | Wakes / sleeps | Steps verified | Unhealthy checks | Failures |
|---|---|---|---|---|---|---|---|
| Abilene | bbm | 4 (bursty:0 diurnal:0 diurnal:1 noisy:0) | 90 / 90 / 90 (90) | 13 / 13 | 384/384 | 0 | 0 |
| Abilene | mbb | 4 (bursty:0 diurnal:0 diurnal:1 noisy:0) | 90 / 90 / 90 (90) | 13 / 13 | 384/384 | 0 | 0 |
| Nsfnet | bbm | 4 (bursty:0 diurnal:0 diurnal:1 noisy:0) | 16 / 16 / 16 (16) | 8 / 8 | 384/384 | 0 | 0 |
| Nsfnet | mbb | 4 (bursty:0 diurnal:0 diurnal:1 noisy:0) | 16 / 16 / 16 (16) | 8 / 8 | 384/384 | 0 | 0 |

## 2. Switch migration latency (ms, from the reassignment command)

| Network | Mode | n | OpenFlow handshake median [p95, max] | Ready (table-miss + barrier) median [p95, max] | Old session closed median | Controller wake (s) median [max] | Controller sleep (ms) median |
|---|---|---|---|---|---|---|---|
| Abilene | bbm | 90 | 25.0 [48.5, 52.9] | 28.3 [52.6, 59.0] | 17.8 | 0.508 [0.622] | 5.2 |
| Abilene | mbb | 90 | 24.7 [41.8, 54.2] | 28.4 [51.0, 61.4] | 116.1 | 0.417 [0.640] | 6.2 |
| Nsfnet | bbm | 16 | 20.1 [28.1, 28.4] | 22.1 [32.3, 33.8] | 13.5 | 0.349 [0.480] | 4.7 |
| Nsfnet | mbb | 16 | 21.6 [37.3, 40.0] | 23.6 [41.0, 47.8] | 44.5 | 0.351 [0.405] | 3.4 |

## 3. Flow-setup disruption and packet loss

New-flow bursts through each migrating switch (every packet is a new 5-tuple that needs a controller decision); phase is relative to that switch's own hand-over: before = sent before the command, during = command to new controller ready (+50 ms), after = later.

| Network | Mode | Before: n / loss % / setup median ms | During: n / loss % / setup median [max] ms | After: n / loss % / setup median ms | Hand-overs with ≥1 lost burst packet |
|---|---|---|---|---|---|
| Abilene | bbm | 2188 / 0.46 / 8.9 | 352 / 18.47 / 9.9 [46.5] | 1655 / 0.00 / 6.9 | 59 / 90 |
| Abilene | mbb | 2018 / 0.45 / 8.6 | 353 / 4.25 / 12.0 [60.6] | 1818 / 0.00 / 7.5 | 15 / 90 |
| Nsfnet | bbm | 358 / 0.00 / 6.0 | 59 / 13.56 / 7.0 [27.9] | 374 / 0.00 / 5.6 | 7 / 16 |
| Nsfnet | mbb | 358 / 0.00 / 6.1 | 64 / 4.69 / 7.3 [26.9] | 370 / 0.00 / 5.2 | 3 / 16 |

Background new-flow probes (5/s per host, all host pairs) and established UDP streams (100 pkt/s, paths through the most-migrated switches):

| Network | Mode | Baseline probes: n / loss % / setup median ms | Probes inside a window: n / loss % | Stream packets sent / lost / lost inside windows | Longest stream gap, whole run, any cause (ms) |
|---|---|---|---|---|---|
| Abilene | bbm | 7473 / 0.00 / 10.0 | 92 / 19.6 | 62474 / 0 / 0 | 190.1 |
| Abilene | mbb | 7445 / 0.00 / 8.8 | 107 / 5.6 | 62412 / 0 / 0 | 58.8 |
| Nsfnet | bbm | 10505 / 0.00 / 9.0 | 16 / 0.0 | 17062 / 0 / 0 | 172.6 |
| Nsfnet | mbb | 10477 / 0.00 / 9.5 | 25 / 4.0 | 17036 / 0 / 0 | 93.9 |

Established-stream pauses above 50 ms (`python -m emulation.stream_gaps`, details in `stream_gaps.csv`): 45 pauses in 8 runs; 26 started at the sender (the send timestamps show the same pause); 19 were delays in transit of 41.1–106.4 ms; 10 overlapped a hand-over of a switch on the stream's path (5 runs, longest 93.9 ms); packets lost inside pauses: 0.

## 4. Controller CPU and memory (psutil; % of one core)

| Network | Mode | Controller CPU mean of process means [max] | Mean in the 1 s after an action | Peak sample | Peak RSS (MB) | ovs-vswitchd CPU mean |
|---|---|---|---|---|---|---|
| Abilene | bbm | 5.6 [9.9] | 12.5 | 100.3 | 49.0 | 74.8 |
| Abilene | mbb | 5.7 [10.3] | 11.3 | 101.0 | 49.0 | 78.7 |
| Nsfnet | bbm | 3.4 [8.0] | 7.1 | 100.8 | 48.7 | 73.2 |
| Nsfnet | mbb | 3.4 [8.5] | 7.2 | 101.1 | 48.7 | 68.5 |

## 5. Power

**Not measured.** no /sys/class/powercap/intel-rapl:* domains (VM, non-Intel/AMD-RAPL CPU, or powercap driver not loaded). No power figure is reported or estimated from these runs.
