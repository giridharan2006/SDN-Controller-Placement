# Sensitivity grid: where do GreenPlace's advantages hold?

Each row is one (capacity, delay-bound) setting on the same ~10 real topologies (3 seeds, NSGA-II pop 30 x 40 generations). Larger C=n/k divisor = smaller controllers = more peak-load pool needed = more elastic headroom. p-values are uncorrected (9 settings; treat as descriptive).

| capacity C=n/ | delay bound (x diam) | topologies | elastic headroom (K-cover, mean) | runtime saves vs always-on (%) | GP migr. | 2-obj migr. | GP fewer/tie/more vs 2-obj | Wilcoxon p | energy: GP / exact |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 0.250 | 10 | -0.100 | 5.718 | 4.400 | 7.233 | 3/5/2 | 0.438 | 1.009 |
| 4 | 0.350 | 10 | 0.800 | 10.176 | 12.700 | 23.567 | 8/2/0 | 0.008 | 1.003 |
| 4 | 0.500 | 10 | 2.000 | 12.236 | 38.900 | 57.000 | 9/0/1 | 0.004 | 1.022 |
| 6 | 0.250 | 10 | 1.400 | 11.379 | 20.433 | 22.567 | 5/1/4 | 0.496 | 1.005 |
| 6 | 0.350 | 10 | 2.300 | 15.485 | 42.800 | 53.800 | 7/1/2 | 0.074 | 1.013 |
| 6 | 0.500 | 10 | 3.500 | 19.683 | 90.733 | 98.100 | 6/0/4 | 0.492 | 1.008 |
| 8 | 0.250 | 10 | 3.200 | 16.396 | 43.033 | 47.167 | 4/1/5 | 0.734 | 1.000 |
| 8 | 0.350 | 10 | 4.100 | 19.958 | 74.233 | 85.900 | 6/1/3 | 0.164 | 1.008 |
| 8 | 0.500 | 10 | 5.300 | 25.246 | 113.067 | 136.500 | 6/1/3 | 0.055 | 0.986 |
