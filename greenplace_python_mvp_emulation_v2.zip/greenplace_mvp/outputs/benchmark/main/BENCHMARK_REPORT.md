# GreenPlace benchmark report  (tag: `main`)

**46 real-world topologies** from the Internet Topology Zoo (11-60 nodes; 37 with geographic link delays, the rest hop-count), 3 random seeds per stochastic method, 96-step diurnal trace.

## What is compared, and how

All methods solve the same problem on the same graph: hard delay bound D = 0.35 x delay-diameter, per-controller capacity C = ceil(n/6), identical power model. **Baselines are our re-implementations of the algorithmic ideas behind existing work, not the original authors' code** (see `greenplace/baselines.py`); the study shows how the GreenPlace *approach* fares against those *approaches* on a common footing, not that it beats any paper's published numbers. Settings were fixed before the full run; a sensitivity grid is reported separately.

Two evaluations:

1. **Static placement quality** - minimise energy subject to the delay bound (what most placement papers measure).
2. **Lifecycle** - each method supplies a controller pool sized for peak load; the *same* runtime elastic manager then operates every pool over a diurnal trace. Differences are attributable to placement quality, not to who has a runtime phase.

## 1. Static placement quality

| Method | Always delay-feasible | Mean gap to exact (%) | Median gap (%) | Matches exact (<=0.5%) | Mean #controllers | Mean runtime (s) |
|---|---|---|---|---|---|---|
| Random feasible | 46/46 | 13.28 | 8.34 | 11/46 | 4.03 | 0.04 |
| k-center (Heller-style) | 46/46 | 10.94 | 8.49 | 8/46 | 3.74 | 0.07 |
| k-median (Heller-style) | 46/46 | 14.10 | 5.07 | 17/46 | 4.26 | 0.05 |
| Greedy cover (min #controllers) | 46/46 | 10.96 | 9.05 | 6/46 | 3.57 | 0.00 |
| Betweenness centrality | 46/46 | 167.46 | 109.60 | 5/46 | 12.80 | 0.07 |
| GreCo-style consolidation | 46/46 | 38.69 | 27.89 | 0/46 | 5.26 | 0.00 |
| Single-objective GA (EHACP-GA-style) | 43/46 | 0.79 | 0.00 | 21/46 | 3.17 | 0.37 |
| Exact MIP (Kondo-style) | 46/46 | 0.00 | 0.00 | 46/46 | 3.30 | 0.13 |
| NSGA-II energy+delay (Jalili-style) | 46/46 | 4.22 | 0.73 | 17/46 | 3.59 | 1.68 |
| CONTROL: 2-obj NSGA-II + migration-aware pick | 46/46 | 5.61 | 1.61 | 16/46 | 3.72 | 1.73 |
| GreenPlace (3-obj NSGA-II) | 46/46 | 6.42 | 3.21 | 12/46 | 3.77 | 1.78 |

![](figures/static_gap.png)

## 2. Lifecycle comparison (same runtime manager for every method)

| Method | Lifecycle energy vs GreenPlace (geo-mean ratio) | 95% CI | Mean migrations | Mean state changes | Delay violations (total steps) | As-published static energy vs GreenPlace lifecycle |
|---|---|---|---|---|---|---|
| Random feasible | 1.027 | [1.012, 1.043] | 55.464 | 6.370 | 0 | 1.191 |
| k-center (Heller-style) | 1.025 | [1.011, 1.041] | 44.899 | 5.543 | 0 | 1.153 |
| k-median (Heller-style) | 1.016 | [0.999, 1.035] | 56.232 | 6.906 | 0 | 1.159 |
| Greedy cover (min #controllers) | 1.006 | [0.992, 1.021] | 65.739 | 7.043 | 0 | 1.157 |
| Betweenness centrality | 1.083 | [1.050, 1.119] | 151.377 | 9.848 | 0 | 1.884 |
| GreCo-style consolidation | 1.114 | [1.066, 1.175] | 37.580 | 5.109 | 0 | 1.235 |
| Single-objective GA (EHACP-GA-style) | 0.993 | [0.984, 1.003] | 59.225 | 6.399 | 0 | 1.129 |
| Exact MIP (Kondo-style) | 1.000 | [0.988, 1.013] | 55.022 | 5.826 | 0 | 1.133 |
| NSGA-II energy+delay (Jalili-style) | 0.998 | [0.989, 1.007] | 53.746 | 6.181 | 0 | 1.132 |
| CONTROL: 2-obj NSGA-II + migration-aware pick | 1.005 | [0.996, 1.016] | 50.130 | 6.130 | 0 | 1.152 |
| GreenPlace (3-obj NSGA-II) | 1.000 | [1.000, 1.000] | 39.754 | 5.674 | 0 | 1.152 |
| CONTROL: 2-obj NSGA-II + simulation pick | 0.992 | [0.984, 1.000] | 50.014 | 6.261 | 0 | 1.143 |
| GreenPlace-SIL (simulation-in-the-loop) | 0.984 | [0.978, 0.990] | 40.225 | 5.891 | 0 | 1.150 |

![](figures/lifecycle_comparison.png)

*'As-published static energy vs GreenPlace lifecycle'* = the energy that method's pool would draw if operated always-on (how pure-placement work is deployed) divided by GreenPlace's lifecycle energy. Part of that gap is simply the runtime phase, which the other methods lack in their published form; column 'Lifecycle energy vs GreenPlace' is the like-for-like comparison.

## 3. Paired comparison: GreenPlace vs each baseline (across topologies)

| Baseline | Energy: GP better / tie / worse | Holm p (energy) | Migrations: GP fewer / tie / more | Median migr. diff (baseline-GP) | Holm p (migr.) |
|---|---|---|---|---|---|
| Random feasible | 25 / 11 / 10 | 0.0225 | 31 / 0 / 15 | 6.5000 | 0.0391 |
| k-center (Heller-style) | 26 / 8 / 12 | 0.0403 | 22 / 3 / 21 | 0.0000 | 1.0000 |
| k-median (Heller-style) | 18 / 9 / 19 | 1.0000 | 32 / 2 / 12 | 12.5000 | 0.0019 |
| Greedy cover (min #controllers) | 21 / 6 / 19 | 1.0000 | 33 / 1 / 12 | 13.1667 | 0.0007 |
| Betweenness centrality | 32 / 3 / 11 | 0.0003 | 40 / 1 / 5 | 61.5000 | 0.0000 |
| GreCo-style consolidation | 34 / 7 / 5 | 0.0000 | 22 / 3 / 21 | 0.0000 | 1.0000 |
| Single-objective GA (EHACP-GA-style) | 13 / 7 / 26 | 0.3966 | 33 / 2 / 11 | 6.3333 | 0.0012 |
| Exact MIP (Kondo-style) | 16 / 7 / 23 | 1.0000 | 28 / 3 / 15 | 3.6667 | 0.0599 |
| NSGA-II energy+delay (Jalili-style) | 14 / 12 / 20 | 1.0000 | 31 / 3 / 12 | 7.3333 | 0.0072 |
| CONTROL: 2-obj NSGA-II + migration-aware pick | 16 / 12 / 18 | 1.0000 | 29 / 7 / 10 | 6.3333 | 0.0072 |
| CONTROL: 2-obj NSGA-II + simulation pick | 10 / 11 / 25 | 0.1017 | 28 / 3 / 15 | 4.3333 | 0.0402 |
| GreenPlace-SIL (simulation-in-the-loop) | 5 / 15 / 26 | 0.0003 | 15 / 10 / 21 | 0.0000 | 1.0000 |

![](figures/migrations_scatter.png)

## 4. Pareto view: which methods are non-dominated in (lifecycle energy, migrations)?

| Method | Topologies where method is Pareto-optimal (energy, migrations) |
|---|---|
| Random feasible | 6/46 |
| k-center (Heller-style) | 17/46 |
| k-median (Heller-style) | 10/46 |
| Greedy cover (min #controllers) | 10/46 |
| Betweenness centrality | 8/46 |
| GreCo-style consolidation | 13/46 |
| Single-objective GA (EHACP-GA-style) | 7/46 |
| Exact MIP (Kondo-style) | 14/46 |
| NSGA-II energy+delay (Jalili-style) | 9/46 |
| CONTROL: 2-obj NSGA-II + migration-aware pick | 10/46 |
| GreenPlace (3-obj NSGA-II) | 19/46 |
| CONTROL: 2-obj NSGA-II + simulation pick | 15/46 |
| GreenPlace-SIL (simulation-in-the-loop) | 31/46 |

## 5. Does the migration-burden objective actually predict runtime migrations?

Mean within-topology Spearman correlation between a pool's offline migration burden and its realised runtime migrations: **0.26** (95% CI [0.13, 0.38], 36 topologies with variation).

## 5b. Control: is it the 3-objective *search*, or just the migration-aware *pick*?

`CONTROL` runs the plain 2-objective NSGA-II (same seeds, so identical fronts to the energy+delay baseline) and then applies GreenPlace's migration-aware selection rule. If GreenPlace's gain were only due to the pick rule, the control would match it.

Mean migrations: energy+delay baseline **53.7**, control **50.1**, GreenPlace **39.8**. GreenPlace fewer/tie/more migrations than the control: 29 / 7 / 10 (Wilcoxon p = 0.001, uncorrected). Mean lifecycle energy: control 941 W vs GreenPlace 937 W.

## 5c. Improvement experiment: GreenPlace-SIL (simulation-in-the-loop selection)

**Design fixed before the run:** same 3-objective NSGA-II fronts as GreenPlace (identical seeds); candidates = feasible Pareto members within 1.25x the cheapest static energy (max 10); each is simulated through the runtime manager on **2 training traces (seeds 100-101) that are never used for evaluation (seeds 0-2)**; pick = fewest simulated migrations among candidates within 2% of the best simulated lifecycle energy. Hypothesis: fewer migrations than the proxy-pick GreenPlace at <=2% extra energy. Caveat: training and evaluation traces come from the same synthetic generator (different noise draws only), so this does not test robustness to a *different* traffic pattern.

| Compared with | Mean migrations (that / SIL) | SIL fewer / tie / more | Holm p (migr.) | Energy ratio that/SIL (geo-mean) | Holm p (energy) |
|---|---|---|---|---|---|
| GreenPlace (3-obj NSGA-II) | 39.8 / 40.2 | 21 / 10 / 15 | 1.0000 | 1.0159 | 0.0001 |
| CONTROL: 2-obj NSGA-II + simulation pick | 50.0 / 40.2 | 27 / 5 / 14 | 0.0998 | 1.0075 | 0.0895 |
| NSGA-II energy+delay (Jalili-style) | 53.7 / 40.2 | 33 / 3 / 10 | 0.0033 | 1.0138 | 0.0363 |
| Exact MIP (Kondo-style) | 55.0 / 40.2 | 31 / 4 / 11 | 0.0275 | 1.0164 | 0.1128 |
| GreCo-style consolidation | 37.6 / 40.2 | 19 / 4 / 23 | 1.0000 | 1.1314 | 0.0000 |
| k-center (Heller-style) | 44.9 / 40.2 | 21 / 4 / 21 | 1.0000 | 1.0415 | 0.0000 |

**Exploratory (post-hoc, not part of the pre-registered claim) - sensitivity to the energy slack:**

| Variant | Mean migrations | Lifecycle energy vs exact MIP (geo-mean) |
|---|---|---|
| GreenPlace-SIL, slack 0% (exploratory) | 47.978 | 0.980 |
| GreenPlace-SIL, slack 2% (pre-registered) | 40.225 | 0.984 |
| GreenPlace-SIL, slack 5% (exploratory) | 34.036 | 0.992 |

## 6. Runtime hysteresis ablation

Mean migrations with EMA+dwell: **39.8** vs without: **101.1**; controller state changes 5.7 vs 14.2.

## 7. Results by topology size

| Nodes | n topologies | Baseline | GP fewer migrations (of n) | GP more migrations (of n) | Median energy ratio baseline/GP |
|---|---|---|---|---|---|
| 0-20 | 14 | NSGA-II energy+delay (Jalili-style) | 8 | 5 | 1.00 |
| 0-20 | 14 | Exact MIP (Kondo-style) | 7 | 6 | 1.00 |
| 0-20 | 14 | GreCo-style consolidation | 11 | 2 | 1.01 |
| 21-35 | 18 | NSGA-II energy+delay (Jalili-style) | 11 | 5 | 1.00 |
| 21-35 | 18 | Exact MIP (Kondo-style) | 11 | 5 | 1.00 |
| 21-35 | 18 | GreCo-style consolidation | 6 | 10 | 1.09 |
| 36+ | 14 | NSGA-II energy+delay (Jalili-style) | 12 | 2 | 0.98 |
| 36+ | 14 | Exact MIP (Kondo-style) | 10 | 4 | 0.99 |
| 36+ | 14 | GreCo-style consolidation | 5 | 9 | 1.09 |

## 8. Scalability

![](figures/scalability.png)

## Per-topology results (means over seeds)

<details><summary>Show table</summary>

| name | n | method | pool_k | avg_energy_w | migrations | transitions | violations |
|---|---|---|---|---|---|---|---|
| Abilene | 11 | Betweenness centrality | 6.0 | 629.4 | 30.0 | 7.0 | 0.0 |
| Abilene | 11 | Exact MIP (Kondo-style) | 6.0 | 718.5 | 33.0 | 10.3 | 0.0 |
| Abilene | 11 | Single-objective GA (EHACP-GA-style) | 6.0 | 704.5 | 24.0 | 7.7 | 0.0 |
| Abilene | 11 | GreCo-style consolidation | 6.0 | 696.4 | 12.0 | 5.0 | 0.0 |
| Abilene | 11 | Greedy cover (min #controllers) | 6.0 | 631.9 | 34.0 | 7.0 | 0.0 |
| Abilene | 11 | GreenPlace (3-obj NSGA-II) | 6.0 | 716.1 | 47.7 | 10.3 | 0.0 |
| Abilene | 11 | GreenPlace-SIL (simulation-in-the-loop) | 7.0 | 692.7 | 28.7 | 7.0 | 0.0 |
| Abilene | 11 | k-center (Heller-style) | 6.0 | 716.1 | 47.7 | 10.3 | 0.0 |
| Abilene | 11 | k-median (Heller-style) | 6.0 | 716.1 | 47.7 | 10.3 | 0.0 |
| Abilene | 11 | NSGA-II energy+delay (Jalili-style) | 6.0 | 704.1 | 43.7 | 9.3 | 0.0 |
| Abilene | 11 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 704.1 | 43.7 | 9.3 | 0.0 |
| Abilene | 11 | CONTROL: 2-obj NSGA-II + simulation pick | 7.0 | 692.7 | 28.7 | 7.0 | 0.0 |
| Abilene | 11 | Random feasible | 6.0 | 679.1 | 23.0 | 6.0 | 0.0 |
| Arnes | 34 | Betweenness centrality | 6.0 | 944.2 | 64.7 | 8.0 | 0.0 |
| Arnes | 34 | Exact MIP (Kondo-style) | 6.0 | 925.7 | 28.7 | 4.7 | 0.0 |
| Arnes | 34 | Single-objective GA (EHACP-GA-style) | 6.0 | 924.3 | 40.7 | 5.3 | 0.0 |
| Arnes | 34 | GreCo-style consolidation | 6.0 | 1047.1 | 38.7 | 7.7 | 0.0 |
| Arnes | 34 | Greedy cover (min #controllers) | 6.0 | 916.0 | 119.7 | 11.3 | 0.0 |
| Arnes | 34 | GreenPlace (3-obj NSGA-II) | 6.0 | 888.5 | 51.0 | 8.0 | 0.0 |
| Arnes | 34 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 877.9 | 57.7 | 7.0 | 0.0 |
| Arnes | 34 | k-center (Heller-style) | 6.0 | 1025.6 | 4.0 | 2.0 | 0.0 |
| Arnes | 34 | k-median (Heller-style) | 6.0 | 911.5 | 64.0 | 10.0 | 0.0 |
| Arnes | 34 | NSGA-II energy+delay (Jalili-style) | 6.0 | 968.5 | 35.3 | 4.7 | 0.0 |
| Arnes | 34 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.7 | 912.9 | 63.3 | 9.0 | 0.0 |
| Arnes | 34 | CONTROL: 2-obj NSGA-II + simulation pick | 6.7 | 912.9 | 63.3 | 9.0 | 0.0 |
| Arnes | 34 | Random feasible | 6.0 | 1006.1 | 38.7 | 6.0 | 0.0 |
| Atmnet | 21 | Betweenness centrality | 6.0 | 812.0 | 72.0 | 9.3 | 0.0 |
| Atmnet | 21 | Exact MIP (Kondo-style) | 6.0 | 788.3 | 68.7 | 11.3 | 0.0 |
| Atmnet | 21 | Single-objective GA (EHACP-GA-style) | 6.0 | 794.4 | 65.0 | 9.3 | 0.0 |
| Atmnet | 21 | GreCo-style consolidation | 6.0 | 772.8 | 20.0 | 5.0 | 0.0 |
| Atmnet | 21 | Greedy cover (min #controllers) | 6.0 | 773.8 | 54.3 | 9.7 | 0.0 |
| Atmnet | 21 | GreenPlace (3-obj NSGA-II) | 6.0 | 771.4 | 36.0 | 7.7 | 0.0 |
| Atmnet | 21 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 763.4 | 42.3 | 8.7 | 0.0 |
| Atmnet | 21 | k-center (Heller-style) | 6.0 | 765.6 | 62.3 | 9.7 | 0.0 |
| Atmnet | 21 | k-median (Heller-style) | 6.0 | 773.0 | 56.0 | 7.7 | 0.0 |
| Atmnet | 21 | NSGA-II energy+delay (Jalili-style) | 6.0 | 777.9 | 63.3 | 10.0 | 0.0 |
| Atmnet | 21 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 801.2 | 49.3 | 11.0 | 0.0 |
| Atmnet | 21 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 781.1 | 58.3 | 11.0 | 0.0 |
| Atmnet | 21 | Random feasible | 6.0 | 774.0 | 49.3 | 8.7 | 0.0 |
| Bellcanada | 48 | Betweenness centrality | 47.0 | 1747.1 | 426.0 | 9.0 | 0.0 |
| Bellcanada | 48 | Exact MIP (Kondo-style) | 6.0 | 1220.9 | 99.3 | 6.7 | 0.0 |
| Bellcanada | 48 | Single-objective GA (EHACP-GA-style) | 6.0 | 1215.5 | 86.3 | 6.0 | 0.0 |
| Bellcanada | 48 | GreCo-style consolidation | 6.0 | 1393.7 | 102.0 | 6.7 | 0.0 |
| Bellcanada | 48 | Greedy cover (min #controllers) | 6.0 | 1346.8 | 152.7 | 7.3 | 0.0 |
| Bellcanada | 48 | GreenPlace (3-obj NSGA-II) | 6.0 | 1232.9 | 88.7 | 6.0 | 0.0 |
| Bellcanada | 48 | GreenPlace-SIL (simulation-in-the-loop) | 6.3 | 1239.7 | 68.0 | 6.7 | 0.0 |
| Bellcanada | 48 | k-center (Heller-style) | 6.0 | 1195.7 | 90.0 | 7.3 | 0.0 |
| Bellcanada | 48 | k-median (Heller-style) | 6.0 | 1211.0 | 78.7 | 6.0 | 0.0 |
| Bellcanada | 48 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1202.2 | 88.0 | 6.3 | 0.0 |
| Bellcanada | 48 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1202.2 | 88.0 | 6.3 | 0.0 |
| Bellcanada | 48 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1191.9 | 71.3 | 5.3 | 0.0 |
| Bellcanada | 48 | Random feasible | 6.0 | 1228.6 | 93.7 | 6.3 | 0.0 |
| Belnet2010 | 19 | Betweenness centrality | 10.0 | 677.0 | 91.0 | 8.7 | 0.0 |
| Belnet2010 | 19 | Exact MIP (Kondo-style) | 5.0 | 660.4 | 94.7 | 11.0 | 0.0 |
| Belnet2010 | 19 | Single-objective GA (EHACP-GA-style) | 5.0 | 711.6 | 66.0 | 9.0 | 0.0 |
| Belnet2010 | 19 | GreCo-style consolidation | 5.0 | 757.9 | 34.7 | 6.0 | 0.0 |
| Belnet2010 | 19 | Greedy cover (min #controllers) | 5.0 | 693.3 | 75.3 | 10.3 | 0.0 |
| Belnet2010 | 19 | GreenPlace (3-obj NSGA-II) | 5.0 | 706.6 | 30.3 | 5.7 | 0.0 |
| Belnet2010 | 19 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 668.9 | 64.7 | 9.0 | 0.0 |
| Belnet2010 | 19 | k-center (Heller-style) | 5.0 | 707.0 | 33.3 | 7.3 | 0.0 |
| Belnet2010 | 19 | k-median (Heller-style) | 5.0 | 675.8 | 82.7 | 11.0 | 0.0 |
| Belnet2010 | 19 | NSGA-II energy+delay (Jalili-style) | 5.0 | 669.3 | 67.0 | 9.0 | 0.0 |
| Belnet2010 | 19 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 706.6 | 30.3 | 5.7 | 0.0 |
| Belnet2010 | 19 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 658.0 | 52.7 | 8.0 | 0.0 |
| Belnet2010 | 19 | Random feasible | 5.0 | 679.8 | 80.7 | 10.0 | 0.0 |
| Bics | 33 | Betweenness centrality | 29.0 | 1272.5 | 322.3 | 15.0 | 0.0 |
| Bics | 33 | Exact MIP (Kondo-style) | 6.0 | 951.4 | 29.0 | 5.7 | 0.0 |
| Bics | 33 | Single-objective GA (EHACP-GA-style) | 6.0 | 952.0 | 34.0 | 5.7 | 0.0 |
| Bics | 33 | GreCo-style consolidation | 6.0 | 1066.0 | 8.0 | 2.0 | 0.0 |
| Bics | 33 | Greedy cover (min #controllers) | 6.0 | 1093.5 | 31.7 | 4.7 | 0.0 |
| Bics | 33 | GreenPlace (3-obj NSGA-II) | 6.0 | 961.4 | 30.0 | 4.7 | 0.0 |
| Bics | 33 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 966.2 | 25.7 | 4.7 | 0.0 |
| Bics | 33 | k-center (Heller-style) | 6.0 | 989.5 | 20.3 | 3.3 | 0.0 |
| Bics | 33 | k-median (Heller-style) | 7.0 | 1064.1 | 72.0 | 9.3 | 0.0 |
| Bics | 33 | NSGA-II energy+delay (Jalili-style) | 6.0 | 973.4 | 42.7 | 6.7 | 0.0 |
| Bics | 33 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 973.4 | 42.7 | 6.7 | 0.0 |
| Bics | 33 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 974.8 | 22.7 | 5.3 | 0.0 |
| Bics | 33 | Random feasible | 6.0 | 1000.3 | 24.3 | 5.3 | 0.0 |
| Biznet | 28 | Betweenness centrality | 27.0 | 1260.7 | 286.0 | 13.3 | 0.0 |
| Biznet | 28 | Exact MIP (Kondo-style) | 6.0 | 970.4 | 112.0 | 8.7 | 0.0 |
| Biznet | 28 | Single-objective GA (EHACP-GA-style) | 6.0 | 967.4 | 114.7 | 8.7 | 0.0 |
| Biznet | 28 | GreCo-style consolidation | 6.0 | 988.3 | 123.7 | 9.3 | 0.0 |
| Biznet | 28 | Greedy cover (min #controllers) | 6.0 | 928.4 | 98.0 | 9.3 | 0.0 |
| Biznet | 28 | GreenPlace (3-obj NSGA-II) | 6.0 | 964.8 | 108.7 | 8.7 | 0.0 |
| Biznet | 28 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 930.5 | 101.7 | 10.7 | 0.0 |
| Biznet | 28 | k-center (Heller-style) | 6.0 | 927.9 | 93.7 | 9.3 | 0.0 |
| Biznet | 28 | k-median (Heller-style) | 6.0 | 928.4 | 98.0 | 9.3 | 0.0 |
| Biznet | 28 | NSGA-II energy+delay (Jalili-style) | 6.0 | 951.6 | 100.7 | 8.7 | 0.0 |
| Biznet | 28 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 951.6 | 100.7 | 8.7 | 0.0 |
| Biznet | 28 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 938.9 | 97.7 | 9.3 | 0.0 |
| Biznet | 28 | Random feasible | 6.0 | 939.6 | 122.0 | 10.7 | 0.0 |
| Cernet | 37 | Betweenness centrality | 28.0 | 1311.7 | 362.7 | 15.0 | 0.0 |
| Cernet | 37 | Exact MIP (Kondo-style) | 6.0 | 1005.3 | 60.7 | 5.0 | 0.0 |
| Cernet | 37 | Single-objective GA (EHACP-GA-style) | 6.0 | 999.9 | 54.0 | 5.0 | 0.0 |
| Cernet | 37 | GreCo-style consolidation | 6.0 | 1037.8 | 22.0 | 5.0 | 0.0 |
| Cernet | 37 | Greedy cover (min #controllers) | 6.0 | 1162.7 | 26.7 | 3.3 | 0.0 |
| Cernet | 37 | GreenPlace (3-obj NSGA-II) | 6.0 | 1039.8 | 37.3 | 4.7 | 0.0 |
| Cernet | 37 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1041.6 | 27.3 | 4.0 | 0.0 |
| Cernet | 37 | k-center (Heller-style) | 6.0 | 1078.6 | 2.0 | 2.0 | 0.0 |
| Cernet | 37 | k-median (Heller-style) | 9.0 | 1222.8 | 139.7 | 13.7 | 0.0 |
| Cernet | 37 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1004.9 | 50.0 | 5.0 | 0.0 |
| Cernet | 37 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1004.9 | 50.0 | 5.0 | 0.0 |
| Cernet | 37 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1004.9 | 50.0 | 5.0 | 0.0 |
| Cernet | 37 | Random feasible | 7.3 | 1216.3 | 40.7 | 6.3 | 0.0 |
| Cesnet201006 | 45 | Betweenness centrality | 6.0 | 968.8 | 68.0 | 8.0 | 0.0 |
| Cesnet201006 | 45 | Exact MIP (Kondo-style) | 6.0 | 976.0 | 60.7 | 8.0 | 0.0 |
| Cesnet201006 | 45 | Single-objective GA (EHACP-GA-style) | 6.0 | 976.0 | 60.7 | 8.0 | 0.0 |
| Cesnet201006 | 45 | GreCo-style consolidation | 7.0 | 1370.0 | 0.0 | 0.0 | 0.0 |
| Cesnet201006 | 45 | Greedy cover (min #controllers) | 6.0 | 974.6 | 70.0 | 8.7 | 0.0 |
| Cesnet201006 | 45 | GreenPlace (3-obj NSGA-II) | 6.0 | 981.8 | 39.0 | 8.0 | 0.0 |
| Cesnet201006 | 45 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 985.1 | 30.0 | 7.3 | 0.0 |
| Cesnet201006 | 45 | k-center (Heller-style) | 6.0 | 975.8 | 72.7 | 8.7 | 0.0 |
| Cesnet201006 | 45 | k-median (Heller-style) | 6.0 | 967.7 | 63.3 | 8.7 | 0.0 |
| Cesnet201006 | 45 | NSGA-II energy+delay (Jalili-style) | 6.0 | 978.3 | 53.7 | 8.7 | 0.0 |
| Cesnet201006 | 45 | CONTROL: 2-obj NSGA-II + migration-aware pick | 7.0 | 1046.5 | 92.7 | 11.0 | 0.0 |
| Cesnet201006 | 45 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 978.3 | 53.7 | 8.7 | 0.0 |
| Cesnet201006 | 45 | Random feasible | 6.3 | 1061.4 | 29.7 | 7.7 | 0.0 |
| Compuserve | 14 | Betweenness centrality | 5.0 | 710.4 | 8.0 | 2.7 | 0.0 |
| Compuserve | 14 | Exact MIP (Kondo-style) | 5.0 | 795.0 | 0.0 | 0.0 | 0.0 |
| Compuserve | 14 | Single-objective GA (EHACP-GA-style) | 5.0 | 738.1 | 2.7 | 2.0 | 0.0 |
| Compuserve | 14 | GreCo-style consolidation | 5.0 | 795.0 | 0.0 | 0.0 | 0.0 |
| Compuserve | 14 | Greedy cover (min #controllers) | 5.0 | 795.0 | 0.0 | 0.0 | 0.0 |
| Compuserve | 14 | GreenPlace (3-obj NSGA-II) | 5.0 | 718.5 | 3.3 | 2.0 | 0.0 |
| Compuserve | 14 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 710.4 | 2.7 | 2.7 | 0.0 |
| Compuserve | 14 | k-center (Heller-style) | 5.0 | 795.0 | 0.0 | 0.0 | 0.0 |
| Compuserve | 14 | k-median (Heller-style) | 5.0 | 795.0 | 0.0 | 0.0 | 0.0 |
| Compuserve | 14 | NSGA-II energy+delay (Jalili-style) | 5.0 | 738.6 | 2.0 | 1.3 | 0.0 |
| Compuserve | 14 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 718.5 | 3.3 | 2.0 | 0.0 |
| Compuserve | 14 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 714.9 | 2.7 | 2.0 | 0.0 |
| Compuserve | 14 | Random feasible | 5.0 | 770.8 | 1.3 | 0.7 | 0.0 |
| Cudi | 51 | Betweenness centrality | 8.0 | 1183.6 | 82.7 | 5.7 | 0.0 |
| Cudi | 51 | Exact MIP (Kondo-style) | 6.0 | 1165.0 | 0.0 | 0.0 | 0.0 |
| Cudi | 51 | Single-objective GA (EHACP-GA-style) | 6.0 | 1089.7 | 23.3 | 3.7 | 0.0 |
| Cudi | 51 | GreCo-style consolidation | 9.0 | 1700.0 | 0.0 | 0.0 | 0.0 |
| Cudi | 51 | Greedy cover (min #controllers) | 6.0 | 1070.4 | 50.0 | 5.7 | 0.0 |
| Cudi | 51 | GreenPlace (3-obj NSGA-II) | 6.0 | 1110.7 | 3.3 | 2.7 | 0.0 |
| Cudi | 51 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1096.0 | 21.3 | 3.7 | 0.0 |
| Cudi | 51 | k-center (Heller-style) | 6.0 | 1165.0 | 0.0 | 0.0 | 0.0 |
| Cudi | 51 | k-median (Heller-style) | 6.0 | 1165.0 | 0.0 | 0.0 | 0.0 |
| Cudi | 51 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1126.6 | 8.7 | 2.0 | 0.0 |
| Cudi | 51 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1126.6 | 9.0 | 2.0 | 0.0 |
| Cudi | 51 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1126.6 | 8.7 | 2.0 | 0.0 |
| Cudi | 51 | Random feasible | 7.7 | 1285.4 | 35.3 | 7.3 | 0.0 |
| Dfn | 51 | Betweenness centrality | 6.0 | 1049.1 | 47.3 | 6.7 | 0.0 |
| Dfn | 51 | Exact MIP (Kondo-style) | 6.0 | 1072.3 | 55.3 | 6.7 | 0.0 |
| Dfn | 51 | Single-objective GA (EHACP-GA-style) | 6.0 | 1063.6 | 16.7 | 3.3 | 0.0 |
| Dfn | 51 | GreCo-style consolidation | 7.0 | 1480.0 | 0.0 | 0.0 | 0.0 |
| Dfn | 51 | Greedy cover (min #controllers) | 6.0 | 1210.7 | 27.3 | 2.7 | 0.0 |
| Dfn | 51 | GreenPlace (3-obj NSGA-II) | 6.3 | 1084.5 | 16.7 | 4.3 | 0.0 |
| Dfn | 51 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1063.0 | 16.3 | 4.3 | 0.0 |
| Dfn | 51 | k-center (Heller-style) | 6.0 | 1240.0 | 18.0 | 2.0 | 0.0 |
| Dfn | 51 | k-median (Heller-style) | 6.0 | 1066.4 | 45.3 | 6.7 | 0.0 |
| Dfn | 51 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1062.4 | 20.7 | 4.3 | 0.0 |
| Dfn | 51 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1066.8 | 25.3 | 4.3 | 0.0 |
| Dfn | 51 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1065.4 | 21.3 | 4.3 | 0.0 |
| Dfn | 51 | Random feasible | 6.7 | 1237.3 | 40.3 | 5.3 | 0.0 |
| Digex | 31 | Betweenness centrality | 31.0 | 1307.3 | 263.0 | 12.3 | 0.0 |
| Digex | 31 | Exact MIP (Kondo-style) | 6.0 | 1131.4 | 24.7 | 2.0 | 0.0 |
| Digex | 31 | Single-objective GA (EHACP-GA-style) | 6.0 | 1090.8 | 135.3 | 8.3 | 0.0 |
| Digex | 31 | GreCo-style consolidation | 6.0 | 1163.1 | 33.7 | 2.0 | 0.0 |
| Digex | 31 | Greedy cover (min #controllers) | 6.0 | 1128.6 | 82.0 | 6.3 | 0.0 |
| Digex | 31 | GreenPlace (3-obj NSGA-II) | 6.0 | 1098.8 | 103.7 | 6.7 | 0.0 |
| Digex | 31 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1091.0 | 69.3 | 6.0 | 0.0 |
| Digex | 31 | k-center (Heller-style) | 6.0 | 1112.8 | 74.7 | 6.3 | 0.0 |
| Digex | 31 | k-median (Heller-style) | 6.0 | 1114.5 | 18.0 | 2.0 | 0.0 |
| Digex | 31 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1121.1 | 17.3 | 2.0 | 0.0 |
| Digex | 31 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1121.1 | 17.3 | 2.0 | 0.0 |
| Digex | 31 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1107.5 | 26.0 | 3.0 | 0.0 |
| Digex | 31 | Random feasible | 6.0 | 1117.8 | 35.0 | 3.7 | 0.0 |
| Ernet | 30 | Betweenness centrality | 6.0 | 843.2 | 40.0 | 5.7 | 0.0 |
| Ernet | 30 | Exact MIP (Kondo-style) | 6.0 | 845.7 | 46.7 | 6.3 | 0.0 |
| Ernet | 30 | Single-objective GA (EHACP-GA-style) | 6.0 | 845.7 | 42.7 | 6.3 | 0.0 |
| Ernet | 30 | GreCo-style consolidation | 6.0 | 1075.0 | 0.0 | 0.0 | 0.0 |
| Ernet | 30 | Greedy cover (min #controllers) | 6.0 | 850.7 | 40.0 | 5.0 | 0.0 |
| Ernet | 30 | GreenPlace (3-obj NSGA-II) | 6.0 | 850.7 | 39.0 | 5.0 | 0.0 |
| Ernet | 30 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 850.7 | 39.0 | 5.0 | 0.0 |
| Ernet | 30 | k-center (Heller-style) | 6.0 | 845.7 | 52.7 | 6.3 | 0.0 |
| Ernet | 30 | k-median (Heller-style) | 6.0 | 851.9 | 48.0 | 5.0 | 0.0 |
| Ernet | 30 | NSGA-II energy+delay (Jalili-style) | 6.0 | 847.0 | 41.3 | 5.0 | 0.0 |
| Ernet | 30 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 850.7 | 39.0 | 5.0 | 0.0 |
| Ernet | 30 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 843.2 | 40.0 | 5.7 | 0.0 |
| Ernet | 30 | Random feasible | 6.0 | 878.6 | 29.3 | 5.0 | 0.0 |
| Funet | 24 | Betweenness centrality | 11.0 | 1026.6 | 134.7 | 12.0 | 0.0 |
| Funet | 24 | Exact MIP (Kondo-style) | 6.0 | 835.6 | 38.0 | 8.0 | 0.0 |
| Funet | 24 | Single-objective GA (EHACP-GA-style) | 6.0 | 837.9 | 36.7 | 8.0 | 0.0 |
| Funet | 24 | GreCo-style consolidation | 6.0 | 864.8 | 53.0 | 8.0 | 0.0 |
| Funet | 24 | Greedy cover (min #controllers) | 6.0 | 816.2 | 45.0 | 9.3 | 0.0 |
| Funet | 24 | GreenPlace (3-obj NSGA-II) | 6.0 | 841.1 | 27.3 | 6.0 | 0.0 |
| Funet | 24 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 830.8 | 33.7 | 8.0 | 0.0 |
| Funet | 24 | k-center (Heller-style) | 6.0 | 845.4 | 32.0 | 8.0 | 0.0 |
| Funet | 24 | k-median (Heller-style) | 6.0 | 840.5 | 68.3 | 10.3 | 0.0 |
| Funet | 24 | NSGA-II energy+delay (Jalili-style) | 6.0 | 841.1 | 66.3 | 10.3 | 0.0 |
| Funet | 24 | CONTROL: 2-obj NSGA-II + migration-aware pick | 7.0 | 903.0 | 69.7 | 9.7 | 0.0 |
| Funet | 24 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 840.3 | 62.7 | 9.7 | 0.0 |
| Funet | 24 | Random feasible | 6.0 | 838.1 | 33.0 | 7.0 | 0.0 |
| Geant2012 | 37 | Betweenness centrality | 27.0 | 1323.6 | 280.0 | 12.3 | 0.0 |
| Geant2012 | 37 | Exact MIP (Kondo-style) | 6.0 | 1140.0 | 0.0 | 0.0 | 0.0 |
| Geant2012 | 37 | Single-objective GA (EHACP-GA-style) | 6.0 | 1120.1 | 3.3 | 0.7 | 0.0 |
| Geant2012 | 37 | GreCo-style consolidation | 7.0 | 1350.0 | 0.0 | 0.0 | 0.0 |
| Geant2012 | 37 | Greedy cover (min #controllers) | 6.0 | 1160.0 | 0.0 | 0.0 | 0.0 |
| Geant2012 | 37 | GreenPlace (3-obj NSGA-II) | 6.0 | 1151.7 | 0.7 | 0.0 | 0.0 |
| Geant2012 | 37 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1158.3 | 0.0 | 0.0 | 0.0 |
| Geant2012 | 37 | k-center (Heller-style) | 6.0 | 1125.0 | 0.0 | 0.0 | 0.0 |
| Geant2012 | 37 | k-median (Heller-style) | 10.0 | 1510.2 | 57.7 | 8.7 | 0.0 |
| Geant2012 | 37 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1135.9 | 7.3 | 0.7 | 0.0 |
| Geant2012 | 37 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1135.9 | 7.3 | 0.7 | 0.0 |
| Geant2012 | 37 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1142.7 | 6.0 | 0.7 | 0.0 |
| Geant2012 | 37 | Random feasible | 8.7 | 1313.9 | 69.0 | 6.0 | 0.0 |
| Grnet | 34 | Betweenness centrality | 9.0 | 1095.3 | 52.3 | 6.0 | 0.0 |
| Grnet | 34 | Exact MIP (Kondo-style) | 6.0 | 1045.0 | 8.0 | 2.0 | 0.0 |
| Grnet | 34 | Single-objective GA (EHACP-GA-style) | 6.0 | 1024.8 | 11.3 | 2.7 | 0.0 |
| Grnet | 34 | GreCo-style consolidation | 8.0 | 1410.4 | 20.7 | 0.0 | 0.0 |
| Grnet | 34 | Greedy cover (min #controllers) | 6.0 | 1063.3 | 28.0 | 4.0 | 0.0 |
| Grnet | 34 | GreenPlace (3-obj NSGA-II) | 6.0 | 987.5 | 7.3 | 2.0 | 0.0 |
| Grnet | 34 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 987.5 | 7.3 | 2.0 | 0.0 |
| Grnet | 34 | k-center (Heller-style) | 6.0 | 1097.5 | 2.0 | 2.0 | 0.0 |
| Grnet | 34 | k-median (Heller-style) | 6.0 | 1035.9 | 21.3 | 3.3 | 0.0 |
| Grnet | 34 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1043.3 | 8.7 | 2.0 | 0.0 |
| Grnet | 34 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.3 | 1035.7 | 14.7 | 3.0 | 0.0 |
| Grnet | 34 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1022.1 | 11.3 | 2.0 | 0.0 |
| Grnet | 34 | Random feasible | 6.0 | 1076.5 | 12.0 | 2.0 | 0.0 |
| Harnet | 21 | Betweenness centrality | 7.0 | 1120.0 | 0.0 | 0.0 | 0.0 |
| Harnet | 21 | Exact MIP (Kondo-style) | 7.0 | 1120.0 | 3.0 | 0.0 | 0.0 |
| Harnet | 21 | Single-objective GA (EHACP-GA-style) | 7.0 | 1120.0 | 4.0 | 0.0 | 0.0 |
| Harnet | 21 | GreCo-style consolidation | 13.0 | 1990.0 | 0.0 | 0.0 | 0.0 |
| Harnet | 21 | Greedy cover (min #controllers) | 7.0 | 1120.0 | 3.0 | 0.0 | 0.0 |
| Harnet | 21 | GreenPlace (3-obj NSGA-II) | 7.7 | 1155.7 | 5.0 | 1.3 | 0.0 |
| Harnet | 21 | GreenPlace-SIL (simulation-in-the-loop) | 7.0 | 1120.0 | 2.0 | 0.0 | 0.0 |
| Harnet | 21 | k-center (Heller-style) | 7.0 | 1120.0 | 1.0 | 0.0 | 0.0 |
| Harnet | 21 | k-median (Heller-style) | 7.0 | 1120.0 | 1.0 | 0.0 | 0.0 |
| Harnet | 21 | NSGA-II energy+delay (Jalili-style) | 7.0 | 1120.0 | 2.7 | 0.0 | 0.0 |
| Harnet | 21 | CONTROL: 2-obj NSGA-II + migration-aware pick | 7.0 | 1120.0 | 3.0 | 0.0 | 0.0 |
| Harnet | 21 | CONTROL: 2-obj NSGA-II + simulation pick | 7.0 | 1120.0 | 1.3 | 0.0 | 0.0 |
| Harnet | 21 | Random feasible | 8.0 | 1173.4 | 4.3 | 1.3 | 0.0 |
| Hibernia | 15 | Betweenness centrality | 14.0 | 811.5 | 164.0 | 16.7 | 0.0 |
| Hibernia | 15 | Exact MIP (Kondo-style) | 5.0 | 679.8 | 92.3 | 16.0 | 0.0 |
| Hibernia | 15 | Single-objective GA (EHACP-GA-style) | 5.0 | 682.5 | 55.0 | 10.3 | 0.0 |
| Hibernia | 15 | GreCo-style consolidation | 5.0 | 679.3 | 71.3 | 12.3 | 0.0 |
| Hibernia | 15 | Greedy cover (min #controllers) | 5.0 | 689.1 | 55.3 | 11.0 | 0.0 |
| Hibernia | 15 | GreenPlace (3-obj NSGA-II) | 5.0 | 681.6 | 53.0 | 10.3 | 0.0 |
| Hibernia | 15 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 681.6 | 53.0 | 10.3 | 0.0 |
| Hibernia | 15 | k-center (Heller-style) | 5.0 | 681.8 | 49.7 | 10.3 | 0.0 |
| Hibernia | 15 | k-median (Heller-style) | 5.0 | 682.2 | 55.7 | 12.3 | 0.0 |
| Hibernia | 15 | NSGA-II energy+delay (Jalili-style) | 5.0 | 680.6 | 64.0 | 12.0 | 0.0 |
| Hibernia | 15 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 680.6 | 64.0 | 12.0 | 0.0 |
| Hibernia | 15 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 680.6 | 64.0 | 12.0 | 0.0 |
| Hibernia | 15 | Random feasible | 5.0 | 681.4 | 59.3 | 11.3 | 0.0 |
| Highwinds | 18 | Betweenness centrality | 9.0 | 837.2 | 71.3 | 13.0 | 0.0 |
| Highwinds | 18 | Exact MIP (Kondo-style) | 6.0 | 788.4 | 20.0 | 5.0 | 0.0 |
| Highwinds | 18 | Single-objective GA (EHACP-GA-style) | 6.0 | 772.5 | 49.3 | 7.7 | 0.0 |
| Highwinds | 18 | GreCo-style consolidation | 6.0 | 786.0 | 44.7 | 8.7 | 0.0 |
| Highwinds | 18 | Greedy cover (min #controllers) | 6.0 | 786.4 | 39.3 | 8.7 | 0.0 |
| Highwinds | 18 | GreenPlace (3-obj NSGA-II) | 6.0 | 776.5 | 26.7 | 5.0 | 0.0 |
| Highwinds | 18 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 776.5 | 26.7 | 5.0 | 0.0 |
| Highwinds | 18 | k-center (Heller-style) | 6.0 | 784.2 | 46.7 | 8.7 | 0.0 |
| Highwinds | 18 | k-median (Heller-style) | 6.0 | 786.4 | 39.3 | 8.7 | 0.0 |
| Highwinds | 18 | NSGA-II energy+delay (Jalili-style) | 6.0 | 775.6 | 38.3 | 6.0 | 0.0 |
| Highwinds | 18 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 775.6 | 38.3 | 6.0 | 0.0 |
| Highwinds | 18 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 778.9 | 32.0 | 6.0 | 0.0 |
| Highwinds | 18 | Random feasible | 6.0 | 777.0 | 45.0 | 7.7 | 0.0 |
| Iinet | 31 | Betweenness centrality | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | Exact MIP (Kondo-style) | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | Single-objective GA (EHACP-GA-style) | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | GreCo-style consolidation | 23.0 | 3490.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | Greedy cover (min #controllers) | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | GreenPlace (3-obj NSGA-II) | 9.0 | 1411.7 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | GreenPlace-SIL (simulation-in-the-loop) | 8.7 | 1363.3 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | k-center (Heller-style) | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | k-median (Heller-style) | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | NSGA-II energy+delay (Jalili-style) | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | CONTROL: 2-obj NSGA-II + migration-aware pick | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | CONTROL: 2-obj NSGA-II + simulation pick | 8.0 | 1315.0 | 0.0 | 0.0 | 0.0 |
| Iinet | 31 | Random feasible | 14.7 | 1472.6 | 6.7 | 2.0 | 0.0 |
| Internet2 | 20 | Betweenness centrality | 8.0 | 853.9 | 30.0 | 5.7 | 0.0 |
| Internet2 | 20 | Exact MIP (Kondo-style) | 5.0 | 830.0 | 0.0 | 0.0 | 0.0 |
| Internet2 | 20 | Single-objective GA (EHACP-GA-style) | 5.0 | 802.5 | 2.0 | 0.7 | 0.0 |
| Internet2 | 20 | GreCo-style consolidation | 5.0 | 779.1 | 16.0 | 2.0 | 0.0 |
| Internet2 | 20 | Greedy cover (min #controllers) | 5.0 | 758.8 | 6.0 | 2.0 | 0.0 |
| Internet2 | 20 | GreenPlace (3-obj NSGA-II) | 5.0 | 747.2 | 4.7 | 2.0 | 0.0 |
| Internet2 | 20 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 747.2 | 4.7 | 2.0 | 0.0 |
| Internet2 | 20 | k-center (Heller-style) | 5.0 | 748.8 | 6.0 | 2.0 | 0.0 |
| Internet2 | 20 | k-median (Heller-style) | 5.0 | 830.0 | 0.0 | 0.0 | 0.0 |
| Internet2 | 20 | NSGA-II energy+delay (Jalili-style) | 5.0 | 802.5 | 4.7 | 0.7 | 0.0 |
| Internet2 | 20 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 802.5 | 4.7 | 0.7 | 0.0 |
| Internet2 | 20 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 802.5 | 1.3 | 0.7 | 0.0 |
| Internet2 | 20 | Random feasible | 5.0 | 783.8 | 8.0 | 1.3 | 0.0 |
| Internetmci | 19 | Betweenness centrality | 8.0 | 709.5 | 52.7 | 8.7 | 0.0 |
| Internetmci | 19 | Exact MIP (Kondo-style) | 5.0 | 652.3 | 23.3 | 4.7 | 0.0 |
| Internetmci | 19 | Single-objective GA (EHACP-GA-style) | 5.0 | 657.9 | 20.0 | 5.3 | 0.0 |
| Internetmci | 19 | GreCo-style consolidation | 5.0 | 693.0 | 18.0 | 5.0 | 0.0 |
| Internetmci | 19 | Greedy cover (min #controllers) | 5.0 | 663.3 | 27.0 | 6.7 | 0.0 |
| Internetmci | 19 | GreenPlace (3-obj NSGA-II) | 5.0 | 665.9 | 13.3 | 4.0 | 0.0 |
| Internetmci | 19 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 651.7 | 18.7 | 4.7 | 0.0 |
| Internetmci | 19 | k-center (Heller-style) | 5.0 | 651.9 | 17.3 | 4.7 | 0.0 |
| Internetmci | 19 | k-median (Heller-style) | 5.0 | 645.2 | 24.0 | 6.7 | 0.0 |
| Internetmci | 19 | NSGA-II energy+delay (Jalili-style) | 5.0 | 654.7 | 19.3 | 5.3 | 0.0 |
| Internetmci | 19 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 654.7 | 19.3 | 5.3 | 0.0 |
| Internetmci | 19 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 657.0 | 17.3 | 4.7 | 0.0 |
| Internetmci | 19 | Random feasible | 5.0 | 661.3 | 39.3 | 6.7 | 0.0 |
| Iris | 51 | Betweenness centrality | 9.0 | 1193.1 | 198.7 | 8.7 | 0.0 |
| Iris | 51 | Exact MIP (Kondo-style) | 6.0 | 1160.2 | 238.0 | 14.0 | 0.0 |
| Iris | 51 | Single-objective GA (EHACP-GA-style) | 6.0 | 1198.2 | 144.0 | 8.7 | 0.0 |
| Iris | 51 | GreCo-style consolidation | 6.0 | 1268.1 | 32.0 | 5.0 | 0.0 |
| Iris | 51 | Greedy cover (min #controllers) | 6.0 | 1242.5 | 185.7 | 9.7 | 0.0 |
| Iris | 51 | GreenPlace (3-obj NSGA-II) | 6.0 | 1294.2 | 22.7 | 4.7 | 0.0 |
| Iris | 51 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1198.6 | 32.0 | 5.7 | 0.0 |
| Iris | 51 | k-center (Heller-style) | 6.0 | 1257.2 | 78.7 | 8.0 | 0.0 |
| Iris | 51 | k-median (Heller-style) | 6.0 | 1268.8 | 115.3 | 8.7 | 0.0 |
| Iris | 51 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1229.2 | 207.3 | 10.0 | 0.0 |
| Iris | 51 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1258.6 | 93.3 | 5.3 | 0.0 |
| Iris | 51 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1229.2 | 207.3 | 10.0 | 0.0 |
| Iris | 51 | Random feasible | 6.0 | 1218.8 | 178.7 | 11.0 | 0.0 |
| Karen | 23 | Betweenness centrality | 9.0 | 909.3 | 150.0 | 14.3 | 0.0 |
| Karen | 23 | Exact MIP (Kondo-style) | 6.0 | 854.9 | 74.7 | 9.7 | 0.0 |
| Karen | 23 | Single-objective GA (EHACP-GA-style) | 6.0 | 822.3 | 88.0 | 11.0 | 0.0 |
| Karen | 23 | GreCo-style consolidation | 6.0 | 848.7 | 30.0 | 5.0 | 0.0 |
| Karen | 23 | Greedy cover (min #controllers) | 6.0 | 773.4 | 102.7 | 12.7 | 0.0 |
| Karen | 23 | GreenPlace (3-obj NSGA-II) | 6.0 | 798.1 | 73.0 | 10.0 | 0.0 |
| Karen | 23 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 799.2 | 70.3 | 10.3 | 0.0 |
| Karen | 23 | k-center (Heller-style) | 6.0 | 847.6 | 86.7 | 11.3 | 0.0 |
| Karen | 23 | k-median (Heller-style) | 6.0 | 849.5 | 74.7 | 9.7 | 0.0 |
| Karen | 23 | NSGA-II energy+delay (Jalili-style) | 6.0 | 845.1 | 86.7 | 11.3 | 0.0 |
| Karen | 23 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 845.1 | 86.7 | 11.3 | 0.0 |
| Karen | 23 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 845.1 | 86.7 | 11.3 | 0.0 |
| Karen | 23 | Random feasible | 6.0 | 830.8 | 81.3 | 9.7 | 0.0 |
| Missouri | 60 | Betweenness centrality | 50.0 | 1994.8 | 858.7 | 19.0 | 0.0 |
| Missouri | 60 | Exact MIP (Kondo-style) | 6.0 | 1429.9 | 26.3 | 2.0 | 0.0 |
| Missouri | 60 | Single-objective GA (EHACP-GA-style) | 6.0 | 1449.4 | 98.7 | 7.3 | 0.0 |
| Missouri | 60 | GreCo-style consolidation | 6.0 | 1570.6 | 21.3 | 2.0 | 0.0 |
| Missouri | 60 | Greedy cover (min #controllers) | 6.0 | 1486.6 | 94.3 | 5.7 | 0.0 |
| Missouri | 60 | GreenPlace (3-obj NSGA-II) | 6.0 | 1498.9 | 30.7 | 3.3 | 0.0 |
| Missouri | 60 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1479.9 | 32.7 | 4.3 | 0.0 |
| Missouri | 60 | k-center (Heller-style) | 6.0 | 1491.8 | 104.7 | 7.0 | 0.0 |
| Missouri | 60 | k-median (Heller-style) | 6.0 | 1422.4 | 70.7 | 6.7 | 0.0 |
| Missouri | 60 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1469.2 | 93.3 | 7.7 | 0.0 |
| Missouri | 60 | CONTROL: 2-obj NSGA-II + migration-aware pick | 7.3 | 1556.6 | 161.3 | 10.0 | 0.0 |
| Missouri | 60 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1469.2 | 93.3 | 7.7 | 0.0 |
| Missouri | 60 | Random feasible | 6.0 | 1570.9 | 118.3 | 7.3 | 0.0 |
| Noel | 19 | Betweenness centrality | 5.0 | 700.2 | 12.0 | 5.0 | 0.0 |
| Noel | 19 | Exact MIP (Kondo-style) | 5.0 | 698.0 | 18.0 | 5.0 | 0.0 |
| Noel | 19 | Single-objective GA (EHACP-GA-style) | 5.0 | 682.0 | 17.3 | 5.7 | 0.0 |
| Noel | 19 | GreCo-style consolidation | 5.0 | 710.7 | 16.0 | 5.0 | 0.0 |
| Noel | 19 | Greedy cover (min #controllers) | 5.0 | 705.8 | 28.0 | 8.0 | 0.0 |
| Noel | 19 | GreenPlace (3-obj NSGA-II) | 5.0 | 692.6 | 12.7 | 5.7 | 0.0 |
| Noel | 19 | GreenPlace-SIL (simulation-in-the-loop) | 5.3 | 686.2 | 20.3 | 6.3 | 0.0 |
| Noel | 19 | k-center (Heller-style) | 5.0 | 735.3 | 19.7 | 4.7 | 0.0 |
| Noel | 19 | k-median (Heller-style) | 5.0 | 697.2 | 27.0 | 7.0 | 0.0 |
| Noel | 19 | NSGA-II energy+delay (Jalili-style) | 5.0 | 699.9 | 23.7 | 7.0 | 0.0 |
| Noel | 19 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 684.8 | 12.7 | 5.7 | 0.0 |
| Noel | 19 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 684.8 | 12.7 | 5.7 | 0.0 |
| Noel | 19 | Random feasible | 5.0 | 693.5 | 26.3 | 7.3 | 0.0 |
| Nsfnet | 13 | Betweenness centrality | 6.0 | 715.3 | 10.7 | 4.0 | 0.0 |
| Nsfnet | 13 | Exact MIP (Kondo-style) | 5.0 | 694.4 | 10.7 | 2.7 | 0.0 |
| Nsfnet | 13 | Single-objective GA (EHACP-GA-style) | 5.0 | 708.3 | 5.3 | 2.7 | 0.0 |
| Nsfnet | 13 | GreCo-style consolidation | 5.0 | 708.3 | 5.3 | 2.7 | 0.0 |
| Nsfnet | 13 | Greedy cover (min #controllers) | 5.0 | 711.9 | 10.7 | 2.7 | 0.0 |
| Nsfnet | 13 | GreenPlace (3-obj NSGA-II) | 5.0 | 710.4 | 2.7 | 2.7 | 0.0 |
| Nsfnet | 13 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 697.3 | 8.0 | 2.7 | 0.0 |
| Nsfnet | 13 | k-center (Heller-style) | 5.0 | 697.2 | 15.7 | 4.7 | 0.0 |
| Nsfnet | 13 | k-median (Heller-style) | 5.0 | 711.9 | 10.7 | 2.7 | 0.0 |
| Nsfnet | 13 | NSGA-II energy+delay (Jalili-style) | 5.0 | 707.7 | 11.3 | 4.0 | 0.0 |
| Nsfnet | 13 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 707.7 | 11.3 | 4.0 | 0.0 |
| Nsfnet | 13 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 703.5 | 12.0 | 3.3 | 0.0 |
| Nsfnet | 13 | Random feasible | 5.0 | 710.0 | 5.3 | 2.7 | 0.0 |
| Ntelos | 47 | Betweenness centrality | 15.0 | 1391.2 | 282.0 | 11.0 | 0.0 |
| Ntelos | 47 | Exact MIP (Kondo-style) | 6.0 | 1226.0 | 63.0 | 5.0 | 0.0 |
| Ntelos | 47 | Single-objective GA (EHACP-GA-style) | 6.0 | 1169.8 | 108.3 | 8.0 | 0.0 |
| Ntelos | 47 | GreCo-style consolidation | 6.0 | 1220.8 | 104.0 | 12.7 | 0.0 |
| Ntelos | 47 | Greedy cover (min #controllers) | 6.0 | 1231.2 | 166.7 | 11.3 | 0.0 |
| Ntelos | 47 | GreenPlace (3-obj NSGA-II) | 6.0 | 1215.4 | 56.3 | 6.0 | 0.0 |
| Ntelos | 47 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1146.5 | 69.3 | 7.7 | 0.0 |
| Ntelos | 47 | k-center (Heller-style) | 6.0 | 1258.7 | 58.7 | 5.0 | 0.0 |
| Ntelos | 47 | k-median (Heller-style) | 6.0 | 1157.8 | 109.7 | 9.3 | 0.0 |
| Ntelos | 47 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1168.5 | 110.7 | 9.7 | 0.0 |
| Ntelos | 47 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.3 | 1179.5 | 99.3 | 9.7 | 0.0 |
| Ntelos | 47 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1164.2 | 94.7 | 8.0 | 0.0 |
| Ntelos | 47 | Random feasible | 6.0 | 1165.3 | 78.0 | 7.3 | 0.0 |
| Ntt | 32 | Betweenness centrality | 29.0 | 1246.9 | 279.0 | 14.0 | 0.0 |
| Ntt | 32 | Exact MIP (Kondo-style) | 6.0 | 1060.0 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | Single-objective GA (EHACP-GA-style) | 6.0 | 1025.2 | 20.7 | 3.0 | 0.0 |
| Ntt | 32 | GreCo-style consolidation | 6.0 | 1130.0 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | Greedy cover (min #controllers) | 6.0 | 981.0 | 37.3 | 6.3 | 0.0 |
| Ntt | 32 | GreenPlace (3-obj NSGA-II) | 6.0 | 1061.7 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1061.7 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | k-center (Heller-style) | 6.0 | 1095.0 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | k-median (Heller-style) | 7.0 | 1145.4 | 13.3 | 3.3 | 0.0 |
| Ntt | 32 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1061.7 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1061.7 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1061.7 | 0.0 | 0.0 | 0.0 |
| Ntt | 32 | Random feasible | 6.0 | 1021.0 | 14.3 | 4.3 | 0.0 |
| Peer1 | 16 | Betweenness centrality | 9.0 | 767.7 | 89.7 | 11.7 | 0.0 |
| Peer1 | 16 | Exact MIP (Kondo-style) | 6.0 | 752.5 | 41.0 | 9.7 | 0.0 |
| Peer1 | 16 | Single-objective GA (EHACP-GA-style) | 6.0 | 763.1 | 80.0 | 11.7 | 0.0 |
| Peer1 | 16 | GreCo-style consolidation | 6.0 | 754.0 | 104.3 | 17.3 | 0.0 |
| Peer1 | 16 | Greedy cover (min #controllers) | 6.0 | 745.4 | 61.0 | 11.7 | 0.0 |
| Peer1 | 16 | GreenPlace (3-obj NSGA-II) | 6.0 | 764.3 | 54.3 | 11.0 | 0.0 |
| Peer1 | 16 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 748.6 | 78.3 | 16.3 | 0.0 |
| Peer1 | 16 | k-center (Heller-style) | 6.0 | 758.2 | 78.3 | 16.3 | 0.0 |
| Peer1 | 16 | k-median (Heller-style) | 6.0 | 765.0 | 58.7 | 8.7 | 0.0 |
| Peer1 | 16 | NSGA-II energy+delay (Jalili-style) | 6.0 | 778.4 | 69.0 | 9.3 | 0.0 |
| Peer1 | 16 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 778.4 | 69.0 | 9.3 | 0.0 |
| Peer1 | 16 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 748.6 | 78.3 | 16.3 | 0.0 |
| Peer1 | 16 | Random feasible | 6.0 | 747.6 | 68.3 | 13.3 | 0.0 |
| Quest | 20 | Betweenness centrality | 5.0 | 690.2 | 38.7 | 6.3 | 0.0 |
| Quest | 20 | Exact MIP (Kondo-style) | 5.0 | 704.8 | 43.3 | 5.7 | 0.0 |
| Quest | 20 | Single-objective GA (EHACP-GA-style) | 5.0 | 705.9 | 17.3 | 5.7 | 0.0 |
| Quest | 20 | GreCo-style consolidation | 5.0 | 706.8 | 21.3 | 5.7 | 0.0 |
| Quest | 20 | Greedy cover (min #controllers) | 5.0 | 726.0 | 44.0 | 6.0 | 0.0 |
| Quest | 20 | GreenPlace (3-obj NSGA-II) | 5.0 | 720.1 | 14.7 | 3.7 | 0.0 |
| Quest | 20 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 699.9 | 30.7 | 6.3 | 0.0 |
| Quest | 20 | k-center (Heller-style) | 5.0 | 722.0 | 8.0 | 2.7 | 0.0 |
| Quest | 20 | k-median (Heller-style) | 5.0 | 710.4 | 17.3 | 5.7 | 0.0 |
| Quest | 20 | NSGA-II energy+delay (Jalili-style) | 5.0 | 706.9 | 26.7 | 5.7 | 0.0 |
| Quest | 20 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 705.9 | 27.3 | 6.3 | 0.0 |
| Quest | 20 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 710.9 | 24.0 | 5.7 | 0.0 |
| Quest | 20 | Random feasible | 5.0 | 731.7 | 14.0 | 3.3 | 0.0 |
| Rediris | 19 | Betweenness centrality | 10.0 | 724.8 | 143.7 | 14.3 | 0.0 |
| Rediris | 19 | Exact MIP (Kondo-style) | 5.0 | 666.8 | 64.7 | 9.7 | 0.0 |
| Rediris | 19 | Single-objective GA (EHACP-GA-style) | 5.0 | 654.6 | 74.3 | 10.7 | 0.0 |
| Rediris | 19 | GreCo-style consolidation | 5.0 | 698.0 | 65.0 | 9.7 | 0.0 |
| Rediris | 19 | Greedy cover (min #controllers) | 5.0 | 649.3 | 62.3 | 9.7 | 0.0 |
| Rediris | 19 | GreenPlace (3-obj NSGA-II) | 5.0 | 679.7 | 64.7 | 10.0 | 0.0 |
| Rediris | 19 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 679.7 | 64.7 | 10.0 | 0.0 |
| Rediris | 19 | k-center (Heller-style) | 5.0 | 696.4 | 42.0 | 7.7 | 0.0 |
| Rediris | 19 | k-median (Heller-style) | 5.0 | 673.8 | 63.7 | 9.7 | 0.0 |
| Rediris | 19 | NSGA-II energy+delay (Jalili-style) | 5.0 | 663.9 | 61.7 | 9.3 | 0.0 |
| Rediris | 19 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 663.9 | 61.7 | 9.3 | 0.0 |
| Rediris | 19 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 663.9 | 61.7 | 9.3 | 0.0 |
| Rediris | 19 | Random feasible | 5.0 | 653.9 | 74.7 | 10.3 | 0.0 |
| Renater2010 | 37 | Betweenness centrality | 7.0 | 967.8 | 42.0 | 4.3 | 0.0 |
| Renater2010 | 37 | Exact MIP (Kondo-style) | 6.0 | 966.7 | 47.7 | 3.3 | 0.0 |
| Renater2010 | 37 | Single-objective GA (EHACP-GA-style) | 6.0 | 974.2 | 33.0 | 4.0 | 0.0 |
| Renater2010 | 37 | GreCo-style consolidation | 6.0 | 1066.1 | 43.0 | 5.7 | 0.0 |
| Renater2010 | 37 | Greedy cover (min #controllers) | 6.0 | 982.2 | 107.7 | 10.3 | 0.0 |
| Renater2010 | 37 | GreenPlace (3-obj NSGA-II) | 6.0 | 965.9 | 21.3 | 2.7 | 0.0 |
| Renater2010 | 37 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 971.1 | 18.7 | 2.7 | 0.0 |
| Renater2010 | 37 | k-center (Heller-style) | 6.0 | 1092.5 | 8.0 | 2.0 | 0.0 |
| Renater2010 | 37 | k-median (Heller-style) | 6.0 | 987.8 | 33.7 | 3.3 | 0.0 |
| Renater2010 | 37 | NSGA-II energy+delay (Jalili-style) | 6.0 | 965.0 | 64.7 | 6.3 | 0.0 |
| Renater2010 | 37 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.7 | 1016.9 | 23.0 | 5.3 | 0.0 |
| Renater2010 | 37 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 965.0 | 64.7 | 6.3 | 0.0 |
| Renater2010 | 37 | Random feasible | 6.0 | 1010.7 | 41.0 | 5.3 | 0.0 |
| Rnp | 28 | Betweenness centrality | 8.0 | 936.2 | 178.3 | 14.0 | 0.0 |
| Rnp | 28 | Exact MIP (Kondo-style) | 6.0 | 859.7 | 88.3 | 11.7 | 0.0 |
| Rnp | 28 | Single-objective GA (EHACP-GA-style) | 6.0 | 859.7 | 86.0 | 11.3 | 0.0 |
| Rnp | 28 | GreCo-style consolidation | 6.0 | 986.9 | 8.0 | 2.0 | 0.0 |
| Rnp | 28 | Greedy cover (min #controllers) | 6.0 | 904.0 | 60.7 | 7.0 | 0.0 |
| Rnp | 28 | GreenPlace (3-obj NSGA-II) | 6.0 | 866.9 | 48.0 | 9.3 | 0.0 |
| Rnp | 28 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 871.8 | 44.0 | 9.3 | 0.0 |
| Rnp | 28 | k-center (Heller-style) | 6.0 | 878.3 | 62.7 | 9.3 | 0.0 |
| Rnp | 28 | k-median (Heller-style) | 6.0 | 863.6 | 72.0 | 9.3 | 0.0 |
| Rnp | 28 | NSGA-II energy+delay (Jalili-style) | 6.0 | 862.3 | 92.7 | 11.3 | 0.0 |
| Rnp | 28 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 867.9 | 52.0 | 9.3 | 0.0 |
| Rnp | 28 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 872.8 | 45.3 | 9.3 | 0.0 |
| Rnp | 28 | Random feasible | 6.0 | 909.3 | 50.7 | 8.3 | 0.0 |
| Sanet | 43 | Betweenness centrality | 12.0 | 1108.6 | 284.7 | 20.7 | 0.0 |
| Sanet | 43 | Exact MIP (Kondo-style) | 6.0 | 1098.9 | 101.0 | 6.7 | 0.0 |
| Sanet | 43 | Single-objective GA (EHACP-GA-style) | 6.0 | 1006.1 | 125.0 | 9.7 | 0.0 |
| Sanet | 43 | GreCo-style consolidation | 6.0 | 1163.3 | 41.3 | 5.7 | 0.0 |
| Sanet | 43 | Greedy cover (min #controllers) | 6.0 | 1057.4 | 219.3 | 13.7 | 0.0 |
| Sanet | 43 | GreenPlace (3-obj NSGA-II) | 6.0 | 1081.7 | 42.7 | 6.0 | 0.0 |
| Sanet | 43 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1050.3 | 82.7 | 8.7 | 0.0 |
| Sanet | 43 | k-center (Heller-style) | 6.0 | 1102.8 | 104.7 | 7.7 | 0.0 |
| Sanet | 43 | k-median (Heller-style) | 6.0 | 1021.9 | 84.7 | 11.3 | 0.0 |
| Sanet | 43 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1077.2 | 93.7 | 6.7 | 0.0 |
| Sanet | 43 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1077.2 | 93.7 | 6.7 | 0.0 |
| Sanet | 43 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1074.0 | 78.7 | 6.7 | 0.0 |
| Sanet | 43 | Random feasible | 6.0 | 1085.1 | 77.0 | 6.7 | 0.0 |
| Savvis | 19 | Betweenness centrality | 7.0 | 842.4 | 35.0 | 6.7 | 0.0 |
| Savvis | 19 | Exact MIP (Kondo-style) | 5.0 | 692.8 | 17.3 | 5.7 | 0.0 |
| Savvis | 19 | Single-objective GA (EHACP-GA-style) | 5.0 | 742.2 | 21.0 | 4.0 | 0.0 |
| Savvis | 19 | GreCo-style consolidation | 5.0 | 696.2 | 42.0 | 8.3 | 0.0 |
| Savvis | 19 | Greedy cover (min #controllers) | 5.0 | 717.4 | 34.0 | 5.7 | 0.0 |
| Savvis | 19 | GreenPlace (3-obj NSGA-II) | 5.0 | 695.7 | 21.7 | 6.0 | 0.0 |
| Savvis | 19 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 691.4 | 15.3 | 5.7 | 0.0 |
| Savvis | 19 | k-center (Heller-style) | 5.0 | 695.1 | 17.3 | 5.7 | 0.0 |
| Savvis | 19 | k-median (Heller-style) | 5.0 | 690.1 | 17.3 | 5.7 | 0.0 |
| Savvis | 19 | NSGA-II energy+delay (Jalili-style) | 5.0 | 690.1 | 17.3 | 5.7 | 0.0 |
| Savvis | 19 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 690.1 | 17.3 | 5.7 | 0.0 |
| Savvis | 19 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 690.1 | 17.3 | 5.7 | 0.0 |
| Savvis | 19 | Random feasible | 5.0 | 715.9 | 11.7 | 4.0 | 0.0 |
| Shentel | 28 | Betweenness centrality | 7.0 | 918.6 | 166.3 | 14.7 | 0.0 |
| Shentel | 28 | Exact MIP (Kondo-style) | 6.0 | 812.1 | 121.3 | 10.0 | 0.0 |
| Shentel | 28 | Single-objective GA (EHACP-GA-style) | 6.0 | 826.3 | 106.3 | 11.3 | 0.0 |
| Shentel | 28 | GreCo-style consolidation | 6.0 | 844.6 | 104.3 | 14.0 | 0.0 |
| Shentel | 28 | Greedy cover (min #controllers) | 6.0 | 826.1 | 104.7 | 13.0 | 0.0 |
| Shentel | 28 | GreenPlace (3-obj NSGA-II) | 6.0 | 834.8 | 117.3 | 13.3 | 0.0 |
| Shentel | 28 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 813.3 | 103.7 | 9.7 | 0.0 |
| Shentel | 28 | k-center (Heller-style) | 6.0 | 873.8 | 82.0 | 9.3 | 0.0 |
| Shentel | 28 | k-median (Heller-style) | 6.0 | 847.3 | 146.3 | 15.7 | 0.0 |
| Shentel | 28 | NSGA-II energy+delay (Jalili-style) | 6.0 | 842.1 | 125.3 | 14.0 | 0.0 |
| Shentel | 28 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 842.1 | 125.3 | 14.0 | 0.0 |
| Shentel | 28 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 837.9 | 106.7 | 13.0 | 0.0 |
| Shentel | 28 | Random feasible | 6.0 | 845.0 | 124.3 | 12.0 | 0.0 |
| Sprint | 11 | Betweenness centrality | 6.0 | 672.2 | 10.0 | 4.0 | 0.0 |
| Sprint | 11 | Exact MIP (Kondo-style) | 6.0 | 750.7 | 16.0 | 4.0 | 0.0 |
| Sprint | 11 | Single-objective GA (EHACP-GA-style) | 6.0 | 686.9 | 18.3 | 6.7 | 0.0 |
| Sprint | 11 | GreCo-style consolidation | 6.0 | 672.7 | 14.7 | 5.0 | 0.0 |
| Sprint | 11 | Greedy cover (min #controllers) | 6.0 | 672.9 | 14.0 | 4.0 | 0.0 |
| Sprint | 11 | GreenPlace (3-obj NSGA-II) | 6.0 | 672.6 | 14.7 | 4.3 | 0.0 |
| Sprint | 11 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 672.2 | 12.0 | 4.0 | 0.0 |
| Sprint | 11 | k-center (Heller-style) | 6.0 | 676.1 | 14.0 | 4.0 | 0.0 |
| Sprint | 11 | k-median (Heller-style) | 6.0 | 672.2 | 12.0 | 4.0 | 0.0 |
| Sprint | 11 | NSGA-II energy+delay (Jalili-style) | 6.0 | 673.5 | 13.3 | 4.0 | 0.0 |
| Sprint | 11 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 673.5 | 13.3 | 4.0 | 0.0 |
| Sprint | 11 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 673.5 | 13.3 | 4.0 | 0.0 |
| Sprint | 11 | Random feasible | 6.0 | 673.4 | 13.3 | 4.7 | 0.0 |
| Sunet | 25 | Betweenness centrality | 23.0 | 1040.6 | 168.0 | 9.3 | 0.0 |
| Sunet | 25 | Exact MIP (Kondo-style) | 5.0 | 861.9 | 30.3 | 2.0 | 0.0 |
| Sunet | 25 | Single-objective GA (EHACP-GA-style) | 5.0 | 883.8 | 17.0 | 2.0 | 0.0 |
| Sunet | 25 | GreCo-style consolidation | 5.0 | 894.9 | 28.0 | 4.0 | 0.0 |
| Sunet | 25 | Greedy cover (min #controllers) | 5.0 | 882.5 | 12.0 | 2.0 | 0.0 |
| Sunet | 25 | GreenPlace (3-obj NSGA-II) | 5.0 | 886.0 | 23.0 | 2.7 | 0.0 |
| Sunet | 25 | GreenPlace-SIL (simulation-in-the-loop) | 5.0 | 886.4 | 19.7 | 2.7 | 0.0 |
| Sunet | 25 | k-center (Heller-style) | 5.0 | 882.3 | 22.0 | 2.0 | 0.0 |
| Sunet | 25 | k-median (Heller-style) | 5.0 | 874.7 | 29.0 | 4.0 | 0.0 |
| Sunet | 25 | NSGA-II energy+delay (Jalili-style) | 5.0 | 872.5 | 25.7 | 2.0 | 0.0 |
| Sunet | 25 | CONTROL: 2-obj NSGA-II + migration-aware pick | 5.0 | 872.5 | 25.7 | 2.0 | 0.0 |
| Sunet | 25 | CONTROL: 2-obj NSGA-II + simulation pick | 5.0 | 868.7 | 25.7 | 2.0 | 0.0 |
| Sunet | 25 | Random feasible | 5.0 | 883.1 | 15.3 | 2.0 | 0.0 |
| Surfnet | 50 | Betweenness centrality | 11.0 | 1227.7 | 292.7 | 15.0 | 0.0 |
| Surfnet | 50 | Exact MIP (Kondo-style) | 6.0 | 1111.6 | 54.0 | 2.7 | 0.0 |
| Surfnet | 50 | Single-objective GA (EHACP-GA-style) | 6.0 | 1138.3 | 51.7 | 3.3 | 0.0 |
| Surfnet | 50 | GreCo-style consolidation | 6.0 | 1211.1 | 50.0 | 5.7 | 0.0 |
| Surfnet | 50 | Greedy cover (min #controllers) | 6.0 | 1181.4 | 141.7 | 9.0 | 0.0 |
| Surfnet | 50 | GreenPlace (3-obj NSGA-II) | 6.3 | 1218.4 | 93.3 | 7.0 | 0.0 |
| Surfnet | 50 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1143.0 | 37.3 | 3.3 | 0.0 |
| Surfnet | 50 | k-center (Heller-style) | 6.0 | 1225.7 | 27.3 | 2.7 | 0.0 |
| Surfnet | 50 | k-median (Heller-style) | 6.0 | 1163.3 | 123.0 | 7.0 | 0.0 |
| Surfnet | 50 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1157.6 | 33.0 | 2.3 | 0.0 |
| Surfnet | 50 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.3 | 1176.8 | 34.7 | 2.7 | 0.0 |
| Surfnet | 50 | CONTROL: 2-obj NSGA-II + simulation pick | 6.7 | 1146.0 | 88.3 | 6.0 | 0.0 |
| Surfnet | 50 | Random feasible | 6.0 | 1201.0 | 35.0 | 2.0 | 0.0 |
| Tinet | 46 | Betweenness centrality | 6.0 | 1047.8 | 196.7 | 11.7 | 0.0 |
| Tinet | 46 | Exact MIP (Kondo-style) | 6.0 | 1173.1 | 340.3 | 11.7 | 0.0 |
| Tinet | 46 | Single-objective GA (EHACP-GA-style) | 6.0 | 1161.1 | 342.3 | 11.7 | 0.0 |
| Tinet | 46 | GreCo-style consolidation | 6.0 | 1268.6 | 181.7 | 9.0 | 0.0 |
| Tinet | 46 | Greedy cover (min #controllers) | 6.0 | 1090.1 | 174.0 | 10.3 | 0.0 |
| Tinet | 46 | GreenPlace (3-obj NSGA-II) | 6.0 | 1117.2 | 132.7 | 9.0 | 0.0 |
| Tinet | 46 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1035.4 | 181.0 | 9.7 | 0.0 |
| Tinet | 46 | k-center (Heller-style) | 6.0 | 1172.9 | 245.7 | 9.0 | 0.0 |
| Tinet | 46 | k-median (Heller-style) | 6.0 | 1099.6 | 181.7 | 10.3 | 0.0 |
| Tinet | 46 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1159.9 | 214.7 | 9.0 | 0.0 |
| Tinet | 46 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1185.1 | 208.7 | 9.0 | 0.0 |
| Tinet | 46 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1088.4 | 164.7 | 9.0 | 0.0 |
| Tinet | 46 | Random feasible | 6.0 | 1153.3 | 363.0 | 11.7 | 0.0 |
| Uunet | 42 | Betweenness centrality | 10.0 | 1198.2 | 208.0 | 12.3 | 0.0 |
| Uunet | 42 | Exact MIP (Kondo-style) | 6.0 | 1102.8 | 85.0 | 6.3 | 0.0 |
| Uunet | 42 | Single-objective GA (EHACP-GA-style) | 6.0 | 1084.3 | 106.7 | 10.0 | 0.0 |
| Uunet | 42 | GreCo-style consolidation | 6.0 | 1175.4 | 6.7 | 3.3 | 0.0 |
| Uunet | 42 | Greedy cover (min #controllers) | 6.0 | 1099.1 | 97.7 | 7.7 | 0.0 |
| Uunet | 42 | GreenPlace (3-obj NSGA-II) | 6.0 | 1130.9 | 44.0 | 5.3 | 0.0 |
| Uunet | 42 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 1090.3 | 31.3 | 5.0 | 0.0 |
| Uunet | 42 | k-center (Heller-style) | 6.0 | 1198.8 | 70.7 | 6.7 | 0.0 |
| Uunet | 42 | k-median (Heller-style) | 6.0 | 1106.4 | 77.3 | 8.3 | 0.0 |
| Uunet | 42 | NSGA-II energy+delay (Jalili-style) | 6.0 | 1106.5 | 84.3 | 6.3 | 0.0 |
| Uunet | 42 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 1107.3 | 71.3 | 5.7 | 0.0 |
| Uunet | 42 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 1109.5 | 67.7 | 5.7 | 0.0 |
| Uunet | 42 | Random feasible | 6.0 | 1132.9 | 56.0 | 6.3 | 0.0 |
| Xeex | 24 | Betweenness centrality | 24.0 | 1099.8 | 201.0 | 12.7 | 0.0 |
| Xeex | 24 | Exact MIP (Kondo-style) | 6.0 | 833.4 | 56.0 | 8.0 | 0.0 |
| Xeex | 24 | Single-objective GA (EHACP-GA-style) | 6.0 | 853.8 | 99.3 | 8.0 | 0.0 |
| Xeex | 24 | GreCo-style consolidation | 6.0 | 899.4 | 88.0 | 8.0 | 0.0 |
| Xeex | 24 | Greedy cover (min #controllers) | 6.0 | 878.0 | 73.0 | 8.0 | 0.0 |
| Xeex | 24 | GreenPlace (3-obj NSGA-II) | 6.0 | 834.1 | 53.7 | 8.0 | 0.0 |
| Xeex | 24 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 834.1 | 53.7 | 8.0 | 0.0 |
| Xeex | 24 | k-center (Heller-style) | 6.0 | 905.1 | 147.3 | 10.7 | 0.0 |
| Xeex | 24 | k-median (Heller-style) | 6.0 | 892.6 | 104.0 | 8.0 | 0.0 |
| Xeex | 24 | NSGA-II energy+delay (Jalili-style) | 6.0 | 833.5 | 56.3 | 8.0 | 0.0 |
| Xeex | 24 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 833.5 | 56.3 | 8.0 | 0.0 |
| Xeex | 24 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 833.5 | 56.3 | 8.0 | 0.0 |
| Xeex | 24 | Random feasible | 6.0 | 864.6 | 112.3 | 8.0 | 0.0 |
| Xspedius | 34 | Betweenness centrality | 8.0 | 932.1 | 126.3 | 12.7 | 0.0 |
| Xspedius | 34 | Exact MIP (Kondo-style) | 6.0 | 880.4 | 81.3 | 8.0 | 0.0 |
| Xspedius | 34 | Single-objective GA (EHACP-GA-style) | 6.0 | 920.3 | 53.7 | 6.7 | 0.0 |
| Xspedius | 34 | GreCo-style consolidation | 6.0 | 994.0 | 76.7 | 9.0 | 0.0 |
| Xspedius | 34 | Greedy cover (min #controllers) | 6.0 | 961.4 | 32.0 | 6.3 | 0.0 |
| Xspedius | 34 | GreenPlace (3-obj NSGA-II) | 6.0 | 884.7 | 64.0 | 7.3 | 0.0 |
| Xspedius | 34 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 884.7 | 64.0 | 7.3 | 0.0 |
| Xspedius | 34 | k-center (Heller-style) | 6.0 | 1034.9 | 30.7 | 5.7 | 0.0 |
| Xspedius | 34 | k-median (Heller-style) | 6.0 | 981.4 | 49.3 | 7.0 | 0.0 |
| Xspedius | 34 | NSGA-II energy+delay (Jalili-style) | 6.0 | 928.2 | 46.0 | 6.0 | 0.0 |
| Xspedius | 34 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 971.7 | 17.0 | 4.7 | 0.0 |
| Xspedius | 34 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 937.3 | 39.0 | 5.0 | 0.0 |
| Xspedius | 34 | Random feasible | 6.0 | 973.0 | 31.0 | 4.0 | 0.0 |
| Zamren | 35 | Betweenness centrality | 6.0 | 1003.7 | 42.7 | 6.0 | 0.0 |
| Zamren | 35 | Exact MIP (Kondo-style) | 6.0 | 963.6 | 14.7 | 2.7 | 0.0 |
| Zamren | 35 | Single-objective GA (EHACP-GA-style) | 6.0 | 917.7 | 62.3 | 7.7 | 0.0 |
| Zamren | 35 | GreCo-style consolidation | 6.0 | 1019.7 | 26.7 | 5.7 | 0.0 |
| Zamren | 35 | Greedy cover (min #controllers) | 6.0 | 928.6 | 95.3 | 10.3 | 0.0 |
| Zamren | 35 | GreenPlace (3-obj NSGA-II) | 6.0 | 917.6 | 48.0 | 8.0 | 0.0 |
| Zamren | 35 | GreenPlace-SIL (simulation-in-the-loop) | 6.0 | 918.8 | 40.0 | 6.7 | 0.0 |
| Zamren | 35 | k-center (Heller-style) | 6.0 | 963.6 | 14.7 | 2.7 | 0.0 |
| Zamren | 35 | k-median (Heller-style) | 6.0 | 963.6 | 14.7 | 2.7 | 0.0 |
| Zamren | 35 | NSGA-II energy+delay (Jalili-style) | 6.0 | 917.5 | 69.3 | 8.7 | 0.0 |
| Zamren | 35 | CONTROL: 2-obj NSGA-II + migration-aware pick | 6.0 | 917.5 | 69.3 | 8.7 | 0.0 |
| Zamren | 35 | CONTROL: 2-obj NSGA-II + simulation pick | 6.0 | 917.5 | 69.3 | 8.7 | 0.0 |
| Zamren | 35 | Random feasible | 6.0 | 949.7 | 41.3 | 7.0 | 0.0 |

</details>
