# Real traffic traces (aggregated)

`real_traces_15min.csv` holds complete 24-hour, 15-minute-resolution **total-traffic** series (96 steps/day) derived from
two public intradomain traffic-matrix datasets, obtained from SNDlib (https://sndlib.put.poznan.pl):

* **GEANT** (Uhlig et al., "Providing public intradomain traffic matrices to the research community", ACM CCR 36(1), 2006): 15-min matrices, 2005-05-04 .. 2005-08-31 (40 complete days after dropping days with missing matrices).
* **Abilene** (Zhang et al., SIGMETRICS 2003 dataset): 5-min matrices aggregated to 15 min, 2004-03-01 .. 2004-09-10 (134 complete days).

Only the sum of all demands per time step (Mbit/s) is kept; matrices with <90 % of the expected demands were treated as missing and
days containing any missing step were dropped. SNDlib: Orlowski, Pioro, Tomaszewski, Wessaely, "SNDlib 1.0 - Survivable Network Design Library", Networks 55(3), 2010.

**How it is used:** the series is divided by its dataset-wide 99th percentile and clipped to [0.05, 1] to obtain a load factor.
Total traffic is a *proxy* for control-plane load (packet-in rate scales with flow arrivals); it is not a controller-load measurement.
Check the SNDlib terms of use before redistributing the raw matrices; only the derived aggregate series is included here.
