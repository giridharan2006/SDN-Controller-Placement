graph [
  node [
    id 0
    label "0"
  ]
  node [
    id 1
    label "1"
  ]
  node [
    id 2
    label "2"
  ]
  node [
    id 3
    label "3"
  ]
  node [
    id 4
    label "4"
  ]
  node [
    id 5
    label "5"
  ]
  node [
    id 6
    label "6"
  ]
  node [
    id 7
    label "7"
  ]
  edge [
    source 0
    target 1
    delay 7.69
  ]
  edge [
    source 0
    target 7
    delay 3.16
  ]
  edge [
    source 0
    target 5
    delay 4.01
  ]
  edge [
    source 1
    target 2
    delay 7.63
  ]
  edge [
    source 2
    target 3
    delay 1.4
  ]
  edge [
    source 2
    target 5
    delay 1.19
  ]
  edge [
    source 3
    target 4
    delay 1.59
  ]
  edge [
    source 4
    target 5
    delay 6.85
  ]
  edge [
    source 5
    target 6
    delay 6.15
  ]
  edge [
    source 5
    target 7
    delay 3.28
  ]
  edge [
    source 6
    target 7
    delay 5.69
  ]
]
