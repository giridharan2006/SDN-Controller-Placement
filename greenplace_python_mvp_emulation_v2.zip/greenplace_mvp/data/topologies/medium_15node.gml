graph [
  node [
    id 0
    label "0"
  ]
  node [
    id 1
    label "1"
  ]
  node [
    id 2
    label "2"
  ]
  node [
    id 3
    label "3"
  ]
  node [
    id 4
    label "4"
  ]
  node [
    id 5
    label "5"
  ]
  node [
    id 6
    label "6"
  ]
  node [
    id 7
    label "7"
  ]
  node [
    id 8
    label "8"
  ]
  node [
    id 9
    label "9"
  ]
  node [
    id 10
    label "10"
  ]
  node [
    id 11
    label "11"
  ]
  node [
    id 12
    label "12"
  ]
  node [
    id 13
    label "13"
  ]
  node [
    id 14
    label "14"
  ]
  edge [
    source 0
    target 1
    delay 2.67
  ]
  edge [
    source 0
    target 14
    delay 5.47
  ]
  edge [
    source 0
    target 8
    delay 6.31
  ]
  edge [
    source 0
    target 11
    delay 7.06
  ]
  edge [
    source 1
    target 2
    delay 4.81
  ]
  edge [
    source 1
    target 11
    delay 1.95
  ]
  edge [
    source 2
    target 3
    delay 3.59
  ]
  edge [
    source 3
    target 4
    delay 5.23
  ]
  edge [
    source 4
    target 5
    delay 5.38
  ]
  edge [
    source 4
    target 8
    delay 6.98
  ]
  edge [
    source 4
    target 10
    delay 6.6
  ]
  edge [
    source 5
    target 6
    delay 1.46
  ]
  edge [
    source 5
    target 8
    delay 5.3
  ]
  edge [
    source 5
    target 9
    delay 6.03
  ]
  edge [
    source 6
    target 7
    delay 1.09
  ]
  edge [
    source 6
    target 9
    delay 5.2
  ]
  edge [
    source 6
    target 10
    delay 2.38
  ]
  edge [
    source 6
    target 14
    delay 7.07
  ]
  edge [
    source 7
    target 8
    delay 6.86
  ]
  edge [
    source 8
    target 9
    delay 2.82
  ]
  edge [
    source 9
    target 10
    delay 2.64
  ]
  edge [
    source 10
    target 11
    delay 7.97
  ]
  edge [
    source 11
    target 12
    delay 4.29
  ]
  edge [
    source 11
    target 14
    delay 3.91
  ]
  edge [
    source 12
    target 13
    delay 6.86
  ]
  edge [
    source 13
    target 14
    delay 4.33
  ]
]
