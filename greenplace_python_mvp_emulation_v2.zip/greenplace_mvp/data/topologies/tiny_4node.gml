graph [
  node [
    id 0
    label "0"
  ]
  node [
    id 1
    label "1"
  ]
  node [
    id 2
    label "2"
  ]
  node [
    id 3
    label "3"
  ]
  edge [
    source 0
    target 1
    delay 1.94
  ]
  edge [
    source 0
    target 3
    delay 2.79
  ]
  edge [
    source 1
    target 2
    delay 6.93
  ]
  edge [
    source 2
    target 3
    delay 6.35
  ]
]
