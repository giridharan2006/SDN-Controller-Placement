graph [
  node [
    id 0
    label "0"
  ]
  node [
    id 1
    label "1"
  ]
  node [
    id 2
    label "2"
  ]
  node [
    id 3
    label "3"
  ]
  node [
    id 4
    label "4"
  ]
  node [
    id 5
    label "5"
  ]
  node [
    id 6
    label "6"
  ]
  node [
    id 7
    label "7"
  ]
  node [
    id 8
    label "8"
  ]
  node [
    id 9
    label "9"
  ]
  node [
    id 10
    label "10"
  ]
  node [
    id 11
    label "11"
  ]
  node [
    id 12
    label "12"
  ]
  node [
    id 13
    label "13"
  ]
  node [
    id 14
    label "14"
  ]
  node [
    id 15
    label "15"
  ]
  node [
    id 16
    label "16"
  ]
  node [
    id 17
    label "17"
  ]
  node [
    id 18
    label "18"
  ]
  node [
    id 19
    label "19"
  ]
  node [
    id 20
    label "20"
  ]
  node [
    id 21
    label "21"
  ]
  node [
    id 22
    label "22"
  ]
  node [
    id 23
    label "23"
  ]
  node [
    id 24
    label "24"
  ]
  edge [
    source 0
    target 1
    delay 2.65
  ]
  edge [
    source 0
    target 24
    delay 7.16
  ]
  edge [
    source 0
    target 2
    delay 5.24
  ]
  edge [
    source 0
    target 7
    delay 7.54
  ]
  edge [
    source 0
    target 22
    delay 1.32
  ]
  edge [
    source 1
    target 2
    delay 1.72
  ]
  edge [
    source 1
    target 19
    delay 2.6
  ]
  edge [
    source 2
    target 3
    delay 3.77
  ]
  edge [
    source 2
    target 5
    delay 5.88
  ]
  edge [
    source 2
    target 10
    delay 3.02
  ]
  edge [
    source 2
    target 24
    delay 1.31
  ]
  edge [
    source 3
    target 4
    delay 2.08
  ]
  edge [
    source 3
    target 9
    delay 7.87
  ]
  edge [
    source 3
    target 12
    delay 1.39
  ]
  edge [
    source 3
    target 16
    delay 4.43
  ]
  edge [
    source 4
    target 5
    delay 1.47
  ]
  edge [
    source 4
    target 8
    delay 3.95
  ]
  edge [
    source 4
    target 13
    delay 2.78
  ]
  edge [
    source 4
    target 19
    delay 7.5
  ]
  edge [
    source 5
    target 6
    delay 3.81
  ]
  edge [
    source 5
    target 10
    delay 2.48
  ]
  edge [
    source 6
    target 7
    delay 7.43
  ]
  edge [
    source 6
    target 8
    delay 7.8
  ]
  edge [
    source 6
    target 11
    delay 7.29
  ]
  edge [
    source 6
    target 15
    delay 2.17
  ]
  edge [
    source 6
    target 21
    delay 7.46
  ]
  edge [
    source 6
    target 22
    delay 7.13
  ]
  edge [
    source 7
    target 8
    delay 6.6
  ]
  edge [
    source 7
    target 20
    delay 1.24
  ]
  edge [
    source 8
    target 9
    delay 6.36
  ]
  edge [
    source 8
    target 14
    delay 6.86
  ]
  edge [
    source 8
    target 16
    delay 4.8
  ]
  edge [
    source 8
    target 23
    delay 1.8
  ]
  edge [
    source 9
    target 10
    delay 2.55
  ]
  edge [
    source 9
    target 16
    delay 7.17
  ]
  edge [
    source 10
    target 11
    delay 4.76
  ]
  edge [
    source 10
    target 18
    delay 3.18
  ]
  edge [
    source 10
    target 23
    delay 2.72
  ]
  edge [
    source 11
    target 12
    delay 2.94
  ]
  edge [
    source 12
    target 13
    delay 2.21
  ]
  edge [
    source 12
    target 22
    delay 2.01
  ]
  edge [
    source 13
    target 14
    delay 1.74
  ]
  edge [
    source 13
    target 20
    delay 3.82
  ]
  edge [
    source 14
    target 15
    delay 2.5
  ]
  edge [
    source 14
    target 17
    delay 1.14
  ]
  edge [
    source 15
    target 16
    delay 7.49
  ]
  edge [
    source 16
    target 17
    delay 6.8
  ]
  edge [
    source 17
    target 18
    delay 6.65
  ]
  edge [
    source 18
    target 19
    delay 6.6
  ]
  edge [
    source 19
    target 20
    delay 2.35
  ]
  edge [
    source 19
    target 23
    delay 2.29
  ]
  edge [
    source 20
    target 21
    delay 3.17
  ]
  edge [
    source 21
    target 22
    delay 5.39
  ]
  edge [
    source 22
    target 23
    delay 6.12
  ]
  edge [
    source 23
    target 24
    delay 6.98
  ]
]
