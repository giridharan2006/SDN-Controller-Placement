from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Preformatted, Table, TableStyle,
                                PageBreak, KeepTogether, ListFlowable, ListItem)
from reportlab.lib.enums import TA_LEFT
import json
R = json.load(open("/home/claude/gp2/greenplace_mvp/outputs/study3/main/results.json"))
_L = {r["method"]: r for r in R["lifecycle_diurnal"]}
_S = {r["method"]: r for r in R["static"]}
_TM = {t["b"]: t for t in R["tests_gp_vs_baselines_migrations"]}
_TE = {t["b"]: t for t in R["tests_gp_vs_baselines_energy"]}
_sh = {s["scenario"]: s for s in R["shift"]}
_sel = R["selector"]["rules"]
def pv(x): return "&lt;0.001" if x < 0.001 else f"{x:.3f}"
def sg(x, d=1): return ("+" if x > 0 else "-" if x < 0 else "") + f"{abs(x):.{d}f}"


G = colors.HexColor("#2e7d4f"); DARK = colors.HexColor("#1f2d3a"); GREY = colors.HexColor("#f3f5f7")
ss = getSampleStyleSheet()
B = ParagraphStyle("B", parent=ss["BodyText"], fontName="Helvetica", fontSize=10, leading=14.2, spaceAfter=6)
H1 = ParagraphStyle("H1", parent=B, fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=G, spaceBefore=14, spaceAfter=8)
H2 = ParagraphStyle("H2", parent=B, fontName="Helvetica-Bold", fontSize=12, leading=16, textColor=DARK, spaceBefore=10, spaceAfter=4)
T = ParagraphStyle("T", parent=B, fontName="Helvetica-Bold", fontSize=26, leading=30, textColor=DARK, spaceAfter=6)
SUB = ParagraphStyle("SUB", parent=B, fontSize=12, leading=16, textColor=colors.HexColor("#555555"))
CODE = ParagraphStyle("CODE", fontName="Courier", fontSize=8.6, leading=11.2, backColor=GREY, borderPadding=(5, 6, 5, 6),
                      leftIndent=6, rightIndent=6, spaceBefore=4, spaceAfter=9)
NOTE = ParagraphStyle("NOTE", parent=B, backColor=colors.HexColor("#fff6e0"), borderPadding=(5, 6, 5, 6), leftIndent=6, rightIndent=6, spaceBefore=4, spaceAfter=10)
CELL = ParagraphStyle("CELL", parent=B, fontSize=8.6, leading=11, spaceAfter=0)
CELLB = ParagraphStyle("CELLB", parent=CELL, fontName="Helvetica-Bold")

S = []
def h1(t): S.append(Paragraph(t, H1))
def h2(t): S.append(Paragraph(t, H2))
def p(t): S.append(Paragraph(t, B))
def note(t): S.append(Paragraph(t, NOTE))
def code(t): S.append(Preformatted(t.strip("\n"), CODE))
def bullets(items): S.append(ListFlowable([ListItem(Paragraph(i, B), leftIndent=14) for i in items], bulletType="bullet", start="•", leftIndent=14))
def table(rows, widths, head=True):
    data = [[Paragraph(str(c), CELLB if (head and ri == 0) else CELL) for c in r] for ri, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1 if head else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#bbbbbb")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if head: st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e3e8ee")))
    t.setStyle(TableStyle(st)); S.append(t); S.append(Spacer(1, 8))

# ---------------- cover ----------------
S.append(Spacer(1, 3 * cm))
S.append(Paragraph("GreenPlace", T))
S.append(Paragraph("Build, Run and Demonstrate the Project", ParagraphStyle("T2", parent=T, fontSize=20, leading=24, textColor=G)))
S.append(Paragraph("Energy-efficient SDN controller placement under hard delay bounds", SUB))
S.append(Spacer(1, 1 * cm))
S.append(Paragraph("A step-by-step guide for Windows, macOS and Linux: install the toolchain, verify the code, run every demo, reproduce the "
                   "benchmark on real Internet Topology Zoo networks, run GreenPlace on your own network, and present the results honestly.", B))
S.append(Spacer(1, 0.6 * cm))
table([["Project package", "greenplace_python_mvp.zip  (folder greenplace_mvp/)"],
       ["Python", "3.10 or newer (verified on 3.13)"],
       ["Test suite", "85 tests, all passing"],
       ["Real data bundled", "67 Internet Topology Zoo GML files; 46 are used in the benchmark (11-60 nodes)"],
       ["Time to first demo", "about 10 minutes (install + tests + quick demo)"]], [4.2, 12], head=False)
S.append(Spacer(1, 1 * cm))
note("<b>Read this before presenting.</b> The project's two kinds of results must not be mixed up. The <i>synthetic-topology demo</i> (<font face='Courier'>demo.py</font>) "
     "prints 56.1% energy savings and 78.2% fewer migrations; those numbers do <b>not</b> generalise. The evidence to trust is the "
     f"<i>v3 study</i> ({R['n_topologies']} real networks, {R['n_seeds']} seeds, 8 traffic scenarios): GreenPlace is <b>not</b> the best static placer ({_S['greenplace']['gap_mean_pct']:.1f}% above the MIP lower bound), is <b>tied</b> on lifecycle energy, "
     f"and has about <b>{abs(_TM['nsga2_2obj']['pct_mean']):.0f}% fewer runtime migrations</b> than an energy+delay NSGA-II (Holm p {pv(_TM['nsga2_2obj']['p_holm'])}). "
     "<b>Correction:</b> earlier versions called the exact MIP's controller set 'the optimum'; it is only a lower bound under the evaluation's nearest-assignment scoring (Section 7). Section 7 gives the wording to use.")
S.append(PageBreak())

# ---------------- contents ----------------
h1("Contents")
bullets(["1. What the project is, in two minutes", "2. What is in the package", "3. Prerequisites", "4. Build: install and verify (CLI and PyCharm)",
         "5. Run the project: every command and its expected output", "6. A 10-minute live demonstration script",
         "7. How to read and present the results honestly", "8. Run GreenPlace on your own network",
         "9. Reproduce the full study", "10. Code map", "11. Troubleshooting", "12. Quick reference card"])

# ---------------- 1 ----------------
h1("1. What the project is, in two minutes")
p("An SDN network needs several controllers. Each controller that is powered on costs energy, but switches must stay within a hard delay bound of their controller. "
  "GreenPlace chooses <b>where to put controllers and which switch each one serves</b> so that control-plane power is low, <b>never</b> breaking the delay bound or controller capacity, "
  "and so that the placement is <i>cheap to live with</i> when traffic changes during the day.")
h2("Two phases")
table([["Phase", "What it does", "Main code"],
       ["1. Offline placement", "Exact MIP (ground truth on small networks) and a self-written 3-objective NSGA-II that minimises (energy, worst-case delay, migration burden) under a hard delay bound. One placement is picked from the Pareto front, either by an offline proxy rule or by simulation in the loop (SIL).",
        "ilp_solver.py, nsga2.py, selection.py"],
       ["2. Runtime elastic manager", "Smooths traffic (EMA), applies dwell-time hysteresis, sleeps and wakes controllers, reassigns switches with a capacity-aware rule and a delay guard.", "runtime.py"],
       ["Evaluation harness", "Compares GreenPlace with 18 other methods and variants (our re-implementations) on 46 real networks, 10 seeds and 8 traffic scenarios, running every method's controller pool through the same runtime manager.", "baselines.py, lifecycle.py, benchmark.py"]],
      [3.4, 9.6, 3.6])
h2("Inputs and outputs")
table([["Inputs", "Outputs"],
       ["A network topology (.gml, Internet Topology Zoo format), a hard delay bound D (default 0.35 x delay-diameter), a controller capacity (default ceil(n/6)), a power model (power per active controller, per control-link hop), a traffic trace (synthetic diurnal curve, 96 steps).",
        "A recommended controller pool and switch assignment; the Pareto front; per-step controller states and energy over the day; counts of switch migrations and sleep/wake events; delay-violation count (must be 0); benchmark tables, statistics and figures; JSON/CSV files."]],
      [8.3, 8.3])

# ---------------- 2 ----------------
h1("2. What is in the package")
code("""greenplace_mvp/
  demo.py                     one-command demo of the whole synthetic pipeline
  README.md  BENCHMARKING.md  project docs (BENCHMARKING.md = protocol + real-topology results)
  requirements.txt  pytest.ini
  greenplace/                 the library (topology, delay, power, placement, ilp_solver, nsga2,
                              optimizer, runtime, metrics, baselines, selection, lifecycle, benchmark,
                              moea, traffic, simnsga, study3)
  scripts/                    runnable entry points (see Section 5)
  tests/                      85 pytest tests
  data/topologies/            small synthetic fixtures
  data/real_topologies/       67 Internet Topology Zoo .gml files (CC BY)
  outputs/                    figures, CSV/JSON from earlier runs; outputs/benchmark/ = full study data
  .idea/                      PyCharm project config with 12 ready-made run configurations""")
p("The folder <font face='Courier'>outputs/benchmark/</font> already contains the complete results of the study (46 networks): "
  "<font face='Courier'>main/BENCHMARK_REPORT.md</font>, its figures, raw per-run rows (<font face='Courier'>rows.jsonl</font>), the control and SIL experiments and the sensitivity grid. "
  "You can show these without re-running anything.")

# ---------------- 3 ----------------
h1("3. Prerequisites")
table([["Item", "Requirement"],
       ["Operating system", "Windows 10/11, macOS, or Linux. No GPU needed. One CPU core is enough."],
       ["Python", "3.10+ (the project was verified on 3.13). Get it from python.org; on Windows tick <b>Add python.exe to PATH</b> in the installer."],
       ["Disk / RAM", "About 300 MB including the virtual environment; under 1 GB RAM."],
       ["Internet", "Needed once for <font face='Courier'>pip install</font>. Optional afterwards (only <font face='Courier'>fetch_real_topologies.py</font> downloads data; the 67 networks you need are already bundled)."],
       ["Editor (optional)", "PyCharm (Community is fine). The project opens directly; VS Code also works."]],
      [3.6, 13])
note("<b>Solver note.</b> The exact MIP uses PuLP with the CBC solver. <font face='Courier'>requirements.txt</font> pins <font face='Courier'>pulp&lt;4</font> because PuLP 4.0 changed its API. "
     "If PuLP is missing or incompatible the code automatically falls back to an exhaustive exact search, which is still exact but only practical up to about 12-14 nodes. "
     "You may see a harmless <i>DeprecationWarning</i> about PULP_CBC_CMD; ignore it.")

# ---------------- 4 ----------------
h1("4. Build: install and verify")
h2("4.1 Command line (any OS)")
p("<b>Step 1 - unzip</b> <font face='Courier'>greenplace_python_mvp.zip</font> anywhere (avoid paths with unusual characters). Open a terminal in the <font face='Courier'>greenplace_mvp</font> folder.")
p("<b>Step 2 - create and activate a virtual environment.</b>")
code("""# macOS / Linux
python3 -m venv .venv
source .venv/bin/activate

# Windows (PowerShell)
python -m venv .venv
.venv\\Scripts\\Activate.ps1
#   if PowerShell blocks scripts:  Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
# Windows (cmd.exe)
python -m venv .venv
.venv\\Scripts\\activate.bat""")
p("<b>Step 3 - install the dependencies.</b> This installs networkx, numpy, pandas, matplotlib, scipy, pulp (<4) and pytest.")
code("""pip install --upgrade pip
pip install -r requirements.txt""")
p("<b>Step 4 - verify the build.</b> This is the check that everything works on your machine.")
code("pytest -q")
p("Expected last line (it takes about 3 seconds):")
code("64 passed, ... warnings in ~3s")
p("If it prints <font face='Courier'>64 passed</font> the build is good. Warnings are normal. If any test fails, go to Troubleshooting (Section 11) before continuing.")
h2("4.2 PyCharm")
bullets(["<b>File &gt; Open</b> and choose the <font face='Courier'>greenplace_mvp</font> folder (the one containing <font face='Courier'>greenplace_mvp.iml</font>).",
         "<b>Settings &gt; Project &gt; Python Interpreter &gt; Add Interpreter &gt; Add Local Interpreter &gt; Virtualenv &gt; New</b>. Accept the prompt to install <font face='Courier'>requirements.txt</font>.",
         "The run-configuration drop-down (top right) now lists 12 ready-made configurations: <b>0. Full Demo</b>, <b>0b. Full Demo (Quick)</b>, 1-4 (individual stages), <b>5. Fetch Real Topologies</b>, "
         "<b>6. Benchmark (Full)</b>, <b>6b. Benchmark (Quick)</b>, <b>7. Analyze Benchmark</b>, <b>8. Place On Topology</b>, and <b>All Tests (pytest)</b>. Select one and press the green run button.",
         "Run <b>All Tests (pytest)</b> first; it should be all green."])

# ---------------- 5 ----------------
h1("5. Run the project: every command and its expected output")
p("Run all commands from the <font face='Courier'>greenplace_mvp</font> folder with the virtual environment active. Everything is seeded, so results are reproducible. "
  "Plots and data are written to <font face='Courier'>outputs/</font>.")
h2("5.1 Quick demo - synthetic pipeline, about 10 seconds")
code("python demo.py --quick")
p("Runs all four stages and prints a summary read back from the JSON each stage wrote. Typical output in quick mode:")
code("""Phase 1 - NSGA-II vs. exact ILP (validation topologies):
    tiny_4node  gap = +0.00%     small_8node  gap = +0.00%     small_10node  gap = +0.00%
Phase 2 - runtime elastic manager (96 timesteps, 2 synthetic days):
    Always-on baseline energy   : 1115.0 W
    Average managed energy      : 499.6 W
    Average energy savings      : 55.2%
    Total switch migrations     : 84
    Delay-bound violations      : 0 (must be 0)
Migration-aware objective (2 seeds): ...""")
p("What to point out: NSGA-II matches the exact solver (0.0% gap) on small networks; the runtime manager saves energy with <b>zero delay violations</b>. "
  "Remember these are synthetic topologies (see the cover warning).")
h2("5.2 Full demo - about 1 minute")
code("python demo.py")
p("Same pipeline with the full settings: 56.1% runtime savings, 54 migrations, and a 5-seed migration-aware comparison (11.0 vs 2.4 migrations). "
  "Plots written: <font face='Courier'>outputs/pareto_small_10node.png</font> (NSGA-II front vs the exact optimum), "
  "<font face='Courier'>outputs/runtime_trace.png</font> (traffic, active controllers and energy over two days), "
  "<font face='Courier'>outputs/pareto_migration_aware.png</font> (front colour-coded by migration burden).")
h2("5.3 The four stages individually")
code("""# writes synthetic fixtures to data/topologies/
python scripts/generate_topologies.py
# exact solver vs NSGA-II: the validation experiment
python scripts/run_ilp_vs_nsga2.py
# offline placement -> runtime manager over a diurnal trace
python scripts/run_runtime_demo.py
# does the 3rd objective reduce migrations? (multi-seed)
python scripts/run_migration_aware_demo.py""")
h2("5.4 Place controllers on a real network")
code("""python scripts/place_on_topology.py data/real_topologies/Cesnet201006.gml""")
p("Takes about 2 seconds. Real output from our run:")
code("""Cesnet201006: 45 nodes, 56 links, delay model: geographic
delay bound 0.79 ms | capacity 9 switches/controller | peak-load pool >= 5 |
  delay-driven minimum ~3 controllers

[offline migration-burden pick]  pool of 5: [7, 16, 31, 41, 44]
  worst-case delay 0.75 ms (bound 0.79) | always-on 1010.0 W | with runtime manager 902.7 W
  | 14.0 migrations/trace | violations 0   (held-out traces)
[simulation-in-the-loop pick (slack 2%)]  pool of 5: [7, 16, 31, 41, 44]
  ...
Wrote outputs/placement_Cesnet201006.json""")
p("Reading it: the pool is sized for peak load (5 controllers); the runtime manager then sleeps what it safely can, taking energy from 1010 W to about 903 W; the worst-case delay stays under the bound; "
  "the held-out traces were not used when choosing the pool. When both picks coincide, the Pareto front offered no better alternative for that network.")
h2("5.5 Benchmark against existing approaches on real topologies")
code("""# 32 networks (11-35 nodes), 2 seeds; roughly 7-10 minutes on one core
python scripts/run_benchmark.py --quick
python scripts/analyze_benchmark.py --tag quick  # tables + statistics + figures""")
p("Output goes to <font face='Courier'>outputs/benchmark/quick/</font>: <font face='Courier'>BENCHMARK_REPORT.md</font> and "
  "<font face='Courier'>figures/*.png</font> (static_gap, lifecycle_comparison, migrations_scatter, scalability). The run checkpoints after every network, so if you stop it and re-run the same command it resumes. "
  "Our quick run produced, for example, mean migrations 36.8 for GreenPlace against 42.3 for NSGA-II energy+delay, with lifecycle energy within 0.2% of it. "
  "That is a smaller gap than in the full study; the quick pass uses smaller networks, fewer seeds and a smaller search budget, so do not quote it in place of the full results.")
note("The benchmark prints progress per network, for example <font face='Courier'>[17/32] Karen  n=23 K=6 cover=2  4.6s</font>. "
     "<b>K</b> is the pool size needed for peak load; <b>cover</b> is the smallest number of controllers that meets the delay bound alone.")
h2("5.6 Show the finished study without re-running it")
p("Open <font face='Courier'>outputs/benchmark/main/BENCHMARK_REPORT.md</font> (tables and statistics) and the four PNGs in <font face='Courier'>outputs/benchmark/main/figures/</font>. "
  "<font face='Courier'>outputs/benchmark/SENSITIVITY_REPORT.md</font> holds the sensitivity grid. <font face='Courier'>BENCHMARKING.md</font> in the project root explains the protocol and results in prose.")

# ---------------- 6 ----------------
h1("6. A 10-minute live demonstration script")
p("Prepare beforehand: activate the environment, run <font face='Courier'>pytest -q</font> once, and open <font face='Courier'>outputs/benchmark/main/figures/</font> in an image viewer. "
  "Every step below works offline.")
table([["Min", "Do", "Say / point out"],
       ["0-1", "Show the architecture figure (or Section 1 of this guide).", "Two phases: offline placement under a <b>hard</b> delay bound, then a runtime manager that sleeps and wakes controllers. The question asked: does making the offline search aware of runtime migration cost reduce switch migrations without costing energy?"],
       ["1-2", "<font face='Courier'>pytest -q</font>", "85 tests pass: the exact solver is checked against an independent brute force; the Pareto front is checked for true non-domination in 3-D; the delay bound is never violated, including with hysteresis."],
       ["2-4", "<font face='Courier'>python demo.py --quick</font>; open <font face='Courier'>outputs/runtime_trace.png</font>", "NSGA-II reproduces the exact optimum (0.0% gap) on small cases. The trace plot shows controllers stepping down at night and up at peak, with zero delay violations. <b>Say clearly that this is synthetic data.</b>"],
       ["4-6", "<font face='Courier'>python scripts/place_on_topology.py data/real_topologies/Cesnet201006.gml</font>", "A real European research network: 45 nodes, pool of 5, runtime manager cuts 1010 W to ~903 W, delay stays within the bound, evaluated on traces not used for selection."],
       ["6-9", "Open <font face='Courier'>outputs/study3/main/RESULTS_SUMMARY.md</font> and the figures in <font face='Courier'>outputs/study3/main/figures/</font> (fig_methods, fig_shift)", f"The headline, honestly: static energy {_S['greenplace']['gap_mean_pct']:.1f}% above the MIP lower bound (not best); lifecycle energy tied with NSGA-II and the MIP set; <b>fewer migrations: {_L['greenplace']['migrations']:.1f} vs {_L['nsga2_2obj']['migrations']:.1f} for NSGA-II ({sg(_TM['nsga2_2obj']['pct_mean'],0)}%, Holm p {pv(_TM['nsga2_2obj']['p_holm'])})</b>; vs the exact-MIP set the median is {sg(_TM['exact_mip']['pct_median'],0)}% with an uncertain mean (CI includes zero). The advantage holds on the synthetic traffic shifts and GEANT, but is small on the real Abilene trace."],
       ["9-10", "Open RESULTS_SUMMARY.md sections on selection rules and the scale study", f"Limits: the offline proxy is weak (Spearman {R['selector']['proxy_rho']['mean']:.2f}); runtime hysteresis is the biggest effect; a learned surrogate selector did <i>not</i> beat the proxy; simulation-based selection lowers energy but not migrations; the exact MIP solves up to 400 nodes to optimality in under a minute, so the heuristic is not needed for scale. Baselines are our re-implementations; the power model is not calibrated; no emulation was run."]],
      [1.2, 5.6, 9.8])
h2("If you have extra time")
bullets(["Run <font face='Courier'>python scripts/run_benchmark.py --tag demo --names Abilene Geant2012 Sprint --seeds 2</font> then <font face='Courier'>python scripts/analyze_benchmark.py --tag demo</font> on a few named networks (a minute or two). Always give a new <font face='Courier'>--tag</font> so the shipped <font face='Courier'>main</font> results are not touched.",
         "Show the slack dial: <font face='Courier'>python scripts/place_on_topology.py data/real_topologies/Cesnet201006.gml --slack 0.05</font> accepts slightly more energy for fewer migrations.",
         "Open <font face='Courier'>outputs/benchmark/SENSITIVITY_REPORT.md</font> (earlier 3-seed grid): the migration advantage holds directionally in all 9 capacity x delay settings (7-46%) but is individually significant in only 2."])

# ---------------- 7 ----------------
h1("7. How to read and present the results honestly")
h2("Results to quote (v3 study: 46 real networks, 10 seeds)")
S.append(Paragraph("Source of every number: <font face='Courier'>outputs/study3/main/RESULTS_SUMMARY.md</font> (generated from the raw rows). Differences are paired by network; p-values are Holm-adjusted.", B))
table([["Question", "Finding"],
       ["Static energy", f"Gap to the MIP <b>lower bound</b>: GreenPlace {_S['greenplace']['gap_mean_pct']:.1f}%, NSGA-II energy+delay {_S['nsga2_2obj']['gap_mean_pct']:.1f}%, NSGA-III {_S['nsga3']['gap_mean_pct']:.1f}%, single-objective GA {_S['ga_energy']['gap_mean_pct']:.1f}% (but delay-infeasible on {_S['ga_energy']['infeasible_topologies']} networks). The same 3-objective front with a minimum-energy pick is {_S['greenplace_energypick']['gap_mean_pct']:.1f}%. GreenPlace is <b>not</b> best here."],
       ["Lifecycle energy", f"Tied with NSGA-II ({sg(_TE['nsga2_2obj']['pct_mean'])}%, p {pv(_TE['nsga2_2obj']['p_holm'])}) and the MIP set ({sg(_TE['exact_mip']['pct_mean'])}%, p {pv(_TE['exact_mip']['p_holm'])}). GreCo-style is {(_L['greco']['avg_energy_w']/_L['greenplace']['avg_energy_w']-1)*100:.0f}% worse; betweenness {(_L['betweenness']['avg_energy_w']/_L['greenplace']['avg_energy_w']-1)*100:.0f}% worse."],
       ["Migrations per day", f"GreenPlace {_L['greenplace']['migrations']:.1f} vs NSGA-II {_L['nsga2_2obj']['migrations']:.1f} ({sg(_TM['nsga2_2obj']['pct_mean'],0)}%, 95% CI [{sg(_TM['nsga2_2obj']['pct_ci'][0],0)}, {sg(_TM['nsga2_2obj']['pct_ci'][1],0)}], Holm p {pv(_TM['nsga2_2obj']['p_holm'])}); vs NSGA-III {sg(_TM['nsga3']['pct_mean'],0)}%; vs the exact-MIP set {_L['exact_mip']['migrations']:.1f} (mean {sg(_TM['exact_mip']['pct_mean'],0)}% with CI including zero, median {sg(_TM['exact_mip']['pct_median'],0)}%, Holm p {pv(_TM['exact_mip']['p_holm'])}). No difference from k-center or GreCo-style."],
       ["Traffic shift / real traces", f"Advantage over NSGA-II on the 7 non-training scenarios: {sg(_sh['two_peak']['gp_vs_nsga2_migs_pct'],0)}% (two-peak), {sg(_sh['bursty']['gp_vs_nsga2_migs_pct'],0)}% (bursty), {sg(_sh['geant']['gp_vs_nsga2_migs_pct'],0)}% (GEANT) but only {sg(_sh['abilene']['gp_vs_nsga2_migs_pct'],0)}% on Abilene (CI includes zero). Versus the MIP set it is not consistent (bursty and Abilene go the other way)."],
       ["Ablation", "Neither the 3rd objective alone nor the migration-aware pick alone helps significantly; the combination does. Runtime hysteresis is the largest effect."],
       ["Selection rules", f"Proxy {_sel['proxy']['migs_diurnal']:.1f} migrations; simulation pick {_sel['sil']['migs_diurnal']:.1f} (lower energy, not fewer migrations); learned surrogate {_sel['surrogate']['migs_diurnal']:.1f} (no better); oracle {_sel['oracle']['migs_diurnal']:.1f}."],
       ["Scale", "Exact MIP: optimal in under a minute up to 400 nodes; fixed-budget metaheuristics remain tens of percent above the bound. The heuristic is not needed for scalability."],
       ["Power-model sensitivity", "Elastic saving falls as the per-hop link power grows or if sleeping controllers draw idle power; fewer migrations do not change energy even at high transition costs."]],
      [4.2, 12.4])
note("<b>Correction to earlier documents.</b> The MIP optimises over free switch-to-controller assignment, but every method (including the MIP's own set) is scored with nearest-controller assignment. "
     "So the MIP set is not guaranteed optimal under the scoring (on 10 of 46 networks a heuristic scored up to 3.3% better) and its objective is only a lower bound. Gaps in this guide's v3 numbers are against that bound. The older 3-seed numbers (6.4% gap, 39.8 vs 53.7 migrations) used the MIP set as the reference and are kept only in <font face='Courier'>outputs/benchmark/</font>.")
h2("Statements to avoid")
bullets(["Do not say GreenPlace \"beats published algorithms\". The baselines are our re-implementations of the algorithmic ideas, not the authors' code.",
         "Do not quote 56.1% savings or 78.2% fewer migrations as general performance; they come from synthetic topologies and 5 seeds.",
         "Do not call the exact MIP set \"the optimum\" or claim an energy saving from fewer migrations; and do not claim emulation validation (the Mininet harness is untested).",
         "Do not say GreenPlace saves more energy than the best energy-focused methods; lifecycle energy is statistically tied.",
         "Do not present the quick-benchmark numbers as the study result."])
h2("What the study does not cover")
p("Controller load measured on real controllers (total network traffic is only a proxy); a calibrated power model; an emulated or physical SDN testbed (the Mininet/Ryu harness in emulation/ was written but never run); the authors' own code for any baseline; RL-based placement. These are listed as limitations in paper draft v3.")

# ---------------- 8 ----------------
h1("8. Run GreenPlace on your own network")
p("Export or download a topology as GML (the Internet Topology Zoo format works best; nodes with <font face='Courier'>Latitude</font>/<font face='Courier'>Longitude</font> give geographic delays, otherwise 1 ms per link is assumed). Then:")
code("""python scripts/place_on_topology.py my_network.gml
python scripts/place_on_topology.py my_network.gml --bound-ms 12 --capacity 8 --slack 0.05
python scripts/place_on_topology.py my_network.gml --pop 60 --gens 100 --seed 3""")
table([["Flag", "Meaning", "Default"],
       ["--bound-ms", "Hard switch-to-controller delay bound in milliseconds", "0.35 x delay-diameter"],
       ["--capacity", "Switches per controller", "ceil(n / 6)"],
       ["--slack", "Energy slack for the simulation-in-the-loop pick (the energy-vs-stability dial)", "0.02 (2%)"],
       ["--pop / --gens / --seed", "NSGA-II population, generations, random seed", "see --help"],
       ["--out", "JSON output path", "outputs/placement_&lt;name&gt;.json"]], [3.6, 9, 4])
p("If the delay bound leaves no elastic headroom (for example GEANT2012 at default settings) both picks coincide and the runtime manager has nothing to sleep; the tool reports that rather than hiding it. "
  "To get more real networks run <font face='Courier'>python scripts/fetch_real_topologies.py --all</font> (needs internet; downloads 250+ GML files into <font face='Courier'>data/real_topologies/</font>). "
  "Please cite the Topology Zoo paper (Knight et al., IEEE JSAC 29(9), 2011) if you publish with them.")

# ---------------- 9 ----------------
h1("9. Reproduce the full study")
h2("9a. The v3 study (primary)")
note("The package ships finished v3 results in <font face='Courier'>outputs/study3/</font> and <font face='Courier'>outputs/scaling/</font>. The runner resumes from <font face='Courier'>done_shard*.txt</font>, so to reproduce from scratch use a new tag (e.g. <font face='Courier'>--tag mine</font>) or move the shipped folders aside. The Docker route gives the exact pinned environment: <font face='Courier'>docker build -t greenplace . &amp;&amp; docker run --rm greenplace</font>.")
code("""make test                                            # 85 tests
make demo                                            # ~40 s: live run + HTML dashboard (outputs/demo/dashboard.html)
make quick                                           # ~3 min smoke study + analysis (tag 'quick')
# full study: ~2 h on two cores
python scripts/run_study3.py --tag main --seeds 10 --shard 0 --nshards 2 &
python scripts/run_study3.py --tag main --seeds 10 --shard 1 --nshards 2 &
python scripts/run_simnsga_sil.py --tag main         # small-network simulation-in-search variant (~1.5 h)
python scripts/compute_mip_lb.py                     # MIP lower bound per network
python scripts/run_scaling.py --mip-limit 60         # scale study (~1 h; Kdl 709 nodes is slow)
python scripts/run_scaling.py --mip-uncapped-only
python scripts/run_scaling.py --size-hint
python scripts/summarize_scaling.py
python scripts/analyze_study3.py --tag main
python scripts/make_figures3.py --tag main
python scripts/make_results_summary.py --tag main""")
p("The paper draft v3 is generated from <font face='Courier'>results.json</font> by <font face='Courier'>paper_src/build_paper3.js</font>, so every number can be traced to a result file. "
  "The Mininet/Ryu emulation harness in <font face='Courier'>emulation/</font> has <b>not</b> been run; see its README.")
h2("9b. The earlier 3-seed study (kept for continuity)")
note("<b>Do this first.</b> The package already contains the finished study in <font face='Courier'>outputs/benchmark/</font>, and the benchmark <i>resumes</i> from existing rows, so re-running with the same tags would skip everything. "
     "To reproduce from scratch, move the shipped results aside: <font face='Courier'>mv outputs/benchmark outputs/benchmark_shipped</font> (Windows: <font face='Courier'>ren outputs\\benchmark benchmark_shipped</font>).")
p("Total about 20-30 minutes on one CPU core for the main run, plus time for the extras. Each command checkpoints per network and resumes if interrupted. Run them in the order shown. Continuation lines ending in a backslash are one command: on Windows put it on one line.")
code("""python scripts/run_benchmark.py --tag main --seeds 3 --nsga-pop 40 --nsga-gens 60
python scripts/run_benchmark.py --tag control --seeds 3 --nsga-pop 40 --nsga-gens 60 \
    --methods nsga2_2obj_migsel
python scripts/run_benchmark.py --tag sil --seeds 3 --nsga-pop 40 --nsga-gens 60 \
    --methods greenplace_sil nsga2_2obj_sil
python scripts/run_benchmark.py --grid
python scripts/analyze_benchmark.py --tag main --extra-tags control sil
python scripts/analyze_sensitivity.py""")
p("Outputs: <font face='Courier'>outputs/benchmark/main/BENCHMARK_REPORT.md</font>, <font face='Courier'>outputs/benchmark/main/figures/*.png</font>, <font face='Courier'>outputs/benchmark/SENSITIVITY_REPORT.md</font>. "
  "Seeds 0-2 are used for evaluation; seeds 100-101 are SIL training traces (disjoint, enforced by an assertion in the code). "
  "Because of random-number and platform differences, exact decimals can differ slightly between machines; the conclusions and significance pattern should not.")
note("To run in the background on Linux/macOS: <font face='Courier'>nohup python scripts/run_benchmark.py --tag main --seeds 3 --nsga-pop 40 --nsga-gens 60 &gt; main.log 2&gt;&amp;1 &amp;</font>. "
     "On Windows use a separate terminal window and leave it open.")

# ---------------- 10 ----------------
h1("10. Code map")
table([["File (greenplace/)", "Role"],
       ["topology.py", "Load Topology Zoo GML (handles parallel-link quirks), synthetic and backbone-like generators"],
       ["delay.py", "Cached all-pairs shortest-path delay and hop counts; coverage_priority (shared sleep/wake ranking)"],
       ["power.py", "Control-plane energy: active controllers x p_c + control-link hops x p_l"],
       ["placement.py", "Placement data structure, feasibility, energy and migration-burden evaluation"],
       ["ilp_solver.py", "Exact MIP (PuLP/CBC) with exhaustive-search fallback and time limit"],
       ["nsga2.py", "Self-written NSGA-II: constrained domination, crowding distance, optional 3rd objective"],
       ["optimizer.py", "Single entry point choosing exact or NSGA-II"],
       ["runtime.py", "Runtime manager: EMA, dwell-time hysteresis, capacity-aware reassignment, delay guard; diurnal trace generator"],
       ["selection.py", "select_migration_aware (offline proxy) and select_by_simulation (SIL)"],
       ["baselines.py", "Re-implementations: random, k-center, k-median, greedy cover, betweenness, GreCo-style, GA"],
       ["lifecycle.py / benchmark.py", "Lifecycle simulation with a shared runtime manager; benchmark driver and settings derivation"],
       ["metrics.py", "2-D/3-D hypervolume, IGD, CSV/JSON export, plots"],
       ["moea.py", "NSGA-III, binary MOPSO, EnPlace-style partition heuristic (our re-implementations)"],
       ["traffic.py", "Six synthetic traffic scenarios and real GEANT / Abilene day traces"],
       ["simnsga.py / study3.py", "NSGA-II with simulated-migration objective; the v3 study harness"]], [4.6, 12])

# ---------------- 11 ----------------
h1("11. Troubleshooting")
table([["Symptom", "Cause and fix"],
       ["<font face='Courier'>python</font> not found / wrong version", "Use <font face='Courier'>python3</font> on macOS/Linux or <font face='Courier'>py -3</font> on Windows; reinstall Python with PATH ticked; check <font face='Courier'>python --version</font> is 3.10+."],
       ["PowerShell: running scripts is disabled", "<font face='Courier'>Set-ExecutionPolicy -Scope CurrentUser RemoteSigned</font>, or use cmd.exe and <font face='Courier'>activate.bat</font>."],
       ["<font face='Courier'>pip install</font> fails behind a proxy or offline", "Set <font face='Courier'>HTTPS_PROXY</font> or install from a local wheel cache. After install, no internet is needed."],
       ["PuLP / CBC errors, or MIP says unavailable", "Run <font face='Courier'>pip install \"pulp&lt;4\"</font>. If CBC cannot run, the exact solver falls back to exhaustive search automatically (fine below ~14 nodes); the benchmark's exact-MIP baseline needs CBC for larger networks."],
       ["DeprecationWarning about PULP_CBC_CMD", "Harmless; comes from PuLP 3.x. It does not affect results."],
       ["A GML file fails to load (parallel links)", "The loader injects <font face='Courier'>multigraph 1</font> automatically for Topology Zoo files. For hand-made GML ensure each node has an <font face='Courier'>id</font> and edges use <font face='Courier'>source</font>/<font face='Courier'>target</font>."],
       ["Plots do not appear / no display", "Scripts save PNGs to <font face='Courier'>outputs/</font> and do not need a display. On servers set <font face='Courier'>MPLBACKEND=Agg</font>."],
       ["Benchmark seems slow", "Expected: about 20-30 minutes for the full study on one core. Use <font face='Courier'>--quick</font>, or <font face='Courier'>--names</font> to run a few networks. It resumes if interrupted."],
       ["Different decimals from this guide", "Small floating-point and library-version differences are normal. Check that the conclusions (and 0 delay violations) hold."],
       ["fetch_real_topologies.py cannot download", "It uses the GitHub mirror mroughan/InternetTopologyZoo. If blocked, skip it: 67 networks are already in <font face='Courier'>data/real_topologies/</font>."],
       ["PyCharm shows an unresolved interpreter", "Settings &gt; Python Interpreter &gt; Add Local &gt; Virtualenv, point it at the project's <font face='Courier'>.venv</font>; mark <font face='Courier'>tests/</font> as Test Sources Root (already set)."]],
      [5, 11.6])

# ---------------- 12 ----------------
h1("12. Quick reference card")
code("""# one-time setup
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
pytest -q                                               # expect: 85 passed

# demos
python demo.py --quick                                  # ~10 s, synthetic pipeline
python demo.py                                          # ~1 min
python scripts/place_on_topology.py data/real_topologies/Cesnet201006.gml   # real network, ~2 s

# benchmark on real topologies
python scripts/run_benchmark.py --quick\npython scripts/analyze_benchmark.py --tag quick
python scripts/run_benchmark.py --tag demo --names Abilene Geant2012 Sprint --seeds 2
python scripts/analyze_benchmark.py --tag demo
# finished v3 study: outputs/study3/main/RESULTS_SUMMARY.md
make quick                                              # smoke run of the v3 harness""")
p("<i>Companion files: the literature review slide deck (PDF) for background and the paper draft for the full write-up. "
  "All statistics in this guide are generated from the project's own result files (outputs/study3/main/results.json).</i>")

def footer(c, d):
    c.saveState(); c.setFont("Helvetica", 8); c.setFillColor(colors.grey)
    c.drawString(2 * cm, 1.2 * cm, "GreenPlace - Build, Run and Demonstrate"); c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Page {d.page}"); c.restoreState()
doc = SimpleDocTemplate("GreenPlace_Build_Run_Demo_Guide.pdf", pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=2 * cm, bottomMargin=2 * cm,
                        title="GreenPlace - Build, Run and Demonstrate the Project", author="")
doc.build(S, onFirstPage=lambda c, d: None, onLaterPages=footer)
