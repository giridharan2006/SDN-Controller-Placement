# Benchmarking GreenPlace against existing approaches on real topologies

> **v3 update.** The primary study is now `scripts/run_study3.py` (10 seeds, 19 methods/variants, 8 traffic scenarios incl. real GÉANT/Abilene traces, hypervolume/IGD, ablations, scale study); see README Section 9 and `outputs/study3/main/RESULTS_SUMMARY.md`. The 3-seed study described below is kept for continuity (`outputs/benchmark/`). **Correction:** wherever this file says the MIP gives the "proven optimum", read "a lower bound": the MIP optimises free assignment while methods are scored with nearest-controller assignment, so on 10/46 networks a heuristic scored up to 3.3% better than the MIP's own set.

This guide explains how to reproduce the comparison, what it does and does not show, and the results
we obtained. **Read "What this does not show" before quoting any number.**

## Run it yourself (3 commands)

```bash
python scripts/fetch_real_topologies.py        # real networks from the Internet Topology Zoo (add --all for 250+)
python scripts/run_benchmark.py --quick        # ~5 min: small networks, 2 seeds   (omit --quick for the full study)
python scripts/analyze_benchmark.py --tag quick   # -> outputs/benchmark/quick/BENCHMARK_REPORT.md + figures
```

Full study used for the results below (46 networks, 11-60 nodes, ~20 min on one CPU core):

```bash
python scripts/run_benchmark.py --tag main --seeds 3 --nsga-pop 40 --nsga-gens 60
python scripts/run_benchmark.py --tag control --seeds 3 --nsga-pop 40 --nsga-gens 60 --methods nsga2_2obj_migsel
python scripts/run_benchmark.py --grid                                  # sensitivity grid
python scripts/run_benchmark.py --tag sil --seeds 3 --nsga-pop 40 --nsga-gens 60 --methods greenplace_sil nsga2_2obj_sil
python scripts/analyze_benchmark.py --tag main --extra-tags control sil
python scripts/analyze_sensitivity.py
```

## What is compared

| Method | What it is | Lineage |
|---|---|---|
| Random feasible | sanity floor | - |
| k-center, k-median | latency-optimal placement (greedy + swap search) | Heller et al. 2012 |
| Greedy cover | fewest controllers meeting the delay bound | Ul Huque et al. 2017 |
| Betweenness | top-centrality nodes | common heuristic |
| GreCo-style | over-provisioned deployment, greedily switch controllers off | GreCo (Ruiz-Rivera et al. 2015) |
| Single-objective GA | minimise energy, delay as a penalty | EHACP-GA (Mohanty & Sahoo 2025) |
| Exact MIP | energy-optimal reference (CBC, proven optimal in every run) | Kondo et al.-style formulation |
| NSGA-II energy+delay | multi-objective, no migration awareness | Jalili-style lineage |
| CONTROL | the 2-objective search + GreenPlace's migration-aware *pick* | isolates search vs. selection |
| **GreenPlace** | 3-objective NSGA-II (energy, delay, migration burden) + migration-aware pick (offline proxy) | this project |
| CONTROL (sim.) | 2-objective search + simulation-in-the-loop pick | isolates the search under SIL selection |
| **GreenPlace-SIL** | same 3-objective search, but the pick is made by *simulating* each candidate pool on training traces | this project, improved selection (Section 9) |

**These are our re-implementations of the algorithmic ideas, not the original authors' code.** They answer
"how does the GreenPlace *approach* fare against these *approaches* on a common footing?" - not "does it beat
paper X's published numbers" (those use different simulators, topologies and parameters). EnPlace's partitioning,
Adekoya's NSGA-III + ISMDA and RL-based placement are **not** re-implemented.

### Two evaluations
1. **Static placement quality** - minimise energy subject to the hard delay bound (what most placement papers measure).
2. **Lifecycle** - every method supplies a controller pool sized to serve peak load; the *same* runtime elastic manager then
   operates each pool over a 96-step diurnal trace. Differences are therefore due to placement quality, not to who has a runtime phase.

Per-topology settings are derived, not hand-tuned, and were fixed before the full run: delay bound = 0.35 x delay-diameter,
controller capacity = ceil(n/6), identical power model. Statistics treat the **topology** as the unit of replication; GreenPlace-vs-baseline
comparisons use paired Wilcoxon tests with Holm correction, alongside win/tie/loss counts and bootstrap CIs.

## Results (46 real topologies; full report: `outputs/benchmark/main/BENCHMARK_REPORT.md`)

**1. Static placement: GreenPlace is not the best, by design.** Mean energy gap to the proven optimum: exact 0%, single-objective GA 0.8%
(but delay-infeasible on 3/46 networks), NSGA-II energy+delay 4.2%, **GreenPlace 6.4%** (median 3.2%), k-center/greedy-cover ~11%, k-median 14%,
GreCo-style 39%, betweenness 167%. GreenPlace knowingly accepts up to 15% more static energy in exchange for placements that are cheaper to run.
At these sizes the exact MIP also solves in ~0.13 s vs ~1.8 s for NSGA-II, so we have **no evidence here that a heuristic is needed below 60 nodes**.

**2. Lifecycle energy: GreenPlace is statistically tied with the best energy-focused methods.** Energy relative to GreenPlace (geometric mean):
exact MIP 1.000 [0.988-1.013], NSGA-II 0.998, GA 0.993 - indistinguishable. It is significantly lower than random (+2.7%), k-center (+2.5%),
betweenness (+8.3%) and GreCo-style (+11.4%) (Holm p < 0.05).

**3. Runtime switch migrations: where GreenPlace's advantage lies.** Mean migrations per trace: GreenPlace **39.8**, GreCo-style 37.6, k-center 44.9,
2-obj control 50.1, NSGA-II energy+delay 53.7, exact MIP 55.0, k-median 56.2, GA 59.2, greedy-cover 65.7, betweenness 151.4.
Significantly fewer than NSGA-II (-26%, Holm p = 0.007; fewer on 31/46 networks, more on 12), k-median, greedy-cover, GA, random, betweenness. Against the exact MIP the reduction (55.0 -> 39.8, -28%) is **not significant after Holm correction** (p = 0.060).
**Not** significantly different from k-center or GreCo-style - and GreCo's low count comes with +11% energy because it rarely sleeps anything.

**4. Pareto view.** In (lifecycle energy, migrations), among the original 11 methods GreenPlace was non-dominated on **25/46** networks (k-center 20, exact MIP 18).
Counts fall as competitors are added: with the two simulation-pick variants included (13 methods), GreenPlace is non-dominated on 19/46 and GreenPlace-SIL on 31/46.
It is a better *trade-off* position, not a dominating one.

**5. Control experiment - is it the search or just the pick rule?** Applying the migration-aware pick to the plain 2-objective search cuts migrations only
from 53.7 to 50.1 (~7%); making migration burden an objective *in the search* reaches 39.8 (GreenPlace fewer/tie/more than the control: 29/7/10, raw Wilcoxon p = 0.001; Holm p = 0.007).
So the third objective itself does real work.

**6. But the proxy is weak.** The offline migration-burden score correlates only modestly with realised runtime migrations (mean within-topology Spearman 0.26, 95% CI [0.13, 0.38]).
That is consistent with the effect being real but moderate.

**7. The runtime hysteresis is the largest single effect.** Removing EMA smoothing + dwell time raises migrations from 39.8 to 101.1 (+154%) and controller state changes from 5.7 to 14.2.

**8. Sensitivity (`outputs/benchmark/SENSITIVITY_REPORT.md`, 9 capacity x delay-bound settings, 10 networks).** GreenPlace has fewer mean migrations than the 2-objective baseline in all 9 settings,
but the reduction ranges from ~7% to ~46%; it is individually significant in only 2 of 9 (both at the tightest capacity) and roughly one survives a multiple-comparison correction.
Runtime elasticity saves 6-25% versus operating the same pool always-on (rising with how much peak-load pool exceeds the delay-driven minimum). GreenPlace's lifecycle energy stays within ~2% of the exact optimum throughout.

## 9. Improvement experiment: simulation-in-the-loop (SIL) selection - pre-registered, hypothesis NOT supported

**Motivation.** The offline migration-burden proxy predicts realised migrations only weakly (rho ~ 0.26). SIL replaces the proxy at pick time: each candidate
pool on the Pareto front is rehearsed through the real runtime manager on *training* traces, and the pick is the one with the fewest simulated migrations among
candidates within 2% of the best simulated lifecycle energy (`greenplace.selection.select_by_simulation`).

**Design fixed before running:** same 3-objective fronts as GreenPlace (identical seeds); candidates = feasible members within 1.25x the cheapest static energy (max 10);
training traces = seeds 100-101, never used for evaluation (seeds 0-2; enforced by an assertion); slack 2%. *Hypothesis: fewer migrations than the proxy pick at <=2% extra energy.*

**Result.**
- **Migrations vs the proxy pick: no improvement** (40.2 vs 39.8; SIL fewer/tie/more on 21/10/15; Holm p = 1.0). The hypothesis is **not supported**.
- **Unplanned finding:** the same migrations at **~1.6% lower lifecycle energy** than the proxy pick (Holm p = 0.0001) - small but consistent.
- vs NSGA-II energy+delay: **40.2 vs 53.7 migrations** (33 fewer / 3 tie / 10 more; Holm p = 0.003) *and* 1.4% less energy (p = 0.036).
  vs exact MIP: 55.0 migrations (p = 0.028) and 1.6% lower energy (not significant after correction, p = 0.11). Not significantly different from k-center or GreCo-style on migrations (GreCo: +13% energy, k-center: +4%).
- **Control (2-objective search + SIL pick):** 50.0 vs 40.2 migrations (27/5/14; Holm p = 0.10) - suggestive that the 3-objective *search* still helps under SIL selection, not conclusive.
- **Pareto position:** non-dominated on 31/46 networks among 13 methods (best).
- **Exploratory, post-hoc (not part of the pre-registered claim):** the slack is a smooth energy-vs-stability dial: slack 0% -> 48.0 migrations (lifecycle energy 0.980 x exact MIP); 2% -> 40.2 (0.984); 5% -> 34.0 (0.992).
- Cost: selection is negligible next to the NSGA-II search (~1.5 s per run on these sizes).

**Caveats.** Training and evaluation traces come from the same synthetic generator (different noise draws only), so this does not test robustness to a different traffic pattern;
the energy gain is small; the slack is a tunable choice, not a discovered constant.

**Use it on your own network:** `python scripts/place_on_topology.py my_network.gml` prints and saves the recommended pool both ways (offline pick and SIL pick) with held-out evaluation.
Where the delay bound leaves no elastic headroom (e.g. GEANT2012 at default settings) both picks coincide and the runtime manager has nothing to sleep - the tool shows that honestly.

## What this does NOT show
- **It does not show GreenPlace beats the published algorithms** - only our re-implementations of their ideas, on our power model and delay-bound formulation.
- **It does not show lower energy than the best energy-focused methods.** Energy is tied; the gain is in migration stability (and Pareto position).
- **The earlier synthetic-topology demo numbers (56.1% runtime energy savings, 78.2% fewer migrations) do not generalise** to real networks under this protocol: here the figures are ~13% runtime savings versus the same pool always-on, and ~26% fewer migrations than the NSGA-II energy+delay baseline. Do not quote the synthetic numbers as general performance.
- All methods satisfied the delay bound in every lifecycle run (pools were made feasible by construction), so delay violations do not discriminate between methods.
- Traffic is a synthetic diurnal curve; capacity and the delay bound are modelling choices (hence the sensitivity grid); 9/46 networks have no coordinates and use a hop-count delay model; only 11-60-node networks were run; the power model is a simple device-count + hop model.
- Baselines are ours and may be weaker or stronger than the originals (e.g. our GA fails to find a feasible placement on 3 networks).

## Extending it
Add a baseline: implement `my_method(problem, k, ...) -> set` in `greenplace/baselines.py`, register it in `METHODS`, and add a branch in
`greenplace/benchmark.py::build_set`. Add networks: drop any `.gml` into `data/real_topologies/` (or run `fetch_real_topologies.py --all`).
