import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
# ---- Fig 2: protocol
fig, ax = plt.subplots(figsize=(11, 3.6)); ax.set_xlim(0,100); ax.set_ylim(0,32); ax.axis("off")
def b(x,w,t,ec,y=8,h=16):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.1,rounding_size=0.8",fc="white",ec=ec,lw=1.5))
    ax.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=8.5,linespacing=1.3)
steps=[("46 Topology Zoo\nnetworks\n(11–60 nodes)","#34495e"),("Fix settings a priori:\nD=0.35×diam,\nCap=⌈n/6⌉, K=⌈n/Cap⌉","#34495e"),
("Each method returns\na controller pool\n(10 seeds, eval seeds 0–9)","#2e7d4f"),("Same runtime manager\noperates every pool\n(8 traffic scenarios)","#c77a12"),
("Per-topology means →\npaired Wilcoxon + Holm,\nbootstrap CIs, Pareto","#7a4a99")]
x=1
for i,(t,c) in enumerate(steps):
    b(x,17,t,c); 
    if i<4: ax.add_patch(FancyArrowPatch((x+17,16),(x+19.6,16),arrowstyle="-|>",mutation_scale=12,color="#444",lw=1.3))
    x+=19.8
b(20,60,"SIL training seeds 100–101 are disjoint from evaluation seeds 0–9 (asserted in code)","#d9541e",y=0.5,h=5)
plt.savefig("fig/fig2_protocol.png",dpi=170,bbox_inches="tight",facecolor="white")
