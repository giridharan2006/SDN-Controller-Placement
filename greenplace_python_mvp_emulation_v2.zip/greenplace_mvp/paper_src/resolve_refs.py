import json, urllib.parse, urllib.request, difflib, re, time, ssl
Q = {
 "heller": "The controller placement problem Heller Sherwood McKeown",
 "greco": "GreCo: An energy aware controller association algorithm for software defined networks",
 "hu": "The energy-aware controller placement problem in software defined networks",
 "kondo23": "An energy efficient SDN controller placement with delay constraints",
 "kondo26": "Energy-aware controller placement with delay guarantees for in-band SDN",
 "enplace": "EnPlace: Energy-aware network partitioning for controller placement in SDN",
 "mohanty": "Energy-efficient controller placement in SDN: A heuristic approach",
 "oliveira": "Improving energy efficiency on SDN control-plane using multi-core controllers",
 "killi": "Capacitated next controller placement in software defined networks",
 "kaz": "Enhanced load balancing technique for SDN controllers: A multi-threshold approach with migration of switches",
 "jalili": "Optimal controller placement in large scale software defined networks based on modified NSGA-II",
 "jalili24": "Enhancing quality of service in SDNs through Pareto-optimized controller placement using NS-MF algorithm",
 "naked": "Multi-controller placement optimization using naked mole-rat algorithm over SDN",
 "sapkota": "Controller placement problem during SDN deployment in the ISP/Telco networks: A survey",
 "dhar": "A comprehensive study of different objectives and solutions of controller placement problem in software-defined networks",
 "sallahi": "Optimal model for the controller placement problem in software defined networks",
 "huque": "Large-scale dynamic controller placement",
 "zhu": "Dynamic switch migration with Q-learning towards scalable SDN control plane",
 "setiawan": "Energy-efficient softwarized networks: A survey",
 "sleep": "Sleeping mode of multi-controller in green software-defined networking",
 "deb": "A fast and elitist multiobjective genetic algorithm: NSGA-II",
 "nsga3": "An Evolutionary Many-Objective Optimization Algorithm Using Reference-Point-Based Nondominated Sorting Approach, Part I: Solving Problems With Box Constraints",
 "mopso": "Handling multiple objectives with particle swarm optimization",
 "hv": "Multiobjective evolutionary algorithms: a comparative case study and the strength Pareto approach",
 "zoo": "The Internet Topology Zoo",
 "geant": "Providing public intradomain traffic matrices to the research community",
 "sndlib": "SNDlib 1.0 - Survivable Network Design Library",
 "cliff": "Dominance statistics: Ordinal analyses to answer ordinal questions",
 "wilcoxon": "Individual comparisons by ranking methods",
 "holm": "A simple sequentially rejective multiple test procedure",
 "tabu": "Efficient dynamic controller placement SDN energy-aware migration survey",
}
ctx = ssl.create_default_context(cafile="/root/.ccr/ca-bundle.crt")
out = {}
for k, q in Q.items():
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode({"query.bibliographic": q, "rows": 3,
          "select": "DOI,title,author,container-title,volume,issue,page,issued,type,publisher,article-number"})
    try:
        d = json.load(urllib.request.urlopen(url, timeout=30, context=ctx))["message"]["items"]
    except Exception as e:
        out[k] = {"status": "error", "err": str(e)}; continue
    best, bs = None, 0
    for it in d:
        t = (it.get("title") or [""])[0]
        s = difflib.SequenceMatcher(None, re.sub(r"\W+", " ", t.lower()), re.sub(r"\W+", " ", q.lower())).ratio()
        if s > bs: best, bs = it, s
    if best is None:
        out[k] = {"status": "none"}; continue
    out[k] = {"status": "ok" if bs >= 0.85 else "weak", "score": round(bs, 2), "doi": best.get("DOI"),
              "title": (best.get("title") or [""])[0], "venue": (best.get("container-title") or [""])[0],
              "volume": best.get("volume"), "issue": best.get("issue"), "page": best.get("page") or best.get("article-number"),
              "year": (best.get("issued", {}).get("date-parts") or [[None]])[0][0], "type": best.get("type"),
              "authors": [f"{a.get('given','')} {a.get('family','')}".strip() for a in best.get("author", [])]}
    time.sleep(0.3)
json.dump(out, open("refs_resolved.json", "w"), indent=1)
for k, v in out.items():
    print(k, v.get("status"), v.get("score"), (v.get("title") or "")[:60], "|", v.get("year"), "|", len(v.get("authors", [])), "authors")
