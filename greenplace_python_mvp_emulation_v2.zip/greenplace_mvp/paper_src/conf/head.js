const fs = require("fs");
const D = require("docx");
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, AlignmentType, WidthType,
        BorderStyle, ShadingType, Footer, PageNumber } = D;
const FONT = "Times New Roman";
const R = JSON.parse(fs.readFileSync(process.argv[2]));           // results.json  (single source of truth)
const SC = JSON.parse(fs.readFileSync(process.argv[3]));          // scaling summary.json
const REFS = JSON.parse(fs.readFileSync("refs3.json", "utf8"));
const dims = JSON.parse(fs.readFileSync("dims.json"));
const order = [];
function cite(txt) {
  return txt.replace(/\{([a-z0-9]+)\}/g, (_, k) => {
    if (!REFS[k]) throw new Error("unknown ref " + k);
    if (!order.includes(k)) order.push(k);
    return "[" + String(order.indexOf(k) + 1) + "]";
  });
}
// ---- number formatting
const f0 = x => Math.round(x).toString(), f1 = x => x.toFixed(1), f2 = x => x.toFixed(2), f3 = x => x.toFixed(3);
const sg = (x, d = 1) => (x > 0 ? "+" : x < 0 ? "−" : "") + Math.abs(x).toFixed(d);          // signed, true minus
const pc = (x, d = 1) => sg(x, d) + "%";
const ci = (c, d = 1) => `[${sg(c[0], d)}, ${sg(c[1], d)}]`;
const pv = p => p < 0.001 ? "<0.001" : p < 0.01 ? p.toFixed(3) : p.toFixed(2);
const L = m => R.lifecycle_diurnal.find(r => r.method === m);
const ST = m => R.static.find(r => r.method === m);
const TM = b => R.tests_gp_vs_baselines_migrations.find(t => t.b === b);
const TE = b => R.tests_gp_vs_baselines_energy.find(t => t.b === b);
const nm = { greenplace: "GreenPlace", greenplace_sil: "GreenPlace-SIL", nsga2_2obj: "NSGA-II (2-obj)", exact_mip: "Exact MIP set", nsga3: "NSGA-III", mopso: "MOPSO",
  enplace: "EnPlace-style", greedy_cover: "Greedy cover", greco: "GreCo-style", ga_energy: "GA (energy)", k_median: "k-median", k_center: "k-center",
  betweenness: "Betweenness", random: "Random", nsga2_2obj_migsel: "NSGA-II + migration pick", greenplace_energypick: "3-obj search, energy pick",
  nsga3_migsel: "NSGA-III + migration pick", simnsga: "Sim-in-loop NSGA-II (min-sim-migration pick)", simnsga_sil: "Sim-in-loop NSGA-II + SIL pick" };
