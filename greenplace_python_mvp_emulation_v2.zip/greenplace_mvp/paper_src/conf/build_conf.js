const fs = require("fs");
const D = require("docx");
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, AlignmentType, WidthType,
        BorderStyle, ShadingType, Footer, PageNumber } = D;
const FONT = "Times New Roman";
const R = JSON.parse(fs.readFileSync(process.argv[2]));           // results.json  (single source of truth)
const SC = JSON.parse(fs.readFileSync(process.argv[3]));          // scaling summary.json
const REFS = JSON.parse(fs.readFileSync("refs3.json", "utf8"));
const dims = JSON.parse(fs.readFileSync("dims.json"));
const order = [];
function cite(txt) {
  return txt.replace(/\{([a-z0-9]+)\}/g, (_, k) => {
    if (!REFS[k]) throw new Error("unknown ref " + k);
    if (!order.includes(k)) order.push(k);
    return "[" + String(order.indexOf(k) + 1) + "]";
  });
}
// ---- number formatting
const f0 = x => Math.round(x).toString(), f1 = x => x.toFixed(1), f2 = x => x.toFixed(2), f3 = x => x.toFixed(3);
const sg = (x, d = 1) => (x > 0 ? "+" : x < 0 ? "−" : "") + Math.abs(x).toFixed(d);          // signed, true minus
const pc = (x, d = 1) => sg(x, d) + "%";
const ci = (c, d = 1) => `[${sg(c[0], d)}, ${sg(c[1], d)}]`;
const pv = p => p < 0.001 ? "<0.001" : p < 0.01 ? p.toFixed(3) : p.toFixed(2);
const L = m => R.lifecycle_diurnal.find(r => r.method === m);
const ST = m => R.static.find(r => r.method === m);
const TM = b => R.tests_gp_vs_baselines_migrations.find(t => t.b === b);
const TE = b => R.tests_gp_vs_baselines_energy.find(t => t.b === b);
const nm = { greenplace: "GreenPlace", greenplace_sil: "GreenPlace-SIL", nsga2_2obj: "NSGA-II (2-obj)", exact_mip: "Exact MIP set", nsga3: "NSGA-III", mopso: "MOPSO",
  enplace: "EnPlace-style", greedy_cover: "Greedy cover", greco: "GreCo-style", ga_energy: "GA (energy)", k_median: "k-median", k_center: "k-center",
  betweenness: "Betweenness", random: "Random", nsga2_2obj_migsel: "NSGA-II + migration pick", greenplace_energypick: "3-obj search, energy pick",
  nsga3_migsel: "NSGA-III + migration pick", simnsga: "Sim-in-loop NSGA-II (min-sim-migration pick)", simnsga_sil: "Sim-in-loop NSGA-II + SIL pick" };
const SZ = 20; // 10 pt body
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: o.size || SZ, ...o });
function runs(t, base = {}) {
  const out = [];
  t.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/).forEach(s => { if (!s) return;
    if (s.startsWith("**")) out.push(run(s.slice(2, -2), { ...base, bold: true }));
    else if (s.startsWith("*")) out.push(run(s.slice(1, -1), { ...base, italics: true }));
    else out.push(run(s, base)); });
  return out;
}
const body = [];
const P = (t, o = {}) => body.push(new Paragraph({ children: runs(cite(t), o.run || {}), alignment: o.align || AlignmentType.JUSTIFIED, spacing: { after: 70, line: 228 } }));
const H1 = t => body.push(new Paragraph({ children: [run(t.toUpperCase(), { bold: true, size: 17 })], alignment: AlignmentType.CENTER, spacing: { before: 130, after: 60 }, keepNext: true }));
const H2 = t => body.push(new Paragraph({ children: [run(t, { italics: true, size: SZ })], spacing: { before: 80, after: 40 }, keepNext: true }));
const EQ = (t, n) => body.push(new Paragraph({ children: [run(t, { italics: true }), run("\t(" + n + ")")], tabStops: [{ type: "right", position: 4860 }], spacing: { before: 40, after: 60 } }));
const BUL = t => body.push(new Paragraph({ children: runs(cite(t)), spacing: { after: 30, line: 228 }, indent: { left: 220, hanging: 180 }, alignment: AlignmentType.JUSTIFIED }));
let CW = 4860;
const bd = { style: BorderStyle.SINGLE, size: 4, color: "999999" }, borders = { top: bd, bottom: bd, left: bd, right: bd };
function TBL(rows, widths, { hl = null, fs = 14 } = {}) {
  const tot = widths.reduce((a, b) => a + b, 0), w = widths.map(x => Math.round(x / tot * CW)); w[w.length - 1] += CW - w.reduce((a, b) => a + b, 0);
  const trs = rows.map((r, ri) => new TableRow({ tableHeader: ri === 0, cantSplit: true, children: r.map((c, ci) => new TableCell({
    borders, width: { size: w[ci], type: WidthType.DXA }, margins: { top: 20, bottom: 20, left: 45, right: 45 },
    shading: ri === 0 ? { type: ShadingType.CLEAR, fill: "E3E8EE" } : (hl && hl(r) ? { type: ShadingType.CLEAR, fill: "E6F2EA" } : undefined),
    children: [new Paragraph({ alignment: ci === 0 ? AlignmentType.LEFT : AlignmentType.CENTER, children: runs(cite(c), { size: fs, bold: ri === 0 || (hl && hl(r)) || undefined }) })] })) }));
  body.push(new Table({ width: { size: CW, type: WidthType.DXA }, columnWidths: w, rows: trs }));
  body.push(new Paragraph({ spacing: { after: 60 }, children: [] }));
}
const CAP = t => body.push(new Paragraph({ children: runs(cite(t), { size: 15 }), spacing: { before: 60, after: 40 }, keepNext: true, alignment: AlignmentType.JUSTIFIED }));
function FIG(key, widthIn, caption) {
  const [w, h] = dims[key]; const pw = Math.round(widthIn * 96), ph = Math.round(pw * h / w);
  body.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 60, after: 30 }, children: [new ImageRun({ type: "png", data: fs.readFileSync(`fig/${key}.png`), transformation: { width: pw, height: ph }, altText: { title: key, description: caption, name: key } })] }));
  body.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 90 }, children: runs(cite(caption), { size: 15 }) }));
}
const pick = (rows, idx) => rows.map(r => idx.map(i => r[i]));
const isGP = r => /^GreenPlace/.test(r[0]);
const N = R.n_topologies, S = R.n_seeds;
const gp = L("greenplace"), n2 = L("nsga2_2obj"), mip = L("exact_mip");
const tmN2 = TM("nsga2_2obj"), tmMip = TM("exact_mip"), tmN3 = TM("nsga3"), teN2 = TE("nsga2_2obj"), teMip = TE("exact_mip");
const sim = R.simnsga_subset, simSil = sim.tests_migrations.filter(t => t.a === "simnsga_sil"), simSilE = sim.tests_energy.filter(t => t.a === "simnsga_sil");
const sh = R.shift, shD = sh[0], shAb = sh.find(s => s.scenario === "abilene"), shGe = sh.find(s => s.scenario === "geant"), shBu = sh.find(s => s.scenario === "bursty");
const sel = R.selector, rl = sel.rules;
const hyst = R.ablation_migrations.find(t => t.b === "greenplace_no_hysteresis");
const ab = (a, b) => R.ablation_migrations.find(t => t.a === a && t.b === b), abE = (a, b) => R.ablation_energy.find(t => t.a === a && t.b === b);
const qa = (m, a) => R.quality.find(q => q.mode === m && q.algo === a);
const qt = (m, col, b) => R.quality_tests.find(t => t.mode === m && t.col === col && t.b === b);
const tr = (b, mm) => R.transition_sweep.find(t => t.boot_s === b && t.mig_s === mm);
const psn = (l, i) => R.power_sensitivity.find(t => t.p_link_w === l && t.idle_frac === i);
const mb = R.mip_set_vs_best_heuristic;
const silT = R.tests_sil, silE = R.tests_sil_energy;
const spR = sel.proxy_rho;
const kdl = SC.rows.find(r => r.instance === "Kdl"), s400 = SC.rows.find(r => r.instance === "syn400"), cog = SC.rows.find(r => r.instance === "Cogentco");
const selT = (a, b, m) => sel.tests.find(t => t.a === a && t.b === b && t.metric === m);
const pcount = R.pareto_counts.nondominated;

// ===================== TITLE =====================
const T0 = (t, o) => body.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: o.after || 60 }, children: [run(t, o)] }));
T0("Migration-Aware Multi-Objective Controller Placement for Energy-Efficient SDN: Evidence from 46 Real Networks", { bold: true, size: 30, after: 80 });
T0("[Authors — to be added]", { size: 20, after: 20 });
T0("[Affiliations, e-mail — to be added]", { size: 17, italics: true, after: 100 });
body.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 228 }, indent: { left: 360, right: 360 }, children: [run("Abstract—", { bold: true, italics: true }), ...runs(cite(
`Energy-aware controller placement is usually solved as a one-shot problem, so a placement is never judged by what happens when controllers later sleep and wake with traffic. We present GreenPlace, which searches energy, delay and a migration-burden objective under a hard delay bound and operates the chosen pool with a hysteresis-based runtime manager. We benchmark it against 15 baselines and variants (our re-implementations of NSGA-II, NSGA-III, MOPSO, GreCo-, EnPlace- and k-center-style methods, a GA and an exact MIP) on ${N} Topology Zoo networks, ${S} seeds and 8 traffic scenarios including real GÉANT and Abilene traces, with every pool run through the same runtime manager. GreenPlace is **not** the best static placer (${f1(ST("greenplace").gap_mean_pct)}% above the MIP lower bound; NSGA-II ${f1(ST("nsga2_2obj").gap_mean_pct)}%) and is tied on lifecycle energy, but needs ${f0(Math.abs(tmN2.pct_mean))}% fewer switch migrations than NSGA-II (95% CI ${ci(tmN2.pct_ci, 0)}, Holm p ${pv(tmN2.p_holm)}). Against the exact-MIP set the mean advantage is uncertain (CI includes zero), and the advantage is small on the real Abilene trace. The exact MIP solves 400-node instances to optimality in under a minute. No emulation was run.`), { italics: true })] }));
body.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 80 }, indent: { left: 360, right: 360 }, children: [run("Index Terms—", { bold: true, italics: true }), run("software-defined networking, controller placement, energy efficiency, multi-objective optimisation, switch migration", { italics: true })] }));
FIG("fig1_architecture", 6.2, "Fig. 1. GreenPlace architecture. Phase 1 computes a Pareto front of delay-feasible placements and picks a pool by a proxy rule (or by simulation in the loop, dashed). Phase 2 runs the pool over a traffic trace. The harness runs every method's pool through the same Phase 2.");
const TOPN = body.length;

// ===================== BODY =====================
H1("I. Introduction");
P("An SDN control plane uses several controllers; each one powered on costs energy, and each switch reassigned when controllers sleep costs control-plane disruption. The controller placement problem (CPP) {heller} is mostly solved for latency, and its energy-aware variants {greco}, {hu}, {enplace}, {kondo26} are offline, so a placement is never judged by the runtime churn it induces; migration work {zhu}, {kaz} targets load balancing, not energy.");
P(`We ask one empirical question: *if the offline search is aware of the migration cost a runtime energy manager will incur, does the pool need fewer migrations over a day without costing energy or violating the delay bound?* Contributions: (i) GreenPlace, a three-objective formulation plus a runtime manager; (ii) a like-for-like protocol in which all methods' pools are operated by the same manager; (iii) an evaluation on ${N} real networks with ${S} seeds, paired tests, Holm correction and bootstrap intervals, reporting where the method does *not* win. We do not claim a new optimiser.`);
H1("II. Method");
P("A placement is a controller set C ⊆ V with nearest-controller assignment a(·). With p_c = 150 W per active controller and p_l = 5 W per hop of an active control path,");
EQ("P(C) = |C|·p_c + p_l · Σ_u h(u, a(u))", 1);
P("subject to a **hard delay bound** d(u, a(u)) ≤ D_max for every switch, capacity ⌈n/6⌉ switches per controller, and a pool of at least K = ⌈n/Cap⌉ controllers. Sleeping controllers draw no power by default (varied in a sensitivity analysis).");
P("**Phase 1.** An NSGA-II {deb} minimises power, worst-case delay and a *migration burden* (switches hosted by the controller the manager would sleep first); the bound is enforced by constrained domination. A *proxy pick* chooses, among members within 15% of the front's minimum energy, the smallest burden. A *simulation-in-the-loop (SIL) pick* simulates up to 10 candidates on held-out training traces and picks the fewest migrations within 2% extra energy.");
P("**Phase 2.** The manager smooths load with an EMA (α = 0.3), enforces a two-step dwell time between sleep events, reassigns switches with capacity-aware rules {killi} before sleeping a controller and wakes immediately whenever the delay bound would otherwise be at risk.");
H1("III. Experimental Protocol");
P(`**Data.** All ${N} Topology Zoo networks {zoo} with 11–60 nodes; D_max = 0.35 × delay-diameter; 96-step traces; ${S} seeds. Eight traffic scenarios: diurnal (the selection distribution), four synthetic shifts, and real GÉANT {geant} and Abilene {abilene} day traces from SNDlib {sndlib}. Settings were fixed before the full run.`);
P("**Baselines (all our re-implementations, not the authors' code):** random, k-center and k-median {heller}, greedy cover, betweenness, GreCo-style {greco}, EnPlace-style {enplace}, a single-objective GA, an exact MIP {kondo26}, two-objective NSGA-II {jalili}, NSGA-III {nsga3} and a binary MOPSO {mopso}; NSGA-II/III were also run with GreenPlace's pick rule and GreenPlace with a min-energy pick, to isolate components.");
P(`**Statistics.** Unit = network (seed means). Paired Wilcoxon {wilcoxon} with Holm correction {holm}, 10 000-resample bootstrap CIs and Cliff's delta {cliff}. Front quality uses exact 3-D hypervolume {hv} and IGD. **Reference.** The MIP picks switch assignments freely, but every method — including the MIP's own set — is scored by nearest assignment, so the MIP objective is only a *lower bound*: on ${mb.n_heuristic_beats_mip_set} of ${mb.n} networks a heuristic scores up to ${f1(mb.max_excess_pct)}% better than the MIP set.`);
H1("IV. Results");
CAP(`TABLE I. Static gap to the MIP lower bound, lifecycle (diurnal) energy and migrations, and Holm p of GreenPlace's migrations vs each method (${N} networks; sim-in-search variants omitted, run on a subset).`);
const tblM = ["greenplace", "greenplace_sil", "nsga2_2obj", "nsga3", "mopso", "enplace", "ga_energy", "exact_mip", "greco", "k_center", "greedy_cover"];
TBL([["Method", "Gap %", "Energy W", "Migr.", "p"]].concat(tblM.map(m => { const l = L(m), s = ST(m), t = m === "greenplace" ? null : (TM(m) || null);
  return [nm[m], s ? f1(s.gap_mean_pct) : "n/a", f0(l.avg_energy_w), f1(l.migrations), t ? pv(t.p_holm) : "—"]; })), [3, 1.1, 1.3, 1.1, 1], { hl: isGP });
P(`**Static energy.** GreenPlace is not best: ${f1(ST("greenplace").gap_mean_pct)}% above the bound vs ${f1(ST("nsga2_2obj").gap_mean_pct)}% (NSGA-II) and ${f1(ST("nsga3").gap_mean_pct)}% (NSGA-III). The gap comes from the pick rule's 15% energy slack: the same front with a min-energy pick is ${f1(ST("greenplace_energypick").gap_mean_pct)}%. **Lifecycle energy** is tied with NSGA-II (${pc(teN2.pct_mean)}, Holm p ${pv(teN2.p_holm)}) and the MIP set (${pc(teMip.pct_mean)}, p ${pv(teMip.p_holm)}); GreCo-style costs ${pc((L("greco").avg_energy_w / gp.avg_energy_w - 1) * 100, 0)} more. No method violates the delay bound.`);
P(`**Migrations.** GreenPlace needs ${f1(gp.migrations)} migrations/day vs ${f1(n2.migrations)} for NSGA-II (${pc(tmN2.pct_mean)}, CI ${ci(tmN2.pct_ci, 0)}; fewer on ${tmN2.wins}, more on ${tmN2.losses} of ${N} networks; Holm p ${pv(tmN2.p_holm)}, Cliff's δ ${sg(tmN2.cliffs_delta, 2)}, a small effect), ${pc(tmN3.pct_mean, 0)} vs NSGA-III and ${pc(TM("mopso").pct_mean, 0)} vs MOPSO (Fig. 3). Versus the exact-MIP set (${f1(mip.migrations)}) the mean is ${pc(tmMip.pct_mean, 0)} with a CI that includes zero (${ci(tmMip.pct_ci, 0)}), the median is ${pc(tmMip.pct_median, 0)} (Holm p ${pv(tmMip.p_holm)}). GreCo-style (${f1(L("greco").migrations)}) and k-center (${f1(L("k_center").migrations)}) are *not* significantly different; GreCo-style achieves this with higher energy.`);
FIG("fig_c1", 3.3, "Fig. 2. Lifecycle trade-off on the diurnal trace (mean over networks); bottom-left is better. GreenPlace variants in green.");
FIG("fig_c2", 3.3, "Fig. 3. GreenPlace migrations relative to each baseline with 95% bootstrap CIs; green = GreenPlace fewer, red = more.");
P(`**Which component matters.** Neither the third objective alone nor the migration-aware pick alone gave a significant gain over NSGA-II; their combination did (Holm p ${pv(ab("greenplace", "greenplace_energypick").p_holm)} for the pick on the 3-objective front). Removing runtime hysteresis raises migrations from ${f1(hyst.mean_b === undefined ? 0 : hyst.mean_a)} to ${f1(hyst.mean_b)} — the largest single effect, and independent of placement.`);
FIG("fig_c3", 3.3, "Fig. 4. Migration advantage across eight traffic scenarios, including the real GÉANT and Abilene traces.");
P(`**Robustness.** Against NSGA-II the advantage holds on the synthetic shifts (${pc(sh.find(s => s.scenario === "two_peak").gp_vs_nsga2_migs_pct, 0)} two-peak, ${pc(shBu.gp_vs_nsga2_migs_pct, 0)} bursty) and GÉANT (${pc(shGe.gp_vs_nsga2_migs_pct, 0)}) but is ${pc(shAb.gp_vs_nsga2_migs_pct, 0)} on Abilene (CI includes zero). Against the MIP set it is inconsistent across scenarios (Fig. 4).`);
P(`**Front quality.** Hypervolume and IGD favour GreenPlace's 3-objective search over NSGA-III and MOPSO (HV ${f2(qa("pool", "greenplace").hv)} vs ${f2(qa("pool", "nsga3").hv)} and ${f2(qa("pool", "mopso").hv)}). The two-objective NSGA-II does not optimise the third axis, so this comparison favours GreenPlace by construction.`);
P(`**Selectors and scale.** SIL lowers energy (${f0(rl.sil.energy_diurnal)} vs ${f0(rl.proxy.energy_diurnal)} W) but not migrations (${f1(rl.sil.migs_diurnal)} vs ${f1(rl.proxy.migs_diurnal)}); a learned surrogate (${f1(rl.surrogate.migs_diurnal)}) did not beat the proxy. The exact MIP solved ${s400.n}-node synthetic instances to optimality in ${f0(s400.mip_secs)} s while fixed-budget NSGA-II was ${f0(s400.nsga2_2obj_gap)}% above the bound, so the heuristic is *not* needed for scalability up to this size; its value is migration stability.`);
H1("V. Limitations");
P("(1) Baselines are our re-implementations of published ideas, not the authors' code. (2) The power model is a stylised proxy, not calibrated on hardware; sensitivity to link power, idle draw and transition cost is analysed in the journal version. (3) Load is total network traffic, not measured controller load. (4) No Mininet/Ryu or hardware experiment was run; a harness is provided but untested. (5) Effects are small in Cliff's-delta terms and vary by network. (6) Simulation-in-search variants reduce migrations further on small networks at higher energy, so \"fewest migrations\" is not the only sensible criterion.");
H1("VI. Conclusion");
P(`Making the offline search aware of runtime migration cost gives ${f0(Math.abs(tmN2.pct_mean))}% fewer migrations than energy-and-delay NSGA-II at statistically tied lifecycle energy, at the price of ${f1(ST("greenplace").gap_mean_pct - ST("nsga2_2obj").gap_mean_pct)} points more static energy; against the exact-MIP controller set the benefit is smaller and uncertain. Code, data and every result row are released; all numbers here are generated from them.`);
P("**Availability:** Python package, topologies, traffic series, raw results, Dockerfile and CI in the accompanying archive. **Funding/COI:** [to be added].");
H1("References");
const top = body.slice(0, TOPN), main = body.slice(TOPN);
const refs = order.map((k, i) => new Paragraph({ spacing: { after: 20 }, indent: { left: 260, hanging: 260 }, alignment: AlignmentType.JUSTIFIED, children: [run(`[${i + 1}] `, { size: 14 }), run(REFS[k], { size: 14 })] }));
const pg = { size: { width: 12240, height: 15840 }, margin: { top: 1000, bottom: 1000, left: 1080, right: 1080 } };
const doc = new Document({ styles: { default: { document: { run: { font: FONT, size: SZ } } } }, sections: [
  { properties: { page: pg }, children: top },
  { properties: { type: D.SectionType.CONTINUOUS, page: pg, column: { count: 2, space: 360, equalWidth: true } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 15, color: "777777" })] })] }) },
    children: [...main, ...refs] }] });
Packer.toBuffer(doc).then(b => { fs.writeFileSync("GreenPlace_Conference_Paper.docx", b); console.log("written", order.length, "refs"); });
