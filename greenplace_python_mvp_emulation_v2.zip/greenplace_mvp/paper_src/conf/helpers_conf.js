const SZ = 20; // 10 pt body
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: o.size || SZ, ...o });
function runs(t, base = {}) {
  const out = [];
  t.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/).forEach(s => { if (!s) return;
    if (s.startsWith("**")) out.push(run(s.slice(2, -2), { ...base, bold: true }));
    else if (s.startsWith("*")) out.push(run(s.slice(1, -1), { ...base, italics: true }));
    else out.push(run(s, base)); });
  return out;
}
const body = [];
const P = (t, o = {}) => body.push(new Paragraph({ children: runs(cite(t), o.run || {}), alignment: o.align || AlignmentType.JUSTIFIED, spacing: { after: 70, line: 228 } }));
const H1 = t => body.push(new Paragraph({ children: [run(t.toUpperCase(), { bold: true, size: 17 })], alignment: AlignmentType.CENTER, spacing: { before: 130, after: 60 }, keepNext: true }));
const H2 = t => body.push(new Paragraph({ children: [run(t, { italics: true, size: SZ })], spacing: { before: 80, after: 40 }, keepNext: true }));
const EQ = (t, n) => body.push(new Paragraph({ children: [run(t, { italics: true }), run("\t(" + n + ")")], tabStops: [{ type: "right", position: 4860 }], spacing: { before: 40, after: 60 } }));
const BUL = t => body.push(new Paragraph({ children: runs(cite(t)), spacing: { after: 30, line: 228 }, indent: { left: 220, hanging: 180 }, alignment: AlignmentType.JUSTIFIED }));
let CW = 4860;
const bd = { style: BorderStyle.SINGLE, size: 4, color: "999999" }, borders = { top: bd, bottom: bd, left: bd, right: bd };
function TBL(rows, widths, { hl = null, fs = 14 } = {}) {
  const tot = widths.reduce((a, b) => a + b, 0), w = widths.map(x => Math.round(x / tot * CW)); w[w.length - 1] += CW - w.reduce((a, b) => a + b, 0);
  const trs = rows.map((r, ri) => new TableRow({ tableHeader: ri === 0, cantSplit: true, children: r.map((c, ci) => new TableCell({
    borders, width: { size: w[ci], type: WidthType.DXA }, margins: { top: 20, bottom: 20, left: 45, right: 45 },
    shading: ri === 0 ? { type: ShadingType.CLEAR, fill: "E3E8EE" } : (hl && hl(r) ? { type: ShadingType.CLEAR, fill: "E6F2EA" } : undefined),
    children: [new Paragraph({ alignment: ci === 0 ? AlignmentType.LEFT : AlignmentType.CENTER, children: runs(cite(c), { size: fs, bold: ri === 0 || (hl && hl(r)) || undefined }) })] })) }));
  body.push(new Table({ width: { size: CW, type: WidthType.DXA }, columnWidths: w, rows: trs }));
  body.push(new Paragraph({ spacing: { after: 60 }, children: [] }));
}
const CAP = t => body.push(new Paragraph({ children: runs(cite(t), { size: 15 }), spacing: { before: 60, after: 40 }, keepNext: true, alignment: AlignmentType.JUSTIFIED }));
function FIG(key, widthIn, caption) {
  const [w, h] = dims[key]; const pw = Math.round(widthIn * 96), ph = Math.round(pw * h / w);
  body.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 60, after: 30 }, children: [new ImageRun({ type: "png", data: fs.readFileSync(`fig/${key}.png`), transformation: { width: pw, height: ph }, altText: { title: key, description: caption, name: key } })] }));
  body.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 90 }, children: runs(cite(caption), { size: 15 }) }));
}
