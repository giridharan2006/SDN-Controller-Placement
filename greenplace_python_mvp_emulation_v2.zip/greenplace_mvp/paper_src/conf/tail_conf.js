const top = body.slice(0, TOPN), main = body.slice(TOPN);
const refs = order.map((k, i) => new Paragraph({ spacing: { after: 20 }, indent: { left: 260, hanging: 260 }, alignment: AlignmentType.JUSTIFIED, children: [run(`[${i + 1}] `, { size: 14 }), run(REFS[k], { size: 14 })] }));
const pg = { size: { width: 12240, height: 15840 }, margin: { top: 1000, bottom: 1000, left: 1080, right: 1080 } };
const doc = new Document({ styles: { default: { document: { run: { font: FONT, size: SZ } } } }, sections: [
  { properties: { page: pg }, children: top },
  { properties: { type: D.SectionType.CONTINUOUS, page: pg, column: { count: 2, space: 360, equalWidth: true } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 15, color: "777777" })] })] }) },
    children: [...main, ...refs] }] });
Packer.toBuffer(doc).then(b => { fs.writeFileSync("GreenPlace_Conference_Paper.docx", b); console.log("written", order.length, "refs"); });
