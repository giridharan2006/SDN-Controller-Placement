import json, sys, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from PIL import Image
R = json.load(open(sys.argv[1])); OUT = "fig/"
G, B, RED = "#1b6e5a", "#8d99ae", "#c1121f"
plt.rcParams.update({"font.size": 7, "font.family": "serif", "axes.spines.top": False, "axes.spines.right": False})
nm = {"greenplace": "GreenPlace", "greenplace_sil": "GreenPlace-SIL", "greenplace_energypick": "3-obj, energy pick", "nsga2_2obj": "NSGA-II", "nsga2_2obj_migsel": "NSGA-II+pick", "nsga3": "NSGA-III", "nsga3_migsel": "NSGA-III+pick",
      "mopso": "MOPSO", "ga_energy": "GA", "exact_mip": "MIP set", "enplace": "EnPlace-style", "greco": "GreCo-style", "k_center": "k-center", "k_median": "k-median", "greedy_cover": "Greedy cover", "random": "Random"}
ours = {"greenplace", "greenplace_sil", "greenplace_energypick"}
L = {r["method"]: r for r in R["lifecycle_diurnal"] if r["method"] in nm}
fig, ax = plt.subplots(figsize=(3.4, 2.6)); ax.grid(color="#e3e6ea", lw=.5); ax.set_axisbelow(True)
lab = {"greenplace", "greenplace_sil", "nsga2_2obj", "exact_mip", "greco", "mopso", "enplace", "k_center", "ga_energy", "nsga3", "greedy_cover"}
off = {"nsga2_2obj": (4, 4), "nsga3": (4, -8), "ga_energy": (4, 3), "exact_mip": (-34, 5), "k_center": (-8, -9), "greco": (4, 4), "enplace": (4, -3), "mopso": (4, 3), "greedy_cover": (-40, 3), "greenplace": (-14, -11), "greenplace_sil": (5, 4)}
for k, r in L.items():
    ax.scatter(r["migrations"], r["avg_energy_w"], s=34 if k in ours else 20, color=G if k in ours else B, edgecolor="white", lw=.8, zorder=3)
    if k in lab: ax.annotate(nm[k], (r["migrations"], r["avg_energy_w"]), xytext=off.get(k, (4, 3)), textcoords="offset points", fontsize=6)
ax.set_xlabel("migrations per day (lower is better)"); ax.set_ylabel("mean lifecycle power (W)"); fig.tight_layout(); fig.savefig(OUT + "fig_c1.png", dpi=300); plt.close(fig)

T = [t for t in R["tests_gp_vs_baselines_migrations"] if t["b"] in nm]
T.sort(key=lambda t: t["pct_mean"])
fig, ax = plt.subplots(figsize=(3.4, 2.6)); ax.grid(axis="x", color="#e3e6ea", lw=.5); ax.set_axisbelow(True)
for i, t in enumerate(T):
    c = G if t["pct_mean"] < 0 else RED
    ax.errorbar(t["pct_mean"], i, xerr=[[t["pct_mean"] - t["pct_ci"][0]], [t["pct_ci"][1] - t["pct_mean"]]], fmt="o", color=c, ms=3, capsize=1.5, lw=.9)
ax.axvline(0, color="k", lw=.6); ax.set_yticks(range(len(T)), ["vs " + nm[t["b"]] for t in T]); ax.invert_yaxis()
ax.set_xlabel("GreenPlace migrations vs baseline, % (95% CI)"); fig.tight_layout(); fig.savefig(OUT + "fig_c2.png", dpi=300); plt.close(fig)

S = R["shift"]; x = np.arange(len(S)); w = .38
fig, ax = plt.subplots(figsize=(3.4, 2.1)); ax.grid(axis="y", color="#e3e6ea", lw=.5); ax.set_axisbelow(True)
ax.bar(x - w / 2, [s["gp_vs_nsga2_migs_pct"] for s in S], w, color=G, label="vs NSGA-II"); ax.bar(x + w / 2, [s["gp_vs_mip_migs_pct"] for s in S], w, color=B, label="vs MIP set")
ax.axhline(0, color="k", lw=.6); ax.set_xticks(x, [s["scenario"].replace("_", "\n") for s in S], fontsize=5.5); ax.set_ylabel("migrations vs baseline, %"); ax.legend(frameon=False, fontsize=6)
fig.tight_layout(); fig.savefig(OUT + "fig_c3.png", dpi=300); plt.close(fig)
d = {k: Image.open(f"fig/{k}.png").size for k in ["fig_c1", "fig_c2", "fig_c3", "fig1_architecture"]}
json.dump(d, open("dims.json", "w")); print(d)
