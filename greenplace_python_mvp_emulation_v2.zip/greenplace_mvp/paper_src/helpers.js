// ---------- paragraph helpers ----------
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: o.size || 22, ...o });
// inline *italic* and **bold** support
function runs(t, base = {}) {
  const out = [];
  t.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/).forEach(s => {
    if (!s) return;
    if (s.startsWith("**")) out.push(run(s.slice(2, -2), { ...base, bold: true }));
    else if (s.startsWith("*")) out.push(run(s.slice(1, -1), { ...base, italics: true }));
    else out.push(run(s, base));
  });
  return out;
}
const body = [];
const P = (t, o = {}) => body.push(new Paragraph({ children: runs(cite(t), o.run || {}),
  alignment: o.align || AlignmentType.JUSTIFIED, spacing: { after: 120, line: 276 }, indent: o.indent }));
const H1 = t => body.push(new Paragraph({ children: [run(t, { bold: true, size: 26 })], spacing: { before: 280, after: 120 }, keepNext: true }));
const H2 = t => body.push(new Paragraph({ children: [run(t, { bold: true, italics: true, size: 23 })], spacing: { before: 180, after: 80 }, keepNext: true }));
const EQ = (t, n) => body.push(new Paragraph({ children: [run(t, { italics: true }), run("\t(" + n + ")")],
  tabStops: [{ type: "right", position: 9026 }], spacing: { before: 80, after: 120 }, alignment: AlignmentType.CENTER }));
const BUL = t => body.push(new Paragraph({ children: runs(cite(t)), spacing: { after: 60, line: 264 },
  indent: { left: 360, hanging: 240 }, alignment: AlignmentType.JUSTIFIED }));

const CW = 9026; // A4 with 1" margins
const bd = { style: BorderStyle.SINGLE, size: 4, color: "999999" };
const borders = { top: bd, bottom: bd, left: bd, right: bd };
function TBL(rows, widths, { hl = null } = {}) {
  const tot = widths.reduce((a, b) => a + b, 0);
  const w = widths.map(x => Math.round(x / tot * CW));
  w[w.length - 1] += CW - w.reduce((a, b) => a + b, 0);
  const trs = rows.map((r, ri) => new TableRow({ tableHeader: ri === 0, cantSplit: true,
    children: r.map((c, ci) => new TableCell({
      borders, width: { size: w[ci], type: WidthType.DXA },
      margins: { top: 40, bottom: 40, left: 70, right: 70 },
      shading: ri === 0 ? { type: ShadingType.CLEAR, fill: "E3E8EE" } :
               (hl && hl(r) ? { type: ShadingType.CLEAR, fill: "E6F2EA" } : undefined),
      children: [new Paragraph({ alignment: ci === 0 ? AlignmentType.LEFT : AlignmentType.CENTER,
        children: runs(cite(c), { size: 16, bold: ri === 0 || (hl && hl(r)) || undefined }) })] })) }));
  body.push(new Table({ width: { size: CW, type: WidthType.DXA }, columnWidths: w, rows: trs }));
  body.push(new Paragraph({ spacing: { after: 100 }, children: [] }));
}
const CAP = t => body.push(new Paragraph({ children: runs(cite(t), { size: 19 }), spacing: { before: 120, after: 60 }, keepNext: true }));
const NOTE = t => body.push(new Paragraph({ children: runs(cite(t), { size: 18, italics: true }), spacing: { after: 140 } }));
function FIG(key, widthIn, caption) {
  const [w, h] = dims[key]; const pw = Math.round(widthIn * 96), ph = Math.round(pw * h / w);
  body.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 60 },
    children: [new ImageRun({ type: "png", data: fs.readFileSync(`fig/${key}.png`), transformation: { width: pw, height: ph },
      altText: { title: key, description: caption, name: key } })] }));
  body.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 160 }, children: runs(cite(caption), { size: 19 }) }));
}

