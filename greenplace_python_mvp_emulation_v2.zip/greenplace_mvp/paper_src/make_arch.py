import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(15, 8.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 58); ax.axis("off")
C = dict(inp="#e8eef7", p1="#e6f2ea", p2="#fdf0dc", out="#efe6f4", ev="#f1f1f1",
         eb="#34495e", e1="#2e7d4f", e2="#c77a12", e3="#7a4a99", sil="#d9541e")

def panel(x, y, w, h, title, fc, ec):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=1.0", fc=fc, ec=ec, lw=1.6, alpha=.55))
    ax.text(x + w/2, y + h - 1.3, title, ha="center", va="center", fontsize=11, fontweight="bold", color=ec)

def box(x, y, w, h, text, ec, fc="white", fs=8.6, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.1,rounding_size=0.6", fc=fc, ec=ec, lw=1.3))
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal", linespacing=1.25)
    return (x, y, w, h)

def arrow(p, q, color="#444", style="-|>", ls="-", lw=1.4, rad=0.0):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle=style, mutation_scale=13, color=color, lw=lw, ls=ls,
                                 connectionstyle=f"arc3,rad={rad}", shrinkA=0, shrinkB=0))

# ---------------- panels ----------------
panel(0.5, 13, 16, 41, "INPUTS", C["inp"], C["eb"])
panel(19.5, 13, 31, 41, "PHASE 1 · OFFLINE PLACEMENT", C["p1"], C["e1"])
panel(53.5, 13, 25, 41, "PHASE 2 · RUNTIME MANAGER", C["p2"], C["e2"])
panel(81.5, 13, 18, 41, "OUTPUTS", C["out"], C["e3"])
panel(0.5, 0.8, 99, 9.6, "EVALUATION HARNESS", C["ev"], "#555")

# ---------------- inputs ----------------
ins = [("Topology\n(Topology Zoo GML,\n11–60 nodes)", 44), ("Hard delay bound\nD_max = 0.35 × diameter", 36.6),
       ("Controller capacity\nCap = ⌈n/6⌉,  K = ⌈n/Cap⌉", 29.2), ("Power model\np_c per controller,\np_l per hop-Watt", 21.2),
       ("Diurnal traffic trace\n(96 steps) → Phase 2, SIL", 15.2)]
for t, y in ins: box(2, y, 13, 6 if "\n" in t and t.count("\n") > 1 else 5.4, t, C["eb"], fs=8)

# ---------------- phase 1 ----------------
box(21, 44, 12.5, 6.5, "Delay engine\nall-pairs shortest\npaths + feasibility", C["e1"], fs=8)
box(36.5, 44, 12.5, 6.5, "Exact MIP\n(PuLP / CBC)\nground truth", C["e1"], fs=8)
box(21, 31.5, 28, 9.8, "3-objective NSGA-II  (self-written)\nmin  energy  P = |C|·p_c + p_l·Σ h(u,a(u))\nmin  worst-case delay\nmin  migration burden\nhard D_max via constrained domination", C["e1"], fs=8.2, bold=False)
box(21, 24, 28, 5.2, "Pareto front of feasible placements", C["e1"], fs=8.8, bold=True)
box(21, 14.2, 13, 7.5, "Proxy pick\nselect_migration_aware\nslack 1.15", C["e1"], fs=8)
box(36, 14.2, 13, 7.5, "SIL pick\nselect_by_simulation\ntrain seeds 100–101", C["sil"], fs=8)

# ---------------- phase 2 ----------------
box(55, 44, 22, 6.5, "Monitor: EMA-smoothed load (α = 0.3)", C["e2"], fs=8.4)
box(55, 36.4, 22, 5.8, "Hysteresis: dwell ≥ 2 steps\n(prevents controller flapping)", C["e2"], fs=8.4)
box(55, 28.4, 22, 6, "Capacity-aware switch reassignment\n(migrate before sleeping)", C["e2"], fs=8.4)
box(55, 20.8, 22, 5.6, "Delay guard: never sleep a controller\nif D_max would be violated", C["e2"], fs=8.4)
box(55, 14.2, 22, 4.6, "Sleep / wake controllers", C["e2"], fs=8.6, bold=True)

# ---------------- outputs ----------------
outs = [("Controller pool +\nswitch→controller map", 44), ("Lifecycle energy\n(Watts over 24 h)", 36.6),
        ("Switch migrations,\nstate changes", 29.2), ("Delay violations\n(must be 0)", 21.8), ("Pareto trade-off\n(energy vs migrations)", 15)]
for t, y in outs: box(83, y, 15, 5.8, t, C["e3"], fs=8.2)

# ---------------- evaluation ----------------
ev = [("46 real topologies\n10 seeds, 8 traffic\nscenarios (2 real traces)", 2), ("19 methods (our re-impl.): heuristics,\nGreCo/EnPlace-style, GA, MIP,\nNSGA-II/-III, MOPSO, ablations,\nSIL, sim-in-loop NSGA-II", 21),
      ("Shared runtime manager\nfor every method\n(like-for-like lifecycle)", 47), ("Paired Wilcoxon + Holm,\nbootstrap CIs,\nPareto dominance", 70)]
widths = [17, 24, 20, 28]
for (t, x), w in zip(ev, widths):
    box(x + (0.0), 1.6, w if x != 2 else 16, 6.3, t, "#555", fs=7.9)

# ---------------- arrows ----------------
arrow((15, 46.5), (21, 47.2), C["eb"])                      # topology -> delay engine
arrow((33.5, 47.2), (36.5, 47.2), C["e1"], "<|-|>")          # delay engine <-> MIP
arrow((27.2, 44), (27.2, 41.3), C["e1"])                     # delay engine -> NSGA
arrow((42.7, 44), (42.7, 41.3), C["e1"], ls="--")            # MIP -> NSGA (validation)
ax.text(43.3, 42.6, "validates", fontsize=7, color=C["e1"], style="italic")
arrow((35, 31.5), (35, 29.2), C["e1"])                       # NSGA -> front
arrow((27.5, 24), (27.5, 21.7), C["e1"])                     # front -> proxy
arrow((42.5, 24), (42.5, 21.7), C["e1"])                     # front -> SIL
# SIL <-> runtime manager (simulation in the loop)
arrow((49, 17.5), (55, 17.5), C["sil"], "<|-|>", ls="--", lw=1.8)
ax.text(52, 19.2, "simulate\ncandidates", fontsize=7, color=C["sil"], ha="center", style="italic", linespacing=1.1)
# selection bus -> runtime
ax.plot([27.5, 27.5], [14.2, 12.4], color=C["e1"], lw=1.4)
ax.plot([42.5, 42.5], [14.2, 12.4], color=C["e1"], lw=1.4)
ax.plot([27.5, 66], [12.4, 12.4], color=C["e1"], lw=1.4)
arrow((66, 12.4), (66, 14.2), C["e1"])
ax.text(47, 11.4, "chosen controller pool", fontsize=7.4, color=C["e1"], ha="center", style="italic")
# inputs to phase 2
ax.text(30.5, 12.9, "", fontsize=7)
# phase 2 internal flow
for y1, y2 in [(44, 42.2), (36.4, 34.4), (28.4, 26.4), (20.8, 18.8)]:
    arrow((66, y1), (66, y2), C["e2"])
# runtime -> outputs
arrow((77, 47.2), (83, 47.2), C["e3"]); arrow((77, 31.4), (83, 31.9), C["e3"])
arrow((77, 17), (83, 17.5), C["e3"])
# harness link
arrow((90.5, 15), (90.5, 10.4), "#555", ls="--")
arrow((9, 7.9), (9, 13), "#555", ls="--", style="<|-|>")

ax.text(50, 56.6, "GreenPlace: energy-efficient SDN controller placement under hard delay bounds",
        ha="center", fontsize=13, fontweight="bold")
plt.savefig("/home/claude/paper/fig/fig1_architecture.png", dpi=170, bbox_inches="tight", facecolor="white")
