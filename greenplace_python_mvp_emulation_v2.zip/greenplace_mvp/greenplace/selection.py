"""How a placement is chosen from an NSGA-II Pareto front.

Both rules are defined relative to the front's OWN minimum feasible energy, so
neither depends on running any other algorithm first (an earlier demo script
chose the 3-objective pick relative to the 2-objective run's energy, which
quietly lets the proposed method peek at its baseline).
"""
from __future__ import annotations


def select_min_energy(front):
    """Energy-aware but migration-oblivious pick: the cheapest feasible placement."""
    feasible = [p for p in front if p.feasible]
    if not feasible:
        return None
    return min(feasible, key=lambda p: (p.energy_w, p.worst_case_delay_ms))


def select_migration_aware(front, energy_slack: float = 1.15):
    """GreenPlace pick: among feasible placements within `energy_slack` x the
    front's own minimum energy, take the one with the lowest migration burden.

    slack=1.15 means "accept up to 15% more static energy to get a placement
    that is cheaper to consolidate at runtime" — an explicit, tunable trade-off.
    """
    feasible = [p for p in front if p.feasible]
    if not feasible:
        return None
    e_min = min(p.energy_w for p in feasible)
    comparable = [p for p in feasible if p.energy_w <= e_min * energy_slack]
    return min(comparable, key=lambda p: (p.migration_burden, p.energy_w))


def select_by_simulation(p, front, capacity, train_traces, energy_slack=0.02, window=1.25,
                         max_candidates=10, simulate_fn=None, slacks=None):
    """Simulation-in-the-loop pick: Phase 1 rehearses Phase 2 instead of guessing with a proxy.

    Each candidate pool (feasible Pareto member within `window` x the cheapest static energy, at most
    `max_candidates`) is run through the real runtime manager on `train_traces`; we keep those whose
    simulated lifecycle energy is within `energy_slack` of the best candidate and return the one with the
    fewest simulated migrations. Training traces must differ from the traces used to *evaluate* the result,
    otherwise the comparison is circular. Returns (placement or None, info); `info["by_slack"]` maps each
    extra slack in `slacks` to its pick (used only for exploratory sensitivity analysis).
    """
    from .lifecycle import simulate as _default_simulate
    simulate_fn = simulate_fn or _default_simulate
    feasible = [m for m in front if m.feasible]
    if not feasible:
        return None, {}
    e_min = min(m.energy_w for m in feasible)
    cands = sorted([m for m in feasible if m.energy_w <= window * e_min], key=lambda m: m.energy_w)[:max_candidates]
    scored = []
    for m in cands:
        sims = [simulate_fn(p, set(m.controllers), capacity, tr) for tr in train_traces]
        scored.append((m, sum(x["avg_energy_w"] for x in sims) / len(sims),
                       sum(x["migrations"] for x in sims) / len(sims)))

    def pick(slack):
        best_e = min(e for _, e, _ in scored)
        ok = [t for t in scored if t[1] <= best_e * (1 + slack)]
        return min(ok, key=lambda t: (t[2], t[1]))[0]

    info = {"n_candidates": len(cands),
            "by_slack": {sl: pick(sl) for sl in (slacks or ())}}
    return pick(energy_slack), info
