"""Extended study (paper v3): more baselines, 10 seeds, traffic distribution shift, real traces,
candidate-table dump for the learned-selector study, and quality indicators (hypervolume / IGD).

For every topology and seed we build ONE pool-mode front per search algorithm (k >= ceil(n/C)) and ONE
static-mode front (k >= 1). Every method's controller set is then evaluated:
  * static  : energy, feasibility, gap to the MIP optimum (analysis step)
  * lifecycle: the SAME runtime manager on 8 traffic scenarios (6 synthetic + 2 real-trace families);
               scenario 'diurnal' is the training/selection distribution, the other seven are unseen shifts.
Methods whose name ends in _sil / simnsga select or search using training seeds (100,101) only.
"""
from __future__ import annotations

import time
from pathlib import Path

from . import baselines as B
from . import moea
from .benchmark import BenchConfig, derive_settings
from .config import DelayConfig, PowerModel
from .lifecycle import simulate
from .metrics import front_indicators
from .selection import select_by_simulation, select_migration_aware, select_min_energy
from .simnsga import run_sim_nsga2
from .topology import load_zoo_topology
from .traffic import get_trace

SCENARIOS = ("diurnal", "two_peak", "flash_crowd", "bursty", "trend", "noisy", "geant", "abilene")
DETERMINISTIC = ("k_center", "k_median", "greedy_cover", "betweenness", "greco", "exact_mip", "enplace")
FRONT_METHODS = ("nsga2_2obj", "greenplace", "nsga3", "mopso")      # search algorithms producing fronts
ALL_METHODS = (
    "random", "k_center", "k_median", "greedy_cover", "betweenness", "greco", "enplace", "ga_energy", "exact_mip",
    "mopso", "nsga3", "nsga3_migsel", "nsga2_2obj", "nsga2_2obj_migsel",
    "greenplace_energypick",          # ablation: 3-obj search, migration-oblivious pick
    "greenplace",                     # 3-obj search + proxy-guided pick (the v2 method)
    "greenplace_sil",                 # 3-obj search + simulation-based pick (held-out training traces)
    "simnsga",                        # NSGA-II with simulated-migration objective (small networks only)
)


def _front(p, algo, k_min, k_max, seed, cfg):
    if algo == "nsga2_2obj":
        return B.nsga2_front(p, k_min, k_max, seed, False, cfg.nsga_pop, cfg.nsga_gens)
    if algo == "greenplace":
        return B.nsga2_front(p, k_min, k_max, seed, True, cfg.nsga_pop, cfg.nsga_gens)
    if algo == "nsga3":
        return moea.run_nsga3(p, k_min, k_max, seed, cfg.nsga_pop, cfg.nsga_gens)
    if algo == "mopso":
        return moea.run_mopso(p, k_min, k_max, seed, cfg.nsga_pop, cfg.nsga_gens)
    raise ValueError(algo)


def _det_set(p, method, k_min, k_max, cfg):
    info = {}
    if method in ("k_center", "k_median", "betweenness"):
        fn = {"k_center": B.k_center, "k_median": B.k_median, "betweenness": B.betweenness}[method]
        k = B.min_feasible_size(p, lambda k: fn(p, k), k_start=k_min)
        return fn(p, k), info
    if method == "greedy_cover":
        return B.greedy_cover(p, k_target=k_min), info
    if method == "greco":
        return B.greco_style(p, min_size=k_min), info
    if method == "exact_mip":
        return B.exact_mip(p, k_min, k_max, cfg.mip_time_limit_s)
    if method == "enplace":
        s = moea.enplace_style(p, k_min)
        while len(s) < k_min:                       # pool mode: pad with the cheapest-extra nodes
            extra = [v for v in p.nodes if v not in s]
            s = s | {min(extra, key=lambda v: p.evaluate(s | {v}).energy_w)}
        return s, info
    raise ValueError(method)


def _fallback(p, k_min):
    return B.greedy_cover(p, k_target=k_min)


def _cand_features(m, e_min, bd_min, K, n):
    return {"energy_w": m.energy_w, "delay_ms": m.worst_case_delay_ms, "burden": m.migration_burden,
            "k": len(m.controllers), "e_ratio": m.energy_w / e_min, "k_over_floor": len(m.controllers) / K}


def run_topology3(path, cfg: BenchConfig, seeds=None, with_sim=True, sim_max_n=40, sim_seeds=5):
    g, meta = load_zoo_topology(path)
    st = derive_settings(g, cfg)
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(st["bound_ms"]))
    K, C, n = st["k_floor"], st["capacity"], meta["n"]
    cover = len(B.greedy_cover(p, 1))
    base = {**meta, "bound_ms": round(st["bound_ms"], 3), "capacity": C, "k_floor": K, "cover_size": cover}
    k_max_pool = min(n, max(K, cover, K) + cfg.extra_pool)
    k_max_stat = min(n, max(1, cover, K) + cfg.extra_pool)
    seeds = list(range(cfg.seeds)) if seeds is None else seeds
    train = [get_trace("diurnal", sd, cfg.trace_len) for sd in cfg.sil_train_seeds]
    assert not set(cfg.sil_train_seeds) & set(range(max(cfg.seeds, 10)))

    rows, cand_rows, quality_rows = [], [], []
    det_cache = {}
    sim_cache = {}

    def life(pool, scen, seed):
        key = (frozenset(pool), scen, seed)
        if key not in sim_cache:
            sim_cache[key] = simulate(p, set(pool), C, get_trace(scen, seed, cfg.trace_len))
        return sim_cache[key]

    for seed in seeds:
        t0 = time.perf_counter()
        pool_sets, static_sets, extra_info = {}, {}, {}
        fronts_pool, fronts_stat = {}, {}
        times = {}
        for algo in FRONT_METHODS:
            t = time.perf_counter(); fronts_pool[algo] = _front(p, algo, K, k_max_pool, seed, cfg); times[algo + "_pool"] = time.perf_counter() - t
            t = time.perf_counter(); fronts_stat[algo] = _front(p, algo, 1, k_max_stat, seed, cfg); times[algo + "_static"] = time.perf_counter() - t

        def pick(front, rule, k_min):
            m = select_min_energy(front) if rule == "min" else select_migration_aware(front, cfg.energy_slack)
            return set(m.controllers) if m is not None else _fallback(p, k_min)

        for mode, fr, kmin in (("pool", fronts_pool, K), ("static", fronts_stat, 1)):
            out = pool_sets if mode == "pool" else static_sets
            out["nsga2_2obj"] = pick(fr["nsga2_2obj"], "min", kmin)
            out["nsga2_2obj_migsel"] = pick(fr["nsga2_2obj"], "mig", kmin)
            out["greenplace"] = pick(fr["greenplace"], "mig", kmin)
            out["greenplace_energypick"] = pick(fr["greenplace"], "min", kmin)
            out["nsga3"] = pick(fr["nsga3"], "min", kmin)
            out["nsga3_migsel"] = pick(fr["nsga3"], "mig", kmin)
            out["mopso"] = pick(fr["mopso"], "min", kmin)
        # SIL pick on the 3-objective front (pool only)
        pk, sil_info = select_by_simulation(p, fronts_pool["greenplace"], C, train, cfg.sil_energy_slack,
                                            cfg.sil_window, cfg.sil_max_candidates)
        pool_sets["greenplace_sil"] = set(pk.controllers) if pk is not None else _fallback(p, K)
        # candidate table for the learned selector (pool only; training + a held-out eval trace)
        feas = [m for m in fronts_pool["greenplace"] if m.feasible]
        if feas:
            e_min = min(m.energy_w for m in feas)
            cands = sorted([m for m in feas if m.energy_w <= cfg.sil_window * e_min], key=lambda m: m.energy_w)[: cfg.sil_max_candidates]
            for ci, m in enumerate(cands):
                row = {"name": meta["name"], "n": n, "seed": seed, "cand": ci, **_cand_features(m, e_min, 0, K, n),
                       "capacity": C, "k_floor": K}
                trn = [life(m.controllers, "diurnal", sd_) if False else simulate(p, set(m.controllers), C, tr) for tr in train for sd_ in [0]]
                row["train_migs"] = sum(x["migrations"] for x in trn) / len(trn)
                row["train_energy"] = sum(x["avg_energy_w"] for x in trn) / len(trn)
                for scen in SCENARIOS:
                    r = life(m.controllers, scen, seed)
                    row[f"migs_{scen}"] = r["migrations"]; row[f"energy_{scen}"] = r["avg_energy_w"]
                cand_rows.append(row)
        # deterministic / single-objective methods
        for method in ("random", "k_center", "k_median", "greedy_cover", "betweenness", "greco", "enplace", "ga_energy", "exact_mip"):
            for mode, kmin, kmax, out in (("pool", K, k_max_pool, pool_sets), ("static", 1, k_max_stat, static_sets)):
                if method in DETERMINISTIC and (method, mode) in det_cache:
                    s, info = det_cache[(method, mode)]
                else:
                    if method == "random":
                        k = B.min_feasible_size(p, lambda k: B.random_feasible(p, k, seed, tries=200), k_start=kmin)
                        s, info = B.random_feasible(p, k, seed, tries=200), {}
                    elif method == "ga_energy":
                        s, info = B.ga_energy(p, kmin, kmax, seed, cfg.nsga_pop, cfg.nsga_gens), {}
                    else:
                        s, info = _det_set(p, method, kmin, kmax, cfg)
                        det_cache[(method, mode)] = (s, info)
                out[method] = set(s)
                if method == "exact_mip":
                    extra_info[("mip", mode)] = info.get("status", "")
        # simulated-migration NSGA-II (small networks, first sim_seeds seeds)
        if with_sim and n <= sim_max_n and seed < sim_seeds:
            t = time.perf_counter()
            fr, sinfo = run_sim_nsga2(p, C, train[:1], K, k_max_pool, seed, pop=30, gens=30)
            pk = select_migration_aware(fr, cfg.energy_slack)
            pool_sets["simnsga"] = set(pk.controllers) if pk is not None else _fallback(p, K)
            times["simnsga_pool"] = time.perf_counter() - t
        # quality indicators of the pool fronts (3-objective hypervolume / IGD, per instance)
        qi = front_indicators({a: fronts_pool[a] for a in FRONT_METHODS})
        for a, v in qi.items():
            quality_rows.append({"name": meta["name"], "n": n, "seed": seed, "algo": a, "mode": "pool",
                                 "hv": float(v["hv"]), "igd": float(v["igd"]), "front_n": v["n"]})
        qi = front_indicators({a: fronts_stat[a] for a in FRONT_METHODS})
        for a, v in qi.items():
            quality_rows.append({"name": meta["name"], "n": n, "seed": seed, "algo": a, "mode": "static",
                                 "hv": float(v["hv"]), "igd": float(v["igd"]), "front_n": v["n"]})
        # evaluate every method
        for method in ALL_METHODS:
            if method not in pool_sets:
                continue
            pool = pool_sets[method]
            stat = static_sets.get(method, pool)
            pl_s, pl_p = p.evaluate(stat), p.evaluate(pool)
            row = {**base, "method": method, "seed": seed, "static_k": len(stat), "static_energy_w": pl_s.energy_w,
                   "static_feasible": pl_s.feasible, "static_valid": method in static_sets,
                   "pool_k": len(pool), "pool_static_energy_w": pl_p.energy_w, "pool_feasible": pl_p.feasible,
                   "pool_burden": pl_p.migration_burden,
                   "mip_status": extra_info.get(("mip", "static"), "") if method == "exact_mip" else "",
                   "t_pool_s": times.get(method + "_pool", float("nan")), "t_static_s": times.get(method + "_static", float("nan"))}
            for scen in SCENARIOS:
                r = life(pool, scen, seed)
                for k, v in r.items():
                    row[f"{scen}__{k}"] = v
            rows.append(row)
            if method == "greenplace":     # hysteresis ablation, diurnal only
                nv = simulate(p, set(pool), C, get_trace("diurnal", seed, cfg.trace_len), ema=1.0, dwell=0)
                rows.append({**row, "method": "greenplace_no_hysteresis", **{f"diurnal__{k}": v for k, v in nv.items()}})
    return rows, cand_rows, quality_rows
