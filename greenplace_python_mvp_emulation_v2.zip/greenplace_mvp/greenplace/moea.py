"""Additional multi-objective baselines (our own re-implementations, NOT the authors' code):

* NSGA-III  (Deb & Jain 2014): reference-point based environmental selection (Das-Dennis points).
* Binary MOPSO with an external non-dominated archive (Coello-style leader selection).
* EnPlace-style: partition-then-place heuristic with energy-driven swap refinement.

All use the same chromosome (binary over nodes), constrained domination, repair to [k_min,k_max] and
objective vector (energy, worst delay, migration burden) as the project's NSGA-II so comparisons are
like-for-like. Each returns a list[Placement] (non-dominated, feasible-first).
"""
from __future__ import annotations

import itertools
import random

import numpy as np

from .baselines import Problem, k_median, is_feasible, min_feasible_size
from .nsga2 import (Individual, _constrained_dominates, _evaluate, _repair, _tournament_select,
                    crowding_distance, fast_non_dominated_sort)


def das_dennis(n_obj: int, divisions: int) -> np.ndarray:
    pts = []
    for c in itertools.combinations(range(divisions + n_obj - 1), n_obj - 1):
        prev, v = -1, []
        for x in c:
            v.append(x - prev - 1)
            prev = x
        v.append(divisions + n_obj - 2 - prev)
        pts.append(np.array(v) / divisions)
    return np.array(pts)


def _front_to_placements(inds: list) -> list:
    nd = fast_non_dominated_sort(list(inds))
    pool = [inds[i] for i in nd[0]] if nd else []
    seen, out = set(), []
    for ind in pool:
        key = frozenset(ind.placement.controllers)
        if key not in seen:
            seen.add(key)
            out.append(ind.placement)
    out.sort(key=lambda q: q.energy_w)
    return out


def _niching_select(combined: list, fronts: list, N: int, refs: np.ndarray, rng: random.Random) -> list:
    chosen, last = [], None
    for f in fronts:
        if len(chosen) + len(f) <= N:
            chosen.extend(f)
        else:
            last = f
            break
    if last is None or len(chosen) == N:
        return [combined[i] for i in chosen]
    pool = chosen + last
    F = np.array([combined[i].objectives for i in pool], dtype=float)
    ideal = F.min(axis=0)
    Fs = F - ideal
    span = Fs.max(axis=0)
    span[span < 1e-12] = 1.0
    Fn = Fs / span                       # simple normalisation (ideal / nadir of the candidate set)
    norm_refs = refs / np.linalg.norm(refs, axis=1, keepdims=True).clip(1e-12)
    proj = Fn @ norm_refs.T
    d2 = (Fn ** 2).sum(1)[:, None] - proj ** 2
    assoc = d2.argmin(1)
    dist = d2[np.arange(len(pool)), assoc]
    niche = np.zeros(len(refs), dtype=int)
    for j in range(len(chosen)):
        niche[assoc[j]] += 1
    last_idx = list(range(len(chosen), len(pool)))
    avail = set(range(len(refs)))
    out = list(chosen)
    while len(out) < N and last_idx:
        cand_refs = [r for r in avail if any(assoc[j] == r for j in last_idx)]
        if not cand_refs:
            break
        mn = min(niche[r] for r in cand_refs)
        r = rng.choice([r for r in cand_refs if niche[r] == mn])
        members = [j for j in last_idx if assoc[j] == r]
        j = min(members, key=lambda j: dist[j]) if niche[r] == 0 else rng.choice(members)
        out.append(pool[j]); last_idx.remove(j); niche[r] += 1
    return [combined[i] for i in out]


def run_nsga3(p: Problem, k_min: int, k_max: int, seed: int, pop: int = 40, gens: int = 60,
              mutation_rate: float = 0.05, divisions: int = 8) -> list:
    rng, nr = random.Random(seed), np.random.default_rng(seed)
    nodes, n = p.nodes, len(p.nodes)
    k_max = min(k_max, n); k_min = min(k_min, k_max)
    refs = das_dennis(3, divisions)
    N = pop

    def ev(g):
        return _evaluate(g, nodes, p.graph, p.engine, p.power, p.delay_config, True)

    def rand():
        g = nr.random(n) < (k_min + k_max) / (2 * n)
        return ev(_repair(g, k_min, k_max, rng))

    P = [rand() for _ in range(N)]
    for _ in range(gens):
        # NSGA-III mating: random pairing (selection pressure comes from niching)
        kids = []
        while len(kids) < N:
            a, b = rng.sample(P, 2)
            g1, g2 = a.genes.copy(), b.genes.copy()
            mask = nr.random(n) < 0.5
            g1, g2 = np.where(mask, a.genes, b.genes), np.where(mask, b.genes, a.genes)
            for g in (g1, g2):
                fl = nr.random(n) < mutation_rate
                g[fl] = ~g[fl]
                _repair(g, k_min, k_max, rng)
                kids.append(ev(g))
        comb = P + kids[:N]
        fronts = fast_non_dominated_sort(comb)
        P = _niching_select(comb, fronts, N, refs, rng)
    return _front_to_placements(P)


def run_mopso(p: Problem, k_min: int, k_max: int, seed: int, swarm: int = 40, iters: int = 60,
              archive_size: int = 40, w: float = 0.6, c1: float = 1.4, c2: float = 1.4) -> list:
    rng, nr = random.Random(seed), np.random.default_rng(seed)
    nodes, n = p.nodes, len(p.nodes)
    k_max = min(k_max, n); k_min = min(k_min, k_max)

    def ev(g):
        return _evaluate(g, nodes, p.graph, p.engine, p.power, p.delay_config, True)

    X = []
    for _ in range(swarm):
        g = nr.random(n) < (k_min + k_max) / (2 * n)
        X.append(ev(_repair(g, k_min, k_max, rng)))
    V = nr.normal(0, 0.5, size=(swarm, n))
    pbest = list(X)
    archive: list = []

    def update_archive(cands):
        nonlocal archive
        allc = archive + cands
        nd = fast_non_dominated_sort(list(allc))
        arch = [allc[i] for i in nd[0]] if nd else []
        uniq, seen = [], set()
        for a in arch:
            key = frozenset(a.placement.controllers)
            if key not in seen:
                seen.add(key); uniq.append(a)
        if len(uniq) > archive_size:
            crowding_distance(uniq, list(range(len(uniq))))
            uniq.sort(key=lambda a: a.crowding, reverse=True)
            uniq = uniq[:archive_size]
        archive = uniq

    update_archive(list(X))
    for _ in range(iters):
        for i in range(swarm):
            leader = rng.choice(archive)
            r1, r2 = nr.random(n), nr.random(n)
            V[i] = (w * V[i] + c1 * r1 * (pbest[i].genes.astype(float) - X[i].genes)
                    + c2 * r2 * (leader.genes.astype(float) - X[i].genes))
            V[i] = np.clip(V[i], -4, 4)
            g = nr.random(n) < 1 / (1 + np.exp(-V[i]))
            g = _repair(g, k_min, k_max, rng)
            X[i] = ev(g)
            if _constrained_dominates(X[i], pbest[i]) or (not _constrained_dominates(pbest[i], X[i]) and rng.random() < 0.5):
                pbest[i] = X[i]
        update_archive(list(X))
    return _front_to_placements(archive)


def enplace_style(p: Problem, k_min: int = 1, swap_passes: int = 2) -> set:
    """Partition-then-place: smallest k whose k-median partition is delay-feasible, then energy swaps."""
    k = min_feasible_size(p, lambda kk: k_median(p, kk), k_start=max(1, k_min))
    cur = set(k_median(p, k))
    if not is_feasible(p, cur):
        return cur
    best = p.evaluate(cur).energy_w
    for _ in range(swap_passes):
        improved = False
        for c in list(cur):
            for v in p.nodes:
                if v in cur:
                    continue
                trial = (cur - {c}) | {v}
                if is_feasible(p, trial):
                    e = p.evaluate(trial).energy_w
                    if e < best - 1e-9:
                        cur, best, improved = trial, e, True
                        break
        if not improved:
            break
    return cur
