"""Control-plane power/energy model.

Follows the energy formulation established in the energy-aware CPP literature:
Hu, Luo, Beaulieu & Deng (2017), "The Energy-Aware Controller Placement Problem
in Software Defined Networks," IEEE Communications Letters 21(4) -- minimize
active control links under delay/load constraints -- and Kondo et al. (2026),
"Energy-Aware Controller Placement With Delay Guarantees for In-Band SDN,"
IJNM 36(1), whose BIP formulation over the Janos-US topology found that idle
(base) power draw of switches/controllers dominates total energy use far more
than port activity or CPU load -- the empirical justification for modeling
power primarily as a function of which devices are active, not how busy they
are.
"""
from __future__ import annotations

from .config import PowerModel
from .delay import DelayEngine


def control_plane_energy_w(
    controllers: set,
    assignment: dict,
    delay_engine: DelayEngine,
    power_model: PowerModel,
) -> float:
    """Total instantaneous control-plane power (Watts) for a given placement.

    energy = sum(active controller power) + sum(hop_count(switch, its controller) * link_hop_w)

    This mirrors the framing used in Kondo et al. and GreCo: energy is driven by
    how many controllers are switched on and how many control-link hops are kept
    active to reach them, not by data-plane forwarding (assumed always-on).
    """
    total = len(controllers) * power_model.controller_active_w
    for switch, controller in assignment.items():
        if switch == controller:
            continue
        total += delay_engine.hop_count(switch, controller) * power_model.link_hop_w
    return total


def energy_breakdown(
    controllers: set,
    assignment: dict,
    delay_engine: DelayEngine,
    power_model: PowerModel,
) -> dict:
    """Same computation as control_plane_energy_w but returns a labeled breakdown,
    useful for reporting/plotting.
    """
    controller_w = len(controllers) * power_model.controller_active_w
    link_w = 0.0
    total_hops = 0
    for switch, controller in assignment.items():
        if switch == controller:
            continue
        hops = delay_engine.hop_count(switch, controller)
        total_hops += hops
        link_w += hops * power_model.link_hop_w
    return {
        "controller_w": controller_w,
        "link_w": link_w,
        "total_w": controller_w + link_w,
        "num_controllers": len(controllers),
        "total_link_hops": total_hops,
    }
