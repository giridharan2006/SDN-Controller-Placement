"""Baseline controller-placement algorithms, for benchmarking GreenPlace.

IMPORTANT — what these are and are not
--------------------------------------
These are *our own re-implementations of the algorithmic ideas* behind well-known
families of controller-placement work, run on exactly the same problem definition
(same graph, same hard delay bound, same power model, same evaluation code) as
GreenPlace. They are NOT the original authors' code, and they are not guaranteed
to reproduce each paper's published numbers (those papers use their own
simulators, topologies and parameters). The comparison therefore answers
"how does GreenPlace's approach fare against these *approaches* on a common
footing?", not "does GreenPlace beat paper X's published results?".

Family                              Implemented here as                 Lineage
----------------------------------  ----------------------------------  ----------------------------
Latency-optimal k-center            `k_center`   (greedy + swaps)       Heller et al. 2012
Latency-optimal k-median            `k_median`   (greedy + swaps / PAM) Heller et al. 2012
Min-#controllers under a bound      `greedy_cover`                      Ul Huque et al. 2017
Centrality-based placement          `betweenness`                       common heuristic baseline
Energy-aware greedy consolidation   `greco_style`                       GreCo (Ruiz-Rivera et al. 2015)
Single-objective metaheuristic      `ga_energy`  (penalty GA)           EHACP-GA (Mohanty & Sahoo 2025)
Exact energy-min MIP                `exact_mip`  (CBC)                  Kondo et al. 2023/2026-style
Multi-objective evolutionary        `nsga2_energy_delay` (2 objectives) Jalili-style NSGA-II lineage
Random (sanity floor)               `random_feasible`

Not re-implemented (no public code / substantially different system model):
EnPlace's network partitioning, Adekoya's NSGA-III + ISMDA, RL-based placement.
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass

import networkx as nx
import numpy as np

from .config import DelayConfig, NSGA2Config, PowerModel
from .delay import DelayEngine
from .ilp_solver import solve_exact
from .nsga2 import _repair, run_nsga2
from .placement import Placement, evaluate_placement


@dataclass
class Problem:
    """Everything a placement algorithm needs, bundled."""
    graph: nx.Graph
    engine: DelayEngine
    power: PowerModel
    delay_config: DelayConfig

    @property
    def bound(self) -> float:
        return self.delay_config.max_switch_to_controller_delay_ms

    @property
    def nodes(self) -> list:
        return list(self.graph.nodes)

    def evaluate(self, controllers: set) -> Placement:
        return evaluate_placement(self.graph, set(controllers), self.engine, self.power, self.delay_config)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _worst_delay(p: Problem, controllers) -> float:
    if not controllers:
        return float("inf")
    return max(min(p.engine.delay(n, c) for c in controllers) for n in p.graph.nodes)


def _avg_delay(p: Problem, controllers) -> float:
    if not controllers:
        return float("inf")
    return sum(min(p.engine.delay(n, c) for c in controllers) for n in p.graph.nodes) / p.graph.number_of_nodes()


def is_feasible(p: Problem, controllers) -> bool:
    return _worst_delay(p, controllers) <= p.bound + 1e-9


def min_feasible_size(p: Problem, builder, k_start: int = 1) -> int:
    """Smallest k >= k_start for which builder(k) is delay-feasible (monotone search)."""
    n = p.graph.number_of_nodes()
    for k in range(max(1, k_start), n + 1):
        if is_feasible(p, builder(k)):
            return k
    return n


# ---------------------------------------------------------------------------
# 1. Random feasible (sanity floor)
# ---------------------------------------------------------------------------
def random_feasible(p: Problem, k: int, seed: int = 0, tries: int = 300) -> set:
    rng = random.Random(seed)
    nodes = p.nodes
    k = min(k, len(nodes))
    best, best_key = None, None
    for _ in range(tries):
        s = set(rng.sample(nodes, k))
        w = _worst_delay(p, s)
        key = (0.0 if w <= p.bound else w - p.bound, p.evaluate(s).energy_w if w <= p.bound else 0.0)
        if best_key is None or key < best_key:
            best, best_key = s, key
    return best


# ---------------------------------------------------------------------------
# 2. Latency-optimal k-center (Heller et al. 2012 objective: worst-case latency)
# ---------------------------------------------------------------------------
def k_center(p: Problem, k: int, swap_passes: int = 2) -> set:
    nodes = p.nodes
    k = min(k, len(nodes))
    # start from the graph center (min eccentricity), then farthest-first traversal
    first = min(nodes, key=lambda c: max(p.engine.delay(n, c) for n in nodes))
    chosen = {first}
    while len(chosen) < k:
        far = max((n for n in nodes if n not in chosen),
                  key=lambda n: min(p.engine.delay(n, c) for c in chosen))
        chosen.add(far)
    # swap local search on worst-case delay (ties broken by average delay)
    def cost(s):
        return (_worst_delay(p, s), _avg_delay(p, s))
    for _ in range(swap_passes):
        improved = False
        for out in list(chosen):
            for inn in nodes:
                if inn in chosen:
                    continue
                trial = (chosen - {out}) | {inn}
                if cost(trial) < cost(chosen):
                    chosen, improved = trial, True
                    break
        if not improved:
            break
    return chosen


# ---------------------------------------------------------------------------
# 3. Latency-optimal k-median (Heller et al. 2012 objective: average latency)
# ---------------------------------------------------------------------------
def k_median(p: Problem, k: int, swap_passes: int = 2) -> set:
    nodes = p.nodes
    k = min(k, len(nodes))
    chosen: set = set()
    while len(chosen) < k:  # greedy add: node that reduces average delay the most
        best = min((n for n in nodes if n not in chosen), key=lambda n: _avg_delay(p, chosen | {n}))
        chosen.add(best)
    for _ in range(swap_passes):  # PAM-style swaps
        improved = False
        cur = _avg_delay(p, chosen)
        for out in list(chosen):
            for inn in nodes:
                if inn in chosen:
                    continue
                trial = (chosen - {out}) | {inn}
                if _avg_delay(p, trial) < cur - 1e-12:
                    chosen, cur, improved = trial, _avg_delay(p, trial), True
                    break
        if not improved:
            break
    return chosen


# ---------------------------------------------------------------------------
# 4. Greedy set cover: fewest controllers that cover every switch within the bound
#    (the "minimise #controllers subject to a latency bound" family, Ul Huque et al.)
# ---------------------------------------------------------------------------
def greedy_cover(p: Problem, k_target: int = 1) -> set:
    nodes = p.nodes
    covers = {c: {n for n in nodes if p.engine.delay(n, c) <= p.bound + 1e-9} for c in nodes}
    uncovered = set(nodes)
    chosen: set = set()
    while uncovered:
        best = max((c for c in nodes if c not in chosen), key=lambda c: len(covers[c] & uncovered))
        if not covers[best] & uncovered:
            break
        chosen.add(best)
        uncovered -= covers[best]
    # If a larger pool is requested (e.g. to serve peak load), grow it with the
    # k-median greedy rule so the extra controllers are still sensibly placed.
    while len(chosen) < min(k_target, len(nodes)):
        best = min((n for n in nodes if n not in chosen), key=lambda n: _avg_delay(p, chosen | {n}))
        chosen.add(best)
    return chosen


# ---------------------------------------------------------------------------
# 5. Betweenness-centrality placement (a common, cheap heuristic)
# ---------------------------------------------------------------------------
def betweenness(p: Problem, k: int) -> set:
    bc = nx.betweenness_centrality(p.graph, weight="delay")
    order = sorted(p.nodes, key=lambda n: (-bc[n], str(n)))
    return set(order[: min(k, len(order))])


# ---------------------------------------------------------------------------
# 6. GreCo-style greedy energy consolidation
#    GreCo starts from an existing controller deployment and switches off as
#    many controllers/links as delay allows to save energy.  We model that as:
#    over-provisioned deployment -> repeatedly deactivate the controller whose
#    removal saves the most energy while the delay bound still holds.
# ---------------------------------------------------------------------------
def greco_style(p: Problem, min_size: int = 1, overprovision: int | None = None) -> set:
    nodes = p.nodes
    n = len(nodes)
    if overprovision is None:
        overprovision = max(2 * max(min_size, 2), min_size + 3)
    start = k_center(p, min(n, overprovision), swap_passes=0)
    while not is_feasible(p, start) and len(start) < n:  # make sure we start feasible
        start = k_center(p, len(start) + 1, swap_passes=0)
    current = set(start)
    while len(current) > min_size:
        best_set, best_energy = None, p.evaluate(current).energy_w
        for c in current:
            trial = current - {c}
            if is_feasible(p, trial):
                e = p.evaluate(trial).energy_w
                if e < best_energy:
                    best_set, best_energy = trial, e
        if best_set is None:
            break
        current = best_set
    return current


# ---------------------------------------------------------------------------
# 7. Single-objective GA (EHACP-GA-style): minimise energy, delay as a penalty
# ---------------------------------------------------------------------------
def ga_energy(p: Problem, k_min: int, k_max: int, seed: int = 0,
              population_size: int = 60, generations: int = 100,
              crossover_rate: float = 0.9, mutation_rate: float = 0.05) -> set:
    rng = random.Random(seed)
    np_rng = np.random.default_rng(seed)
    nodes = p.nodes
    n = len(nodes)
    k_max = min(k_max, n)
    k_min = min(k_min, k_max)
    penalty = 10_000.0  # W per ms of delay-bound violation: dominates any energy gain

    def fitness(genes):
        placement = p.evaluate({nodes[i] for i in np.flatnonzero(genes)})
        return placement.energy_w + penalty * placement.violation_ms, placement

    def rand_ind():
        g = np_rng.random(n) < (k_min + k_max) / (2 * n)
        g = _repair(g, k_min, k_max, rng)
        f, pl = fitness(g)
        return [g, f, pl]

    pop = [rand_ind() for _ in range(population_size)]

    def tournament():
        a, b = rng.sample(pop, 2)
        return a if a[1] <= b[1] else b

    for _ in range(generations):
        children = []
        while len(children) < population_size:
            p1, p2 = tournament(), tournament()
            g1, g2 = p1[0].copy(), p2[0].copy()
            if rng.random() < crossover_rate:
                mask = np_rng.random(n) < 0.5
                g1, g2 = np.where(mask, p1[0], p2[0]), np.where(mask, p2[0], p1[0])
            for g in (g1, g2):
                flip = np_rng.random(n) < mutation_rate
                g[flip] = ~g[flip]
                _repair(g, k_min, k_max, rng)
                f, pl = fitness(g)
                children.append([g, f, pl])
        pop = sorted(pop + children, key=lambda x: x[1])[:population_size]  # elitist (mu+lambda)
    return set(pop[0][2].controllers)


# ---------------------------------------------------------------------------
# 8. Exact MIP (Kondo-style: minimise energy subject to a hard delay bound)
# ---------------------------------------------------------------------------
def exact_mip(p: Problem, k_min: int = 1, k_max: int | None = None, time_limit_s: float | None = 60.0):
    placement, info = solve_exact(p.graph, p.engine, p.power, p.delay_config, k_min, k_max, time_limit_s)
    # The MIP optimises over *free* switch->controller assignment (any controller within the delay bound), whereas
    # every method is evaluated with nearest-controller assignment. `model_energy_w` is therefore a valid LOWER BOUND
    # on the nearest-assignment energy of any placement, and the returned set is NOT guaranteed optimal under
    # nearest assignment.
    info = dict(info); info["model_energy_w"] = placement.energy_w
    return set(placement.controllers), info


# ---------------------------------------------------------------------------
# 9. NSGA-II (energy + delay only) — multi-objective lineage WITHOUT migration awareness
# ---------------------------------------------------------------------------
def nsga2_front(p: Problem, k_min: int, k_max: int, seed: int, migration_aware: bool,
                population_size: int = 60, generations: int = 100) -> list:
    cfg = NSGA2Config(population_size=population_size, generations=generations,
                      k_min=k_min, k_max=k_max, random_seed=seed, optimize_migration=migration_aware)
    return run_nsga2(p.graph, p.engine, p.power, p.delay_config, cfg)


# ---------------------------------------------------------------------------
# registry (name -> description), used by reports and plots
# ---------------------------------------------------------------------------
METHODS = {
    "random":        ("Random feasible",                    "sanity floor"),
    "k_center":      ("k-center (Heller-style)",            "latency-optimal, worst-case"),
    "k_median":      ("k-median (Heller-style)",            "latency-optimal, average"),
    "greedy_cover":  ("Greedy cover (min #controllers)",    "Ul Huque-style, bound-driven"),
    "betweenness":   ("Betweenness centrality",             "common cheap heuristic"),
    "greco":         ("GreCo-style consolidation",          "energy-aware greedy"),
    "ga_energy":     ("Single-objective GA (EHACP-GA-style)", "energy only, delay penalty"),
    "exact_mip":     ("Exact MIP (Kondo-style)",            "energy-optimal reference"),
    "nsga2_2obj":    ("NSGA-II energy+delay (Jalili-style)", "no migration awareness"),
    "nsga2_2obj_migsel": ("CONTROL: 2-obj NSGA-II + migration-aware pick", "isolates search vs. selection"),
    "greenplace":    ("GreenPlace (3-obj NSGA-II)",         "migration-aware (proposed)"),
    "nsga2_2obj_sil": ("CONTROL: 2-obj NSGA-II + simulation pick", "isolates search under SIL selection"),
    "greenplace_sil": ("GreenPlace-SIL (simulation-in-the-loop)", "improved selection (this study)"),
}
