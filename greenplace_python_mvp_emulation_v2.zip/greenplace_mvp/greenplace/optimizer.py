"""Unified entry point for offline placement optimization.

Selects a solving strategy ("exact" or "nsga2") behind one function so
scripts/benchmarks don't need to know which backend is in use. This is also
the intended extension point for a future MOPSO or pymoo-backed backend:
add a new branch here returning `list[Placement]` and nothing else changes.
"""
from __future__ import annotations

import networkx as nx

from .config import DelayConfig, NSGA2Config, PowerModel
from .delay import DelayEngine
from .ilp_solver import solve_exact
from .nsga2 import run_nsga2
from .placement import Placement


def optimize(
    graph: nx.Graph,
    method: str = "nsga2",
    power_model: PowerModel = PowerModel(),
    delay_config: DelayConfig = DelayConfig(),
    nsga2_config: NSGA2Config = NSGA2Config(),
    k_min: int = 1,
    k_max: int | None = None,
) -> tuple[list[Placement], dict]:
    """Run the selected optimizer. Returns (placements, info).

    method="exact" -> a single-element list containing the exact optimum
                       (or best-found within the enumerated k-range).
    method="nsga2" -> the final Pareto front (list of non-dominated Placements).
    """
    delay_engine = DelayEngine(graph)

    if method == "exact":
        placement, info = solve_exact(graph, delay_engine, power_model, delay_config, k_min, k_max)
        return [placement], info

    if method == "nsga2":
        cfg = nsga2_config
        cfg.k_min, cfg.k_max = k_min, (k_max or cfg.k_max)
        front = run_nsga2(graph, delay_engine, power_model, delay_config, cfg)
        info = {"backend": "nsga2", "pareto_front_size": len(front)}
        return front, info

    raise ValueError(f"Unknown method: {method!r}. Use 'exact' or 'nsga2'.")
