"""Run a candidate controller pool through the runtime elastic manager over a traffic trace."""
from __future__ import annotations

from .config import RuntimeConfig
from .runtime import RuntimeManager


def simulate(p, pool: set, capacity: int, trace, ema: float = 0.3, dwell: int = 2) -> dict:
    rt = RuntimeConfig(controller_capacity=capacity, timesteps=len(trace),
                       load_ema_alpha=ema, min_dwell_steps=dwell)
    res = RuntimeManager(p.graph, pool, p.power, p.delay_config, rt, delay_engine=p.engine).run(trace)
    counts = [r.active_controllers for r in res]
    return {
        "avg_energy_w": sum(r.energy_w for r in res) / len(res),
        "migrations": sum(r.migrations for r in res),
        "violations": sum(1 for r in res if not r.feasible),
        "transitions": sum(1 for a, b in zip(counts, counts[1:]) if a != b),
        # total controller sleep/wake events (each controller turned on or off once = 1), a better
        # proxy for boot-energy / disruption cost than the number of steps at which the count changed
        "state_changes": sum(abs(b - a) for a, b in zip(counts, counts[1:])),
        "avg_active": sum(counts) / len(counts),
        "min_active": min(counts),
        "max_active": max(counts),
    }
