"""Self-contained NSGA-II for the energy-vs-delay Controller Placement Problem.

Implemented from scratch (no external MOO dependency) so the MVP has zero
extra install requirements beyond networkx/numpy. It follows Deb et al.
(2002) "A Fast and Elitist Multiobjective Genetic Algorithm: NSGA-II":
fast non-dominated sorting, crowding-distance environmental selection, and
constrained-domination (Deb's feasibility-first comparison) to enforce the
hard delay-SLA bound.

The overall population/Pareto-front structure is descended from Jalili,
Keshtgari & Akbari (2018), "Optimal controller placement in large scale
software defined networks based on modified NSGA-II," Applied Intelligence
48, 2809-2823 — their Multi-Start Hybrid NSGA-II is the closest algorithmic
ancestor, though their objectives are latency-type metrics only, with no
energy term. The controller-count search range (k_min/k_max) follows the
"minimize active controllers under a hard latency bound" framing of Ul Huque,
Si, Jourjon & Gramoli (2017), "Large-Scale Dynamic Controller Placement,"
IEEE TNSM 14(1).

Chromosome: a binary vector over graph nodes; a 1-bit means that node is an
active controller. Objectives (all minimized): total control-plane energy
(W), worst-case switch-to-controller delay (ms), and — when
`NSGA2Config.optimize_migration=True` (the default) — the worst-case
switch-migration burden (see `placement.worst_case_migration_burden`), the
project's sharpened novelty contribution: placement quality accounts for how
expensive a *future* runtime consolidation would be, not just the placement's
own energy and delay. Feasibility = delay bound respected.

This module is intentionally self-contained so a MOPSO backend (or pymoo,
once installed) can later be dropped in behind the same `optimize()` entry
point in optimizer.py without touching the rest of the pipeline.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

import networkx as nx
import numpy as np

from .config import DelayConfig, NSGA2Config, PowerModel
from .delay import DelayEngine
from .placement import Placement, evaluate_placement


@dataclass
class Individual:
    genes: np.ndarray
    placement: Placement = None
    rank: int = -1
    crowding: float = 0.0
    optimize_migration: bool = True

    @property
    def objectives(self) -> tuple:
        if self.optimize_migration:
            return (self.placement.energy_w, self.placement.worst_case_delay_ms, self.placement.migration_burden)
        return (self.placement.energy_w, self.placement.worst_case_delay_ms)

    @property
    def feasible(self) -> bool:
        return self.placement.feasible

    @property
    def violation(self) -> float:
        return self.placement.violation_ms


def _decode(genes: np.ndarray, nodes: list) -> set:
    return {nodes[i] for i in range(len(nodes)) if genes[i]}


def _evaluate(
    genes: np.ndarray,
    nodes: list,
    graph: nx.Graph,
    delay_engine: DelayEngine,
    power_model: PowerModel,
    delay_config: DelayConfig,
    optimize_migration: bool = True,
    burden_fn=None,
) -> Individual:
    controllers = _decode(genes, nodes)
    placement = evaluate_placement(graph, controllers, delay_engine, power_model, delay_config)
    if burden_fn is not None:   # replace the offline proxy by a custom (e.g. simulated) migration objective
        placement.migration_burden = float(burden_fn(placement))
    return Individual(genes=genes, placement=placement, optimize_migration=optimize_migration)


def _repair(genes: np.ndarray, k_min: int, k_max: int, rng: random.Random) -> np.ndarray:
    count = int(genes.sum())
    idx = list(range(len(genes)))
    if count < k_min:
        zeros = [i for i in idx if not genes[i]]
        rng.shuffle(zeros)
        for i in zeros[: k_min - count]:
            genes[i] = True
    elif count > k_max:
        ones = [i for i in idx if genes[i]]
        rng.shuffle(ones)
        for i in ones[: count - k_max]:
            genes[i] = False
    return genes


def _constrained_dominates(a: Individual, b: Individual) -> bool:
    """Deb's constrained-domination: feasible beats infeasible; among infeasible,
    lower violation wins; among feasible, standard Pareto dominance applies."""
    if a.feasible and not b.feasible:
        return True
    if not a.feasible and b.feasible:
        return False
    if not a.feasible and not b.feasible:
        return a.violation < b.violation
    # both feasible -> standard Pareto dominance (minimize both objectives)
    ao, bo = a.objectives, b.objectives
    not_worse = all(x <= y for x, y in zip(ao, bo))
    strictly_better = any(x < y for x, y in zip(ao, bo))
    return not_worse and strictly_better


def fast_non_dominated_sort(pop: list) -> list:
    fronts: list = [[]]
    dom_count = [0] * len(pop)
    dominated = [[] for _ in pop]

    for p in range(len(pop)):
        for q in range(len(pop)):
            if p == q:
                continue
            if _constrained_dominates(pop[p], pop[q]):
                dominated[p].append(q)
            elif _constrained_dominates(pop[q], pop[p]):
                dom_count[p] += 1
        if dom_count[p] == 0:
            pop[p].rank = 0
            fronts[0].append(p)

    i = 0
    while fronts[i]:
        next_front = []
        for p in fronts[i]:
            for q in dominated[p]:
                dom_count[q] -= 1
                if dom_count[q] == 0:
                    pop[q].rank = i + 1
                    next_front.append(q)
        i += 1
        fronts.append(next_front)
    return fronts[:-1]  # drop trailing empty front


def crowding_distance(pop: list, front: list) -> None:
    if not front:
        return
    for idx in front:
        pop[idx].crowding = 0.0
    n_obj = len(pop[front[0]].objectives)
    for m in range(n_obj):
        front_sorted = sorted(front, key=lambda i: pop[i].objectives[m])
        pop[front_sorted[0]].crowding = float("inf")
        pop[front_sorted[-1]].crowding = float("inf")
        obj_vals = [pop[i].objectives[m] for i in front_sorted]
        span = obj_vals[-1] - obj_vals[0]
        if span == 0:
            continue
        for k in range(1, len(front_sorted) - 1):
            prev_v = obj_vals[k - 1]
            next_v = obj_vals[k + 1]
            pop[front_sorted[k]].crowding += (next_v - prev_v) / span


def _tournament_select(pop: list, rng: random.Random) -> Individual:
    a, b = rng.sample(range(len(pop)), 2)
    ia, ib = pop[a], pop[b]
    if ia.rank < ib.rank:
        return ia
    if ib.rank < ia.rank:
        return ib
    return ia if ia.crowding > ib.crowding else ib


def run_nsga2(
    graph: nx.Graph,
    delay_engine: DelayEngine,
    power_model: PowerModel,
    delay_config: DelayConfig,
    cfg: NSGA2Config = NSGA2Config(),
    burden_fn=None,
) -> list[Placement]:
    """Run NSGA-II and return the final Pareto front as a list of Placement objects.

    `burden_fn(placement) -> float` optionally replaces the offline migration-burden proxy (3rd objective)
    with a custom estimate, e.g. migrations measured by simulating the runtime manager (see simnsga.py).
    """
    rng = random.Random(cfg.random_seed)
    np_rng = np.random.default_rng(cfg.random_seed)
    nodes = list(graph.nodes)
    n = len(nodes)
    k_max = min(cfg.k_max, n)
    k_min = min(cfg.k_min, k_max)

    def random_individual() -> Individual:
        genes = np_rng.random(n) < (k_min + k_max) / (2 * n)
        genes = _repair(genes, k_min, k_max, rng)
        return _evaluate(genes, nodes, graph, delay_engine, power_model, delay_config, cfg.optimize_migration, burden_fn)

    population = [random_individual() for _ in range(cfg.population_size)]
    fronts = fast_non_dominated_sort(population)
    for f in fronts:
        crowding_distance(population, f)

    for _generation in range(cfg.generations):
        offspring_genes = []
        while len(offspring_genes) < cfg.population_size:
            p1 = _tournament_select(population, rng)
            p2 = _tournament_select(population, rng)
            g1, g2 = p1.genes.copy(), p2.genes.copy()
            if rng.random() < cfg.crossover_rate:
                mask = np_rng.random(n) < 0.5
                g1, g2 = np.where(mask, p1.genes, p2.genes), np.where(mask, p2.genes, p1.genes)
            for g in (g1, g2):
                flip = np_rng.random(n) < cfg.mutation_rate
                g[flip] = ~g[flip]
                _repair(g, k_min, k_max, rng)
            offspring_genes.append(g1)
            offspring_genes.append(g2)
        offspring_genes = offspring_genes[: cfg.population_size]

        offspring = [
            _evaluate(g, nodes, graph, delay_engine, power_model, delay_config, cfg.optimize_migration, burden_fn)
            for g in offspring_genes
        ]

        combined = population + offspring
        fronts = fast_non_dominated_sort(combined)
        for f in fronts:
            crowding_distance(combined, f)

        next_population: list = []
        for front in fronts:
            if len(next_population) + len(front) <= cfg.population_size:
                next_population.extend(combined[i] for i in front)
            else:
                remaining = cfg.population_size - len(next_population)
                front_sorted = sorted(front, key=lambda i: combined[i].crowding, reverse=True)
                next_population.extend(combined[i] for i in front_sorted[:remaining])
                break
        population = next_population

    final_fronts = fast_non_dominated_sort(population)
    pareto_front = [population[i] for i in final_fronts[0]] if final_fronts else []
    # De-duplicate identical placements (same controller set) for a cleaner front.
    seen = set()
    result = []
    for ind in pareto_front:
        key = frozenset(ind.placement.controllers)
        if key in seen:
            continue
        seen.add(key)
        result.append(ind.placement)
    result.sort(key=lambda p: p.energy_w)
    return result
