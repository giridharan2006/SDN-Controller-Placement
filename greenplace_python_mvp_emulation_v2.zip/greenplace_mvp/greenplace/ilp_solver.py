"""Exact solver for the Controller Placement Problem.

Two backends:
  * PuLP-backed exact ILP (used automatically if `pulp` is installed) — solves
    the joint controller-placement + switch-assignment problem as a proper
    mixed-integer program (facility-location style formulation).
  * Exhaustive-search fallback (no dependencies) — enumerates every candidate
    controller subset within [k_min, k_max], assigns switches to the nearest
    active controller, and keeps the true minimum-energy feasible placement.
    This is exact (not a heuristic) for the small topologies it's intended
    for (roughly <= 12-14 nodes); it is what the NSGA-II heuristic in
    nsga2.py is benchmarked against when PuLP is unavailable.

Only used for SMALL topologies (a handful to ~12 nodes) as a ground-truth
validation baseline for the NSGA-II heuristic — see scripts/run_ilp_vs_nsga2.py.
"""
from __future__ import annotations

import itertools
import time

import networkx as nx

from .config import DelayConfig, PowerModel
from .delay import DelayEngine
from .placement import Placement, evaluate_placement

try:
    import pulp  # type: ignore
    # PuLP 4.x changed its modelling API (LpVariable is no longer constructed
    # from a name/category). Probe the API we rely on and fall back to the
    # exhaustive solver instead of crashing on an incompatible version.
    pulp.LpVariable("_gp_probe", cat="Binary")
    _HAS_PULP = True
except Exception:  # ImportError, or TypeError/AttributeError on PuLP>=4
    pulp = None  # type: ignore
    _HAS_PULP = False


def solve_exact(
    graph: nx.Graph,
    delay_engine: DelayEngine,
    power_model: PowerModel,
    delay_config: DelayConfig,
    k_min: int = 1,
    k_max: int | None = None,
    time_limit_s: float | None = None,
) -> tuple[Placement, dict]:
    """Return (best_placement, solver_info). Dispatches to PuLP if available.

    `time_limit_s` bounds the MIP (CBC) wall-clock time; if the limit is hit the
    best incumbent is returned and info["status"] reports it (the result is then
    a feasible upper bound, not a proven optimum).
    """
    if _HAS_PULP:
        return _solve_pulp(graph, delay_engine, power_model, delay_config, k_min, k_max, time_limit_s)
    return _solve_bruteforce(graph, delay_engine, power_model, delay_config, k_min, k_max)


def _solve_bruteforce(
    graph: nx.Graph,
    delay_engine: DelayEngine,
    power_model: PowerModel,
    delay_config: DelayConfig,
    k_min: int,
    k_max: int | None,
) -> tuple[Placement, dict]:
    nodes = list(graph.nodes)
    k_max = k_max or len(nodes)
    start = time.perf_counter()

    best: Placement | None = None
    evaluated = 0
    for k in range(k_min, k_max + 1):
        for combo in itertools.combinations(nodes, k):
            evaluated += 1
            placement = evaluate_placement(graph, set(combo), delay_engine, power_model, delay_config)
            if not placement.feasible:
                continue
            if best is None or placement.energy_w < best.energy_w:
                best = placement

    elapsed = time.perf_counter() - start
    info = {
        "backend": "bruteforce",
        "candidates_evaluated": evaluated,
        "runtime_s": round(elapsed, 4),
        "note": "Exact for the enumerated k-range; install `pulp` for a scalable MIP formulation.",
    }
    if best is None:
        best = Placement(controllers=set(), feasible=False, energy_w=float("inf"),
                          worst_case_delay_ms=float("inf"), violation_ms=float("inf"))
        info["status"] = "infeasible"
    else:
        info["status"] = "optimal"
    return best, info


def _solve_pulp(
    graph: nx.Graph,
    delay_engine: DelayEngine,
    power_model: PowerModel,
    delay_config: DelayConfig,
    k_min: int,
    k_max: int | None,
    time_limit_s: float | None = None,
) -> tuple[Placement, dict]:
    """Facility-location-style MIP: minimize controller + link-hop power subject to
    a hard delay bound and single-assignment constraints.

    x_c in {0,1}: controller c is active
    y_{s,c} in {0,1}: switch s is assigned to controller c
    """
    nodes = list(graph.nodes)
    k_max = k_max or len(nodes)
    start = time.perf_counter()

    prob = pulp.LpProblem("cpp_energy_delay", pulp.LpMinimize)
    x = {c: pulp.LpVariable(f"x_{c}", cat="Binary") for c in nodes}
    y = {(s, c): pulp.LpVariable(f"y_{s}_{c}", cat="Binary") for s in nodes for c in nodes}

    hop = {(s, c): delay_engine.hop_count(s, c) for s in nodes for c in nodes}
    dly = {(s, c): delay_engine.delay(s, c) for s in nodes for c in nodes}
    bound = delay_config.max_switch_to_controller_delay_ms

    # Objective: controller power + link-hop power.
    prob += (
        pulp.lpSum(power_model.controller_active_w * x[c] for c in nodes)
        + pulp.lpSum(power_model.link_hop_w * hop[(s, c)] * y[(s, c)] for s in nodes for c in nodes)
    )

    # Each switch assigned to exactly one controller.
    for s in nodes:
        prob += pulp.lpSum(y[(s, c)] for c in nodes) == 1

    # Can only assign to an active controller; assignment must respect the delay bound.
    for s in nodes:
        for c in nodes:
            prob += y[(s, c)] <= x[c]
            if dly[(s, c)] > bound:
                prob += y[(s, c)] == 0

    # Controller-count bounds.
    prob += pulp.lpSum(x[c] for c in nodes) >= k_min
    prob += pulp.lpSum(x[c] for c in nodes) <= k_max

    solver = pulp.PULP_CBC_CMD(msg=False, timeLimit=time_limit_s) if time_limit_s else pulp.PULP_CBC_CMD(msg=False)
    prob.solve(solver)
    elapsed = time.perf_counter() - start

    status = pulp.LpStatus[prob.status]
    info = {"backend": "pulp+cbc", "runtime_s": round(elapsed, 4), "status": status}

    # With a time limit CBC may stop at a feasible-but-unproven incumbent; PuLP
    # reports that as "Not Solved"/"Optimal" depending on version, so accept any
    # status that actually produced an integral solution.
    have_solution = all(x[c].value() is not None for c in nodes)
    if time_limit_s and have_solution and status != "Optimal":
        info["status"] = "Feasible (time limit)"
        status = "Optimal"
    if status != "Optimal":
        return Placement(controllers=set(), feasible=False, energy_w=float("inf"),
                          worst_case_delay_ms=float("inf"), violation_ms=float("inf")), info

    controllers = {c for c in nodes if x[c].value() > 0.5}
    assignment = {s: c for s in nodes for c in nodes if y[(s, c)].value() > 0.5}
    worst = delay_engine.worst_case_delay(assignment)
    from .power import control_plane_energy_w
    energy = control_plane_energy_w(controllers, assignment, delay_engine, power_model)

    placement = Placement(
        controllers=controllers,
        assignment=assignment,
        energy_w=energy,
        worst_case_delay_ms=worst,
        feasible=True,
        violation_ms=0.0,
    )
    return placement, info
