"""Runtime energy-elastic controller management ('Phase 2' of GreenPlace).

Given a pool of candidate controllers (typically the largest-k placement from
the offline NSGA-II/ILP phase), this module puts controllers to sleep when
traffic is low and wakes them back up as traffic rises, always keeping every
switch's assignment within the hard delay bound and each controller within
its capacity. Every switch reassignment triggered by a sleep/wake event is
counted as a migration.

Design lineage:
  - The capacity-aware switch-reassignment logic follows Killi & Rao (2017),
    "Capacitated Next Controller Placement in Software Defined Networks,"
    IEEE TNSM 14(3), which shows worst-case latency spikes sharply after a
    controller is deactivated unless spare capacity was planned for in
    advance -- their analysis was of failure-triggered reassignment; this
    module applies the same capacity discipline to a *deliberate*,
    traffic-driven energy-saving reassignment instead.
  - The EMA-smoothed, multi-threshold sleep/wake policy (see RuntimeConfig's
    load_ema_alpha and min_dwell_steps) is adapted from Kazemiesfeh, Imanpour
    & Montazerolghaem (2025), "Enhanced load balancing technique for SDN
    controllers: A multi-threshold approach with migration of switches,"
    Computer Communications 238 -- their multi-level threshold classification
    of controller state (vs. a single load threshold) is repurposed here
    toward energy saving rather than load balancing.
  - The M/N controller-sleeping concept (some redundant controllers powered
    down under light load, delay/loss bounded) follows the queueing-theoretic
    treatment in the 2016 EURASIP JWCN paper "Sleeping mode of multi-controller
    in green software-defined networking."
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import networkx as nx
import numpy as np

from .config import DelayConfig, PowerModel, RuntimeConfig
from .delay import DelayEngine, coverage_priority
from .placement import assign_nearest
from .power import control_plane_energy_w


def generate_diurnal_trace(timesteps: int = 48, seed: int = 0, noise: float = 0.08) -> np.ndarray:
    """Synthetic diurnal traffic-load trace in [0, 1] (e.g., 48 half-hour steps = 1 day).

    Low load at 'night' (start/end of trace), peak at 'midday' (mid-trace).
    """
    rng = np.random.default_rng(seed)
    t = np.linspace(0, 2 * np.pi, timesteps, endpoint=False)
    base = 0.5 + 0.42 * np.sin(t - np.pi / 2)  # trough near t=0, peak near mid-trace
    trace = base + rng.normal(0, noise, size=timesteps)
    return np.clip(trace, 0.05, 1.0)


def assign_with_capacity(
    graph: nx.Graph,
    delay_engine: DelayEngine,
    active_controllers: set,
    capacity: int,
    delay_bound: float,
) -> dict | None:
    """Greedy capacity-aware assignment. Returns None if infeasible (some switch
    has no active controller within both the delay bound and remaining capacity).
    """
    if not active_controllers:
        return None

    pairs = []
    for node in graph.nodes:
        for c in active_controllers:
            d = delay_engine.delay(node, c)
            if d <= delay_bound:
                pairs.append((d, node, c))
    pairs.sort(key=lambda x: x[0])

    remaining = {c: capacity for c in active_controllers}
    assignment: dict = {}
    for _d, node, c in pairs:
        if node in assignment:
            continue
        if remaining[c] > 0:
            assignment[node] = c
            remaining[c] -= 1

    if len(assignment) != len(graph.nodes):
        return None  # some switch couldn't be placed within bound + capacity
    return assignment


@dataclass
class RuntimeStepResult:
    t: int
    load_factor: float
    active_controllers: int
    energy_w: float
    worst_case_delay_ms: float
    migrations: int
    feasible: bool
    changed: bool = False  # True if active_controllers differs from the previous step


class RuntimeManager:
    """Traffic-driven controller sleep/wake manager with delay-bounded switch migration."""

    def __init__(
        self,
        graph: nx.Graph,
        candidate_controllers: set,
        power_model: PowerModel = PowerModel(),
        delay_config: DelayConfig = DelayConfig(),
        runtime_config: RuntimeConfig = RuntimeConfig(),
        delay_engine: DelayEngine | None = None,
    ):
        self.graph = graph
        self.delay_engine = delay_engine or DelayEngine(graph)
        self.power_model = power_model
        self.delay_config = delay_config
        self.cfg = runtime_config
        self.candidates = set(candidate_controllers)

        self.priority = coverage_priority(
            graph, self.candidates, self.delay_engine, delay_config.max_switch_to_controller_delay_ms
        )
        if not self.priority:
            raise ValueError("candidate_controllers must be non-empty")

        n = len(graph.nodes)
        if runtime_config.controller_capacity * len(self.candidates) < n:
            raise ValueError(
                "Candidate pool cannot cover all switches even fully awake "
                f"(capacity={runtime_config.controller_capacity} x candidates={len(self.candidates)} "
                f"< n_switches={n}). Increase capacity or the candidate pool."
            )

        # Start fully awake; the trace will drive it down as load allows.
        self.active: set = set(self.priority)
        self.prev_assignment: dict = {}
        self.migration_log: list = []
        self._smoothed_load: float | None = None
        self._last_sleep_step: int = -10_000  # far in the past so the first sleep isn't blocked

    def _effective_capacity(self, load_factor: float) -> int:
        """A controller's usable switch-capacity for this step.

        Every switch always needs *some* active controller — traffic intensity
        doesn't shrink the switch count. What changes with load is how much
        per-switch processing budget each controller has spare: at low traffic
        a controller can comfortably serve more switches than its rated
        capacity at peak load, at high traffic it's limited to (up to) its
        rated capacity. `load_factor=1.0` recovers the configured capacity
        exactly (the binding worst case validated in __init__).
        """
        floor = 0.2  # never let effective capacity explode unrealistically at near-zero load
        return max(1, int(self.cfg.controller_capacity / max(load_factor, floor)))

    def _target_active_count(self, load_factor: float) -> int:
        n = len(self.graph.nodes)
        eff_cap = self._effective_capacity(load_factor)
        needed = math.ceil(n / eff_cap)
        return max(1, min(needed, len(self.candidates)))

    def step(self, t: int, load_factor: float) -> RuntimeStepResult:
        # Smooth the traffic signal (EMA) before it drives any sleep/wake
        # decision — reacting to raw per-timestep noise is what causes rapid
        # controller flapping (see README "known gaps" in the MVP writeup).
        if self._smoothed_load is None:
            self._smoothed_load = load_factor
        else:
            a = self.cfg.load_ema_alpha
            self._smoothed_load = a * load_factor + (1 - a) * self._smoothed_load

        target = self._target_active_count(self._smoothed_load)
        eff_cap = self._effective_capacity(self._smoothed_load)
        bound = self.delay_config.max_switch_to_controller_delay_ms

        # Waking is always immediate and never gated — safety (the delay bound)
        # must never wait on a cooldown timer.
        for c in self.priority:
            if len(self.active) >= target:
                break
            self.active.add(c)

        # Sleeping is gated by a minimum dwell time since the last sleep event,
        # so a single noisy dip doesn't trigger sleep-then-immediately-rewake
        # churn. Only sleeping is throttled; nothing here ever delays a wake.
        dwell_ok = (t - self._last_sleep_step) >= self.cfg.min_dwell_steps
        if dwell_ok:
            for c in reversed(self.priority):
                if len(self.active) <= target:
                    break
                if c not in self.active:
                    continue
                trial = self.active - {c}
                trial_assignment = assign_with_capacity(
                    self.graph, self.delay_engine, trial, eff_cap, bound
                )
                if trial_assignment is not None:
                    self.active = trial
                    self._last_sleep_step = t
                # else: keep c active — sleeping it would violate delay/capacity.

        assignment = assign_with_capacity(
            self.graph, self.delay_engine, self.active, eff_cap, bound
        )
        feasible = assignment is not None
        if not feasible:
            # First fallback: wake everything and retry at full rated capacity
            # (should be rare given the capacity check in __init__).
            self.active = set(self.candidates)
            assignment = assign_with_capacity(
                self.graph, self.delay_engine, self.active, self.cfg.controller_capacity, bound
            )
            feasible = assignment is not None
        if not feasible:
            # Final fallback: the greedy capacity-constrained matcher can fail
            # to find a feasible assignment even when one exists (it's a
            # simple heuristic, not an optimal bipartite matcher — see
            # README "known gaps"). The delay bound is this project's true
            # hard invariant, so fall back to uncapacitated nearest-controller
            # assignment (guaranteed feasible whenever the candidate pool's
            # *own* NSGA-II/ILP placement was feasible) rather than crash.
            assignment = assign_nearest(self.graph, self.active, self.delay_engine)
            worst_uncapacitated = self.delay_engine.worst_case_delay(assignment)
            feasible = worst_uncapacitated <= bound

        migrations = sum(
            1 for node, c in assignment.items() if self.prev_assignment.get(node) != c
        ) if self.prev_assignment else 0
        self.prev_assignment = assignment

        energy = control_plane_energy_w(self.active, assignment, self.delay_engine, self.power_model)
        worst = self.delay_engine.worst_case_delay(assignment)

        prev_count = self.migration_log[-1].active_controllers if self.migration_log else len(self.active)
        result = RuntimeStepResult(
            t=t,
            load_factor=load_factor,
            active_controllers=len(self.active),
            energy_w=energy,
            worst_case_delay_ms=worst,
            migrations=migrations,
            feasible=feasible,
            changed=len(self.active) != prev_count,
        )
        self.migration_log.append(result)
        return result

    def run(self, trace: np.ndarray) -> list:
        return [self.step(t, load) for t, load in enumerate(trace)]
