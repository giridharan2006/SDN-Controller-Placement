"""Benchmark harness: GreenPlace vs. re-implemented existing approaches.

Two complementary evaluations are run on every topology, with every algorithm
facing the identical problem (same graph, hard delay bound, power model):

STATIC placement quality (what most placement papers evaluate)
    Each algorithm returns a controller set minimising energy subject to the
    delay bound. We record energy, #controllers, worst-case delay, feasibility,
    algorithm run-time, and the gap to the exact MIP optimum.

LIFECYCLE over a 96-step diurnal traffic trace (what an operator actually pays)
    Each algorithm returns a *candidate pool* sized to serve peak load
    (>= ceil(n / capacity) controllers). The pool is then handed to the SAME
    runtime elastic manager for every method, so differences in lifecycle energy,
    switch migrations and delay violations are attributable to *placement
    quality*, not to who has a runtime phase. We also record each pool's
    "as-published" static-operation energy (always-on, no runtime phase), which is
    how the pure-placement literature would operate it.

Per-topology settings are derived, not hand-tuned:
    delay bound  D = bound_frac x (delay diameter of the topology)      [default 0.35]
    capacity     C = ceil(n / cap_div) switches per controller          [default 5]
    peak pool    K = ceil(n / C)                                         [= cap_div]
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, asdict
from pathlib import Path

import networkx as nx

from . import baselines as B
from .config import DelayConfig, PowerModel, RuntimeConfig
from .delay import DelayEngine
from .runtime import generate_diurnal_trace
from .lifecycle import simulate
from .selection import select_by_simulation, select_migration_aware, select_min_energy
from .topology import load_zoo_topology

STATIC_METHODS = [
    "random", "k_center", "k_median", "greedy_cover", "betweenness",
    "greco", "ga_energy", "exact_mip", "nsga2_2obj", "greenplace",
]
CONTROL_METHODS = ["nsga2_2obj_migsel"]
SIL_METHODS = ["greenplace_sil", "nsga2_2obj_sil"]


@dataclass
class BenchConfig:
    bound_frac: float = 0.35
    cap_div: int = 5
    trace_len: int = 96
    seeds: int = 3
    nsga_pop: int = 40
    nsga_gens: int = 60
    energy_slack: float = 1.15
    mip_time_limit_s: float = 30.0
    extra_pool: int = 4
    include_hysteresis_ablation: bool = True
    methods: tuple = tuple(STATIC_METHODS)
    # --- simulation-in-the-loop (SIL) selection; values FIXED BEFORE the experiment was run ---
    sil_train_seeds: tuple = (100, 101)   # disjoint from evaluation trace seeds 0..seeds-1 (held-out)
    sil_window: float = 1.25              # candidates: feasible Pareto members within 1.25x min static energy
    sil_max_candidates: int = 10
    sil_energy_slack: float = 0.02        # accept <=2% more simulated lifecycle energy than the best candidate
    sil_extra_slacks: tuple = (0.0, 0.05) # EXPLORATORY post-hoc sensitivity only (reported separately)


def derive_settings(graph: nx.Graph, cfg: BenchConfig) -> dict:
    engine = DelayEngine(graph)
    diameter = max(d for src in engine._dist.values() for d in src.values())
    n = graph.number_of_nodes()
    capacity = max(2, math.ceil(n / cfg.cap_div))
    return {
        "engine": engine,
        "diameter_ms": diameter,
        "bound_ms": cfg.bound_frac * diameter,
        "capacity": capacity,
        "k_floor": math.ceil(n / capacity),
    }




def build_set(method: str, p: B.Problem, k_floor: int, cfg: BenchConfig, seed: int, mode: str,
              cover_size: int, capacity: int | None = None) -> tuple[set, dict]:
    """Return (controller_set, info). mode='static' -> unconstrained size; 'pool' -> >= k_floor."""
    n = len(p.nodes)
    k_min = 1 if mode == "static" else k_floor
    k_max = min(n, max(k_min, cover_size, k_floor) + cfg.extra_pool)
    info: dict = {}

    if method == "random":
        k = B.min_feasible_size(p, lambda k: B.random_feasible(p, k, seed, tries=200), k_start=k_min)
        return B.random_feasible(p, k, seed, tries=200), info
    if method in ("k_center", "k_median", "betweenness"):
        fn = {"k_center": B.k_center, "k_median": B.k_median, "betweenness": B.betweenness}[method]
        k = B.min_feasible_size(p, lambda k: fn(p, k), k_start=k_min)
        return fn(p, k), info
    if method == "greedy_cover":
        return B.greedy_cover(p, k_target=k_min), info
    if method == "greco":
        return B.greco_style(p, min_size=k_min), info
    if method == "ga_energy":
        return B.ga_energy(p, k_min, k_max, seed, cfg.nsga_pop, cfg.nsga_gens), info
    if method == "exact_mip":
        s, info = B.exact_mip(p, k_min, k_max, cfg.mip_time_limit_s)
        return s, info
    if method in ("nsga2_2obj", "greenplace", "nsga2_2obj_migsel"):
        aware = method == "greenplace"          # only GreenPlace optimises migration burden in the search
        front = B.nsga2_front(p, k_min, k_max, seed, aware, cfg.nsga_pop, cfg.nsga_gens)
        # The control uses the plain 2-objective search but GreenPlace's migration-aware *pick*,
        # isolating "does the 3rd objective in the search matter?" from "does the pick rule matter?".
        pick = select_min_energy(front) if method == "nsga2_2obj" else select_migration_aware(front, cfg.energy_slack)
        info["front_size"] = len(front)
        if pick is None:  # no feasible member found: fall back to the bound-driven cover
            info["fallback"] = "greedy_cover"
            return B.greedy_cover(p, k_target=k_min), info
        return set(pick.controllers), info
    if method in ("greenplace_sil", "nsga2_2obj_sil"):
        assert capacity is not None, "SIL selection needs the controller capacity"
        assert not set(cfg.sil_train_seeds) & set(range(cfg.seeds)), "training seeds must be disjoint from evaluation seeds"
        aware = method == "greenplace_sil"       # same 3-obj search as GreenPlace; the control uses the 2-obj search
        front = B.nsga2_front(p, k_min, k_max, seed, aware, cfg.nsga_pop, cfg.nsga_gens)
        train = [generate_diurnal_trace(timesteps=cfg.trace_len, seed=sd) for sd in cfg.sil_train_seeds]
        pick, sil_info = select_by_simulation(p, front, capacity, train, cfg.sil_energy_slack, cfg.sil_window,
                                              cfg.sil_max_candidates,
                                              slacks=cfg.sil_extra_slacks if aware else None)
        info.update(front_size=len(front), sil_candidates=sil_info.get("n_candidates", 0))
        if pick is None:
            info["fallback"] = "greedy_cover"
            return B.greedy_cover(p, k_target=k_min), info
        info["alt_picks"] = {sl: set(m.controllers) for sl, m in sil_info["by_slack"].items()}
        return set(pick.controllers), info
    raise ValueError(method)




def run_topology(path: str | Path, cfg: BenchConfig, progress=None) -> list[dict]:
    g, meta = load_zoo_topology(path)
    st = derive_settings(g, cfg)
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(st["bound_ms"]))
    K, C = st["k_floor"], st["capacity"]
    cover_size = len(B.greedy_cover(p, 1))
    base = {**meta, "bound_ms": round(st["bound_ms"], 3), "diameter_ms": round(st["diameter_ms"], 3),
            "capacity": C, "k_floor": K, "cover_size": cover_size}

    rows: list[dict] = []
    deterministic = {"k_center", "k_median", "greedy_cover", "betweenness", "greco", "exact_mip"}
    cache: dict = {}
    for method in cfg.methods:
        for seed in range(cfg.seeds):
            if method in deterministic and (method, "det") in cache:
                s_static, i_static, t_static, s_pool, i_pool, t_pool = cache[(method, "det")]
            else:
                t0 = time.perf_counter()
                if method in SIL_METHODS:      # SIL only concerns the lifecycle pool; static columns are not meaningful
                    s_static, i_static = set(), {}
                else:
                    s_static, i_static = build_set(method, p, K, cfg, seed, "static", cover_size, C)
                t_static = time.perf_counter() - t0
                t0 = time.perf_counter()
                s_pool, i_pool = build_set(method, p, K, cfg, seed, "pool", cover_size, C)
                t_pool = time.perf_counter() - t0
                if method in deterministic:
                    cache[(method, "det")] = (s_static, i_static, t_static, s_pool, i_pool, t_pool)

            pl_static = p.evaluate(s_static if s_static else s_pool)
            pl_pool = p.evaluate(s_pool)
            trace = generate_diurnal_trace(timesteps=cfg.trace_len, seed=seed)
            life = simulate(p, s_pool, C, trace)
            row = {
                **base, "method": method, "seed": seed,
                "static_k": len(s_static), "static_energy_w": pl_static.energy_w,
                "static_worst_delay_ms": pl_static.worst_case_delay_ms, "static_feasible": pl_static.feasible,
                "static_runtime_s": t_static,
                "pool_k": len(s_pool), "pool_static_energy_w": pl_pool.energy_w,
                "pool_feasible": pl_pool.feasible, "pool_migration_burden": pl_pool.migration_burden,
                "pool_runtime_s": t_pool, "mip_status": i_static.get("status", ""),
                "static_valid": method not in SIL_METHODS,
                **life,
            }
            rows.append(row)
            for sl, alt in (i_pool.get("alt_picks") or {}).items():   # exploratory slack sensitivity (post-hoc)
                if alt == s_pool:
                    rows.append({**row, "method": f"greenplace_sil_slack{int(round(sl * 100))}"})
                    continue
                alt_pl = p.evaluate(alt)
                rows.append({**row, "method": f"greenplace_sil_slack{int(round(sl * 100))}", "pool_k": len(alt),
                             "pool_static_energy_w": alt_pl.energy_w, "pool_migration_burden": alt_pl.migration_burden,
                             **simulate(p, alt, C, trace)})
            if method == "greenplace" and cfg.include_hysteresis_ablation:
                naive = simulate(p, s_pool, C, trace, ema=1.0, dwell=0)
                rows.append({**row, "method": "greenplace_no_hysteresis", **naive})
        if progress:
            progress(f"    {meta['name']}: {method} done")
    return rows
