"""Traffic-load traces for the runtime manager: synthetic scenario families and REAL traces.

Every trace is an array of load factors in [0.05, 1.0] (96 steps by default).

Synthetic families (used to test robustness to a traffic pattern different from the one used for
selection/training, i.e. distribution shift):
    diurnal      smooth single-peak day with Gaussian noise (the training/default pattern)
    two_peak     morning and evening peaks with a midday dip (office/residential mix)
    flash_crowd  diurnal base plus 1-3 short, sharp surges
    bursty       two-state (calm/burst) Markov-modulated load
    trend        slowly growing load with a weak daily swing
    noisy        diurnal shape with 3x the noise
Real traces (see data/traffic/README.md): complete 24 h days of GEANT (2005) and Abilene (2004) total traffic.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np

from .runtime import generate_diurnal_trace

DATA = Path(__file__).resolve().parents[1] / "data" / "traffic" / "real_traces_15min.csv"
SYNTHETIC = ("diurnal", "two_peak", "flash_crowd", "bursty", "trend", "noisy")
REAL = ("geant", "abilene")


def synthetic_trace(kind: str, steps: int = 96, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(10_000 + seed)
    t = np.linspace(0, 2 * np.pi, steps, endpoint=False)
    if kind == "diurnal":
        return generate_diurnal_trace(timesteps=steps, seed=seed)
    if kind == "noisy":
        return generate_diurnal_trace(timesteps=steps, seed=seed, noise=0.24)
    if kind == "two_peak":
        x = 0.5 + 0.32 * np.sin(2 * t - np.pi / 3) + 0.08 * np.sin(t)
        return np.clip(x + rng.normal(0, 0.06, steps), 0.05, 1.0)
    if kind == "flash_crowd":
        x = 0.5 + 0.3 * np.sin(t - np.pi / 2)
        for _ in range(int(rng.integers(1, 4))):
            c, w = int(rng.integers(5, steps - 5)), int(rng.integers(2, 5))
            x[max(0, c - w): c + w] += rng.uniform(0.3, 0.5)
        return np.clip(x + rng.normal(0, 0.05, steps), 0.05, 1.0)
    if kind == "bursty":
        state, out = 0, []
        for _ in range(steps):
            if state == 0 and rng.random() < 0.08:
                state = 1
            elif state == 1 and rng.random() < 0.25:
                state = 0
            out.append((0.75 if state else 0.35) + rng.normal(0, 0.05))
        return np.clip(np.array(out), 0.05, 1.0)
    if kind == "trend":
        x = np.linspace(0.3, 0.85, steps) + 0.1 * np.sin(t)
        return np.clip(x + rng.normal(0, 0.05, steps), 0.05, 1.0)
    raise ValueError(kind)


@lru_cache(maxsize=1)
def _real_table():
    import csv
    series: dict = {}
    with open(DATA, newline="") as fh:
        for r in csv.DictReader(fh):
            series.setdefault((r["dataset"], r["date"]), {})[int(r["step"])] = float(r["total_mbps"])
    out: dict = {}
    for (ds, date), v in sorted(series.items()):
        out.setdefault(ds, []).append((date, np.array([v[i] for i in range(96)])))
    p99 = {ds: float(np.percentile(np.concatenate([a for _, a in days]), 99)) for ds, days in out.items()}
    return out, p99


def real_trace(dataset: str, idx: int = 0) -> np.ndarray:
    """The idx-th complete 24 h day (wrapping), as a load factor in [0.05, 1]."""
    days, p99 = _real_table()
    date, arr = days[dataset][idx % len(days[dataset])]
    return np.clip(arr / p99[dataset], 0.05, 1.0)


def n_real_days(dataset: str) -> int:
    return len(_real_table()[0][dataset])


def get_trace(kind: str, seed: int = 0, steps: int = 96) -> np.ndarray:
    if kind in REAL:
        # spread the requested days over the dataset deterministically
        n = n_real_days(kind)
        return real_trace(kind, (seed * 7 + 3) % n)
    return synthetic_trace(kind, steps, seed)
