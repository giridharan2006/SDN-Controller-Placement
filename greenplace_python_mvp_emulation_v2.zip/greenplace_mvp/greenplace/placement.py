"""Placement data structure: a candidate controller set + switch assignment,
with feasibility checking and energy evaluation.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import networkx as nx

from .config import DelayConfig, PowerModel
from .delay import DelayEngine
from .power import control_plane_energy_w, energy_breakdown


@dataclass
class Placement:
    controllers: set
    assignment: dict = field(default_factory=dict)
    energy_w: float = 0.0
    worst_case_delay_ms: float = 0.0
    feasible: bool = False
    violation_ms: float = 0.0  # total delay-bound exceedance, 0 if feasible
    migration_burden: float = 0.0  # worst-case switches lost if the busiest controller sleeps

    def summary(self) -> dict:
        return {
            "num_controllers": len(self.controllers),
            "controllers": sorted(self.controllers, key=str),
            "energy_w": round(self.energy_w, 2),
            "worst_case_delay_ms": round(self.worst_case_delay_ms, 3),
            "migration_burden": round(self.migration_burden, 2),
            "feasible": self.feasible,
            "violation_ms": round(self.violation_ms, 3),
        }


def assign_nearest(graph: nx.Graph, controllers: set, delay_engine: DelayEngine) -> dict:
    """Assign every node in the graph to its nearest active controller."""
    assignment = {}
    for node in graph.nodes:
        if not controllers:
            continue
        c, _ = delay_engine.nearest(node, controllers)
        assignment[node] = c
    return assignment


def worst_case_migration_burden(
    assignment: dict,
    graph: nx.Graph = None,
    controllers: set = None,
    delay_engine: DelayEngine = None,
    delay_bound: float = None,
) -> float:
    """Expected switch-migration cost if this placement's runtime manager
    consolidated (put to sleep) the controller it would actually target first.

    This is the project's sharpened novelty contribution: rather than
    treating offline placement and runtime switch migration as two
    disconnected phases (as in the closest prior art — e.g. the Adekoya
    thesis's NSGA-III + separate migration algorithm, or Kondo et al.'s
    placement-only BIP), the *expected cost of a future migration* is folded
    in as a placement objective itself, using the SAME coverage-priority
    policy the runtime manager (runtime.py) actually uses to decide which
    controller to sleep first — not a generic proxy like "biggest cluster"
    that may have no relationship to what the runtime policy would do.

    Falls back to a policy-agnostic worst-case (max cluster size across all
    controllers) when graph/delay_engine/bound aren't supplied, e.g. for
    quick unit tests that don't need the full runtime-policy link.
    """
    if not assignment:
        return 0.0
    counts: dict = {}
    for _switch, controller in assignment.items():
        counts[controller] = counts.get(controller, 0) + 1

    if graph is not None and controllers and delay_engine is not None and delay_bound is not None:
        from .delay import coverage_priority
        priority = coverage_priority(graph, controllers, delay_engine, delay_bound)
        if priority:
            first_to_sleep = priority[-1]  # runtime.py sleeps lowest-priority controllers first
            return float(counts.get(first_to_sleep, 0))

    return float(max(counts.values()))


def evaluate_placement(
    graph: nx.Graph,
    controllers: set,
    delay_engine: DelayEngine,
    power_model: PowerModel,
    delay_config: DelayConfig,
) -> Placement:
    """Build a full Placement (assignment + energy + feasibility) from a controller set."""
    if not controllers:
        return Placement(controllers=set(), assignment={}, energy_w=float("inf"),
                          worst_case_delay_ms=float("inf"), feasible=False,
                          violation_ms=float("inf"))

    assignment = assign_nearest(graph, controllers, delay_engine)
    worst = delay_engine.worst_case_delay(assignment)
    bound = delay_config.max_switch_to_controller_delay_ms
    violation = max(0.0, worst - bound)
    energy = control_plane_energy_w(controllers, assignment, delay_engine, power_model)
    burden = worst_case_migration_burden(
        assignment, graph=graph, controllers=controllers, delay_engine=delay_engine, delay_bound=bound
    )

    return Placement(
        controllers=set(controllers),
        assignment=assignment,
        energy_w=energy,
        worst_case_delay_ms=worst,
        feasible=violation == 0.0,
        violation_ms=violation,
        migration_burden=burden,
    )


def placement_energy_breakdown(placement: Placement, delay_engine: DelayEngine, power_model: PowerModel) -> dict:
    return energy_breakdown(placement.controllers, placement.assignment, delay_engine, power_model)
