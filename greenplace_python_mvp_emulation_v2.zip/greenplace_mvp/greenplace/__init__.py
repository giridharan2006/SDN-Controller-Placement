"""
GreenPlace: Energy-Efficient SDN Controller Placement Under Delay Constraints.

MVP implementation (pure Python). Modules:
    topology   - load / generate network graphs (nodes = switches, edges = links with delay)
    delay      - shortest-path delay engine
    power      - control-plane energy model
    placement  - Placement data structure + feasibility/energy evaluation
    ilp_solver - exact solver (PuLP if available, exhaustive-search fallback otherwise)
    nsga2      - self-contained multi-objective genetic algorithm (energy, delay)
    optimizer  - unified entry point selecting a solving strategy
    runtime    - traffic-driven controller/link sleep-wake manager + switch migration
    metrics    - Pareto-front analysis, CSV/JSON export, plotting helpers
    config     - configuration dataclasses
"""

__version__ = "0.1.0"
