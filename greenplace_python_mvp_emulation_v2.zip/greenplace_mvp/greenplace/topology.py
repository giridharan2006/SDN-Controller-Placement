"""Topology loading and synthetic topology generation.

Real backbone topologies (Internet2 OS3E, GEANT, other Internet Topology Zoo
networks) can be downloaded as GML from https://topology-zoo.org/dataset.html
and loaded directly with `load_topology_gml`. Edge "delay" attributes (ms) are
derived from the `LinkLabel`/geographic distance if present, or must be added
manually — see `annotate_missing_delays`.
"""
from __future__ import annotations

import math
import random
from pathlib import Path

import networkx as nx

DEFAULT_PROPAGATION_SPEED_KM_PER_MS = 200.0  # ~2/3 speed of light in fiber


def load_topology_gml(path: str | Path) -> nx.Graph:
    """Load a topology from a GML file (e.g., Internet Topology Zoo format)."""
    g = nx.read_gml(path, label="id")
    g = nx.Graph(g)  # drop multigraph/directedness if present
    annotate_missing_delays(g)
    return g


def annotate_missing_delays(g: nx.Graph) -> None:
    """Ensure every edge has a 'delay' (ms) attribute.

    If nodes carry 'Latitude'/'Longitude' (Topology Zoo convention), delay is
    derived from great-circle distance. Otherwise a small default is assigned.
    """
    for u, v, data in g.edges(data=True):
        if "delay" in data:
            continue
        lat_u, lon_u = g.nodes[u].get("Latitude"), g.nodes[u].get("Longitude")
        lat_v, lon_v = g.nodes[v].get("Latitude"), g.nodes[v].get("Longitude")
        if None not in (lat_u, lon_u, lat_v, lon_v):
            dist_km = _haversine_km(lat_u, lon_u, lat_v, lon_v)
            data["delay"] = max(0.1, dist_km / DEFAULT_PROPAGATION_SPEED_KM_PER_MS)
        else:
            data["delay"] = 1.0


def _haversine_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def generate_synthetic_topology(
    n_nodes: int,
    seed: int = 0,
    extra_edge_prob: float = 0.15,
    min_delay_ms: float = 1.0,
    max_delay_ms: float = 8.0,
) -> nx.Graph:
    """Generate a connected synthetic topology for testing/demo purposes.

    Builds a spanning ring (guaranteed connectivity) then adds random extra
    edges for realism, with random per-edge delays in [min_delay_ms, max_delay_ms].
    """
    rng = random.Random(seed)
    g = nx.Graph()
    g.add_nodes_from(range(n_nodes))

    # Ring backbone guarantees connectivity.
    for i in range(n_nodes):
        j = (i + 1) % n_nodes
        g.add_edge(i, j, delay=round(rng.uniform(min_delay_ms, max_delay_ms), 2))

    # Sprinkle in extra chords for a more realistic mesh.
    for i in range(n_nodes):
        for j in range(i + 2, n_nodes):
            if (i, j) == (0, n_nodes - 1):
                continue
            if rng.random() < extra_edge_prob:
                g.add_edge(i, j, delay=round(rng.uniform(min_delay_ms, max_delay_ms), 2))

    return g


def generate_backbone_like_topology(
    n_nodes: int,
    seed: int = 0,
    area_km: float = 3000.0,
    avg_degree: float = 2.6,
) -> nx.Graph:
    """A geographic-proxy synthetic topology sized/shaped closer to real WAN
    backbones (Internet2 OS3E ~34 nodes, GEANT ~40 nodes) than the plain
    ring-plus-chords generator above.

    Nodes are scattered uniformly over a square area of side `area_km`
    (a stand-in for a continental backbone footprint); edges are built from
    a minimum spanning tree (guaranteeing connectivity, mimicking a
    backbone's sparse "no wasted long-haul links" structure) plus a small
    number of nearest-neighbor edges added on top for realistic path
    diversity (real backbones average roughly 2.2-3x edges per node, not the
    dense mesh a random graph would give at these sizes). Delay is derived
    from Euclidean distance via a fiber-propagation-speed constant, the same
    conversion used for real Topology Zoo GML in `annotate_missing_delays`.

    This remains a stand-in, not real data — swap in actual Internet2 OS3E /
    GEANT GML via `load_topology_gml` once available; see the module
    docstring for the download source.
    """
    rng = random.Random(seed)
    g = nx.Graph()
    positions = {i: (rng.uniform(0, area_km), rng.uniform(0, area_km)) for i in range(n_nodes)}
    g.add_nodes_from(positions.keys())
    for i, (x, y) in positions.items():
        g.nodes[i]["x_km"] = x
        g.nodes[i]["y_km"] = y

    def dist(i, j):
        xi, yi = positions[i]
        xj, yj = positions[j]
        return math.hypot(xi - xj, yi - yj)

    # Minimum spanning tree over full pairwise distances -> guaranteed
    # connectivity with a sparse, "no wasted long-haul fiber" backbone shape.
    complete = nx.Graph()
    complete.add_nodes_from(positions.keys())
    for i in range(n_nodes):
        for j in range(i + 1, n_nodes):
            complete.add_edge(i, j, weight=dist(i, j))
    mst = nx.minimum_spanning_tree(complete, weight="weight")
    g.add_edges_from(mst.edges())

    # Add nearest-neighbor edges on top until the average degree target is
    # roughly met, for realistic (but still sparse) path diversity.
    target_edges = int(avg_degree * n_nodes / 2)
    candidates = sorted(
        ((dist(i, j), i, j) for i in range(n_nodes) for j in range(i + 1, n_nodes)),
        key=lambda x: x[0],
    )
    for _d, i, j in candidates:
        if g.number_of_edges() >= target_edges:
            break
        if not g.has_edge(i, j):
            g.add_edge(i, j)

    for u, v in g.edges():
        km = dist(u, v)
        g[u][v]["delay"] = round(max(0.1, km / DEFAULT_PROPAGATION_SPEED_KM_PER_MS), 3)

    return g


def save_topology_gml(g: nx.Graph, path: str | Path) -> None:
    nx.write_gml(g, path)


def load_topology_json(path: str | Path) -> nx.Graph:
    """Load a hand-authored small fixture topology from a simple JSON edge list.

    Format: {"nodes": [0,1,2,3], "edges": [[0,1,2.0], [1,2,3.5], ...]}
    where each edge triple is [u, v, delay_ms].
    """
    import json

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    g = nx.Graph()
    g.add_nodes_from(data["nodes"])
    for u, v, delay in data["edges"]:
        g.add_edge(u, v, delay=float(delay))
    return g


def load_zoo_topology(path: str | Path, min_geo_fraction: float = 0.8):
    """Load an Internet Topology Zoo GML file robustly -> (graph, meta).

    Real Zoo files have quirks the plain loader does not handle: parallel links
    (networkx refuses them unless the file declares a multigraph), self-loops,
    'Hyperedge' pseudo-nodes / nodes with no coordinates, and occasionally
    disconnected components. This loader
      * collapses parallel links and drops self-loops,
      * if >= `min_geo_fraction` of nodes have Latitude/Longitude: drops the
        coordinate-less nodes and derives link delay from great-circle distance
        at ~2/3 c in fibre (median known delay for any link still lacking one);
      * otherwise uses a uniform 1 ms/link (hop-count) delay model for the whole
        graph rather than mixing geographic and made-up delays;
      * keeps the largest connected component and relabels nodes 0..n-1
        (original label kept as attribute 'name').
    """
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    if "multigraph" not in text:
        text = text.replace("graph [", "graph [\n  multigraph 1", 1)
    raw = nx.parse_gml(text, label="id")
    has_geo = {n: ("Latitude" in d and "Longitude" in d) for n, d in raw.nodes(data=True)}
    geo_frac = sum(has_geo.values()) / max(1, len(has_geo))
    geographic = geo_frac >= min_geo_fraction

    g = nx.Graph()
    keep = [n for n in raw.nodes if has_geo[n]] if geographic else list(raw.nodes)
    for n in keep:
        d = raw.nodes[n]
        g.add_node(n, name=str(d.get("label", n)), Latitude=d.get("Latitude"), Longitude=d.get("Longitude"))
    for u, v in raw.edges():
        if u != v and u in g and v in g:
            g.add_edge(u, v)
    if g.number_of_nodes() == 0:
        raise ValueError("no usable nodes")
    lcc = max(nx.connected_components(g), key=len)
    g = g.subgraph(lcc).copy()

    known = []
    if geographic:
        for u, v in g.edges():
            a, b = g.nodes[u], g.nodes[v]
            if None not in (a.get("Latitude"), a.get("Longitude"), b.get("Latitude"), b.get("Longitude")):
                dist = _haversine_km(a["Latitude"], a["Longitude"], b["Latitude"], b["Longitude"])
                g[u][v]["delay"] = max(0.1, dist / DEFAULT_PROPAGATION_SPEED_KM_PER_MS)
                known.append(g[u][v]["delay"])
    fallback = sorted(known)[len(known) // 2] if known else 1.0
    for u, v, d in g.edges(data=True):
        d.setdefault("delay", fallback)

    g = nx.convert_node_labels_to_integers(g, label_attribute="orig_id")
    meta = {
        "name": Path(path).stem,
        "n": g.number_of_nodes(),
        "m": g.number_of_edges(),
        "geo_fraction": round(geo_frac, 3),
        "delay_model": "geographic" if geographic else "hop-count (1 ms/link)",
    }
    return g, meta
