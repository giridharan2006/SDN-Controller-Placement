"""Shortest-path delay engine.

Wraps networkx shortest-path computation with caching so repeated placement
evaluations (inside the ILP search and the NSGA-II fitness function) don't
recompute all-pairs shortest paths from scratch every time.
"""
from __future__ import annotations

from functools import lru_cache

import networkx as nx


class DelayEngine:
    """Precomputes and serves shortest-path propagation delay between any two nodes."""

    def __init__(self, graph: nx.Graph):
        self.graph = graph
        # All-pairs shortest path delay, computed once per graph instance.
        self._dist = dict(nx.all_pairs_dijkstra_path_length(graph, weight="delay"))
        # Lazily-filled per-source hop counts along the min-delay path. Identical
        # values to calling nx.dijkstra_path per pair, but computed once per
        # source instead of once per (switch, controller) per evaluation.
        self._hops: dict = {}

    def delay(self, u, v) -> float:
        """Shortest-path propagation delay (ms) between nodes u and v."""
        if u == v:
            return 0.0
        return self._dist[u][v]

    def nearest(self, node, candidates) -> tuple:
        """Return (closest_candidate, delay_ms) among `candidates` to `node`."""
        best_c, best_d = None, float("inf")
        for c in candidates:
            d = self.delay(node, c)
            if d < best_d:
                best_c, best_d = c, d
        return best_c, best_d

    def worst_case_delay(self, assignment: dict) -> float:
        """Given {switch: controller}, return the maximum switch-to-controller delay."""
        if not assignment:
            return float("inf")
        return max(self.delay(sw, ctrl) for sw, ctrl in assignment.items())

    def average_delay(self, assignment: dict) -> float:
        if not assignment:
            return float("inf")
        return sum(self.delay(sw, ctrl) for sw, ctrl in assignment.items()) / len(assignment)

    def hop_count(self, u, v) -> int:
        """Number of link hops on the shortest (by delay) path from u to v."""
        if u == v:
            return 0
        if u not in self._hops:
            _, paths = nx.single_source_dijkstra(self.graph, u, weight="delay")
            self._hops[u] = {t: len(p) - 1 for t, p in paths.items()}
        return self._hops[u][v]

    def inter_controller_delays(self, controllers) -> list:
        controllers = list(controllers)
        out = []
        for i in range(len(controllers)):
            for j in range(i + 1, len(controllers)):
                out.append(self.delay(controllers[i], controllers[j]))
        return out


def coverage_priority(graph: nx.Graph, candidates, delay_engine: "DelayEngine", bound: float) -> list:
    """Order candidate controllers by how many nodes they can serve within the
    delay bound (most useful first). Shared by the offline migration-burden
    objective (placement.py) and the runtime sleep/wake manager (runtime.py)
    so the offline objective actually predicts what the runtime policy does,
    rather than measuring something only loosely related to it.
    """
    scored = []
    for c in candidates:
        count = sum(1 for n in graph.nodes if delay_engine.delay(n, c) <= bound)
        scored.append((count, c))
    scored.sort(key=lambda x: (-x[0], str(x[1])))
    return [c for _, c in scored]
