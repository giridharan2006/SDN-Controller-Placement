"""NSGA-II whose 3rd objective is *simulated* migrations (simulation-in-the-search-loop).

The offline proxy `worst_case_migration_burden` is replaced by the number of switch migrations the runtime
manager actually performs when the candidate pool is run over a training trace. Because every fitness
evaluation costs a lifecycle simulation, results are cached per controller set and the method is only
practical on small/medium networks (see the scale study for run-times).
"""
from __future__ import annotations

from .config import NSGA2Config
from .lifecycle import simulate
from .nsga2 import run_nsga2


def run_sim_nsga2(p, capacity: int, train_traces, k_min: int, k_max: int, seed: int,
                  pop: int = 30, gens: int = 30):
    cache: dict = {}

    def burden(placement) -> float:
        key = frozenset(placement.controllers)
        if key not in cache:
            try:
                sims = [simulate(p, set(key), capacity, tr) for tr in train_traces]
                cache[key] = sum(s["migrations"] for s in sims) / len(sims)
            except ValueError:            # pool too small to cover all switches at the rated capacity
                cache[key] = 1e6
        return cache[key]

    cfg = NSGA2Config(population_size=pop, generations=gens, k_min=k_min, k_max=k_max,
                      random_seed=seed, optimize_migration=True)
    front = run_nsga2(p.graph, p.engine, p.power, p.delay_config, cfg, burden_fn=burden)
    return front, {"sim_evals": len(cache)}
