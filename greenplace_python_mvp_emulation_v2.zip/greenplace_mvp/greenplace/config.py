"""Configuration dataclasses shared across GreenPlace modules."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class PowerModel:
    """Control-plane power model (Watts), following the energy framing used in
    Kondo et al. (2023/2026) and GreCo (Ruiz-Rivera et al., 2015): total control-plane
    energy is dominated by (a) which controllers are switched on, and (b) how many
    control-link hops are used to reach them.
    """
    controller_active_w: float = 150.0   # power drawn by one active controller instance
    controller_idle_w: float = 0.0       # power drawn by a sleeping/inactive controller
    link_hop_w: float = 5.0              # power drawn per active control-link hop

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DelayConfig:
    """Hard delay-SLA configuration."""
    max_switch_to_controller_delay_ms: float = 15.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class NSGA2Config:
    """NSGA-II search hyperparameters."""
    population_size: int = 60
    generations: int = 80
    crossover_rate: float = 0.9
    mutation_rate: float = 0.05
    k_min: int = 1
    k_max: int = 6
    random_seed: int = 42
    optimize_migration: bool = True  # add worst-case migration burden as a 3rd objective

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RuntimeConfig:
    """Runtime elastic-management configuration."""
    controller_capacity: int = 12          # max switches one controller can serve
    low_load_threshold: float = 0.35       # below this, try to sleep a controller
    high_load_threshold: float = 0.75      # above this, wake a controller if needed
    timesteps: int = 48                    # e.g. 48 half-hour steps = 1 day
    load_ema_alpha: float = 0.3            # traffic smoothing: 1.0 = no smoothing, lower = smoother
    min_dwell_steps: int = 2               # minimum steps between consecutive SLEEP decisions (anti-flap)

    def to_dict(self) -> dict:
        return asdict(self)


def load_json_config(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json_config(data: dict, path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
