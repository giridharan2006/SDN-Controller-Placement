"""Pareto-front analysis, CSV/JSON export, and plotting helpers."""
from __future__ import annotations

import csv
import json
from pathlib import Path

from .placement import Placement


def hypervolume_2d(placements: list[Placement], ref_point: tuple[float, float]) -> float:
    """2-objective hypervolume (energy, delay), both minimized, relative to a
    reference (worst-case) point. Standard sweep algorithm for 2D.
    """
    feasible = [p for p in placements if p.feasible]
    if not feasible:
        return 0.0
    pts = sorted(((p.energy_w, p.worst_case_delay_ms) for p in feasible), key=lambda x: x[0])
    ref_e, ref_d = ref_point
    hv = 0.0
    prev_e = ref_e
    best_d_so_far = ref_d
    for e, d in pts:
        if e >= ref_e or d >= ref_d:
            continue
        best_d_so_far = min(best_d_so_far, d)
        hv += (prev_e - e) * (ref_d - best_d_so_far)
        prev_e = e
    return hv


def placements_to_records(placements: list[Placement]) -> list[dict]:
    return [p.summary() for p in placements]


def export_csv(records: list[dict], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not records:
        path.write_text("")
        return
    fieldnames = list(records[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in records:
            writer.writerow(r)


def export_json(records, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, default=str)


def plot_pareto_front(placements: list[Placement], title: str, out_path: str | Path,
                       highlight: Placement | None = None,
                       highlight_label: str = "Exact ILP (baseline, not GreenPlace)",
                       series_label: str = "GreenPlace (NSGA-II placement)",
                       color_by_migration: bool = False) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    feasible = [p for p in placements if p.feasible]
    fig, ax = plt.subplots(figsize=(6.5, 4.8))
    if feasible:
        xs = [p.energy_w for p in feasible]
        ys = [p.worst_case_delay_ms for p in feasible]
        if color_by_migration:
            burdens = [p.migration_burden for p in feasible]
            sc = ax.scatter(xs, ys, c=burdens, cmap="viridis_r", s=60,
                             label=series_label, zorder=3, edgecolors="white", linewidths=0.5)
            cbar = fig.colorbar(sc, ax=ax)
            cbar.set_label("Worst-case migration burden\n(switches lost if busiest controller sleeps)")
        else:
            ax.scatter(xs, ys, c="#0E7C7B", label=series_label, zorder=3)
    if highlight is not None and highlight.feasible:
        ax.scatter([highlight.energy_w], [highlight.worst_case_delay_ms],
                   c="#F96167", marker="*", s=220, label=highlight_label, zorder=4)
    ax.set_xlabel("Total control-plane energy (W)")
    ax.set_ylabel("Worst-case switch-to-controller delay (ms)")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_runtime_trace(results, out_path: str | Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = [r.t for r in results]
    load = [r.load_factor for r in results]
    active = [r.active_controllers for r in results]
    energy = [r.energy_w for r in results]

    fig, axes = plt.subplots(3, 1, figsize=(8, 7), sharex=True)
    axes[0].plot(t, load, color="#1E2761")
    axes[0].set_ylabel("Traffic load\n(0-1)")
    axes[0].grid(alpha=0.3)

    axes[1].step(t, active, where="post", color="#0E7C7B")
    axes[1].set_ylabel("Active\ncontrollers")
    axes[1].grid(alpha=0.3)

    axes[2].plot(t, energy, color="#F96167")
    axes[2].set_ylabel("Energy (W)")
    axes[2].set_xlabel("Timestep")
    axes[2].grid(alpha=0.3)

    fig.suptitle("GreenPlace Phase 2: runtime elastic controller management\nover a diurnal traffic trace")
    fig.tight_layout()
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


# ---------------------------------------------------------------------------
# 3-objective quality indicators (all objectives minimised; feasible placements only)
# ---------------------------------------------------------------------------
def _pts(placements):
    return [(p.energy_w, p.worst_case_delay_ms, p.migration_burden) for p in placements if p.feasible]


def hypervolume_3d(points, ref) -> float:
    """Exact 3-D hypervolume by slicing along the 3rd objective (O(n^2 log n); fronts here are small)."""
    pts = sorted([tuple(q) for q in points if all(q[i] < ref[i] for i in range(3))], key=lambda q: q[2])
    if not pts:
        return 0.0
    hv = 0.0
    for i, q in enumerate(pts):
        z_hi = pts[i + 1][2] if i + 1 < len(pts) else ref[2]
        depth = z_hi - q[2]
        if depth <= 0:
            continue
        slab = sorted(((a[0], a[1]) for a in pts[: i + 1]), key=lambda t: t[0])
        area, best_d = 0.0, ref[1]
        for j, (e, d) in enumerate(slab):
            best_d = min(best_d, d)
            e_next = slab[j + 1][0] if j + 1 < len(slab) else ref[0]
            area += (e_next - e) * (ref[1] - best_d)
        hv += area * depth
    return hv


def igd(front_pts, ref_front_pts, scale) -> float:
    """Inverted generational distance of a front to a reference front, in range-normalised space."""
    import numpy as np
    if not len(front_pts) or not len(ref_front_pts):
        return float("inf")
    A = np.array(front_pts, float) / scale
    R = np.array(ref_front_pts, float) / scale
    d = np.sqrt(((R[:, None, :] - A[None, :, :]) ** 2).sum(-1)).min(1)
    return float(d.mean())


def front_indicators(fronts: dict) -> dict:
    """fronts: {method: list[Placement]} for ONE instance. Returns {method: {hv, igd, n}} on a common
    normalisation: ideal/nadir from the union of all feasible points; reference point = nadir*1.1 (per-objective
    range-normalised, so hv is in [0, 1.1^3])."""
    import numpy as np
    allp = [q for pl in fronts.values() for q in _pts(pl)]
    if not allp:
        return {m: {"hv": 0.0, "igd": float("inf"), "n": 0} for m in fronts}
    A = np.array(allp)
    lo, hi = A.min(0), A.max(0)
    rng_ = np.where(hi - lo < 1e-9, 1.0, hi - lo)
    norm = lambda pts: [tuple((np.array(q) - lo) / rng_) for q in pts]
    # reference (pseudo-optimal) front: non-dominated subset of the union
    N = norm(allp)
    ref_front = [q for i, q in enumerate(N)
                 if not any(all(o[k] <= q[k] for k in range(3)) and any(o[k] < q[k] for k in range(3))
                            for j, o in enumerate(N) if j != i)]
    out = {}
    for m, pl in fronts.items():
        pts = norm(_pts(pl))
        out[m] = {"hv": hypervolume_3d(pts, (1.1, 1.1, 1.1)), "igd": igd(pts, ref_front, 1.0), "n": len(pts)}
    return out
