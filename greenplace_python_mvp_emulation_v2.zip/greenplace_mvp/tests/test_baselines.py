"""Tests for the baseline algorithms, selection rules, real-topology loader and hop cache."""
import networkx as nx
import pytest

from greenplace import baselines as B
from greenplace.config import DelayConfig, PowerModel
from greenplace.delay import DelayEngine
from greenplace.selection import select_migration_aware, select_min_energy
from greenplace.placement import Placement
from greenplace.topology import generate_backbone_like_topology, load_zoo_topology


@pytest.fixture(scope="module")
def prob():
    g = generate_backbone_like_topology(n_nodes=20, seed=3)
    eng = DelayEngine(g)
    diam = max(d for s in eng._dist.values() for d in s.values())
    return B.Problem(g, eng, PowerModel(), DelayConfig(0.4 * diam))


def test_hop_cache_matches_dijkstra_path(prob):
    g, eng = prob.graph, prob.engine
    for u in list(g.nodes)[:8]:
        for v in g.nodes:
            expected = 0 if u == v else len(nx.dijkstra_path(g, u, v, weight="delay")) - 1
            assert eng.hop_count(u, v) == expected


def test_greedy_cover_covers_everything_within_bound(prob):
    s = B.greedy_cover(prob)
    assert B.is_feasible(prob, s)


@pytest.mark.parametrize("name", ["k_center", "k_median", "betweenness"])
def test_fixed_k_methods_return_requested_size_and_valid_nodes(prob, name):
    fn = {"k_center": B.k_center, "k_median": B.k_median, "betweenness": B.betweenness}[name]
    s = fn(prob, 4)
    assert len(s) == 4 and s <= set(prob.nodes)


def test_min_feasible_size_is_actually_feasible_and_minimal(prob):
    k = B.min_feasible_size(prob, lambda k: B.k_center(prob, k))
    assert B.is_feasible(prob, B.k_center(prob, k))
    if k > 1:
        assert not B.is_feasible(prob, B.k_center(prob, k - 1))


def test_greco_style_feasible_and_not_worse_than_its_start(prob):
    out = B.greco_style(prob, min_size=1)
    assert B.is_feasible(prob, out)
    start = B.k_center(prob, min(len(prob.nodes), max(2 * 2, 1 + 3)), swap_passes=0)
    if B.is_feasible(prob, start):
        assert prob.evaluate(out).energy_w <= prob.evaluate(start).energy_w + 1e-9


def test_ga_is_deterministic_per_seed_and_feasible(prob):
    a = B.ga_energy(prob, 1, 8, seed=5, population_size=20, generations=15)
    b = B.ga_energy(prob, 1, 8, seed=5, population_size=20, generations=15)
    assert a == b and B.is_feasible(prob, a)


def test_exact_mip_is_never_beaten_by_a_heuristic(prob):
    exact, _ = B.exact_mip(prob, 1, None, time_limit_s=30)
    e_exact = prob.evaluate(exact).energy_w
    for s in (B.greedy_cover(prob), B.greco_style(prob),
              B.k_center(prob, B.min_feasible_size(prob, lambda k: B.k_center(prob, k)))):
        assert e_exact <= prob.evaluate(s).energy_w + 1e-6


def test_random_is_seeded(prob):
    assert B.random_feasible(prob, 5, seed=1) == B.random_feasible(prob, 5, seed=1)


def _pl(ctrls, energy, burden, feasible=True):
    return Placement(controllers=set(ctrls), energy_w=energy, migration_burden=burden,
                     feasible=feasible, worst_case_delay_ms=1.0)


def test_select_min_energy_ignores_infeasible():
    front = [_pl({1}, 100, 5, feasible=False), _pl({1, 2}, 300, 3), _pl({1, 2, 3}, 450, 1)]
    assert select_min_energy(front).energy_w == 300


def test_select_migration_aware_respects_energy_slack():
    front = [_pl({1}, 100, 9), _pl({2}, 112, 4), _pl({3}, 118, 1), _pl({4}, 400, 0)]
    pick = select_migration_aware(front, energy_slack=1.15)   # budget = 115
    assert pick.energy_w == 112                                # 118 and 400 are over budget
    assert select_migration_aware(front, energy_slack=1.20).energy_w == 118
    assert select_migration_aware([_pl({1}, 1, 1, feasible=False)]) is None


GML_MESSY = """graph [
  node [ id 0 label "A" Latitude 40.0 Longitude -74.0 ]
  node [ id 1 label "B" Latitude 41.0 Longitude -87.0 ]
  node [ id 2 label "C" Latitude 34.0 Longitude -118.0 ]
  node [ id 3 label "Hyper" ]
  node [ id 4 label "Island" Latitude 10.0 Longitude 10.0 ]
  edge [ source 0 target 1 ]
  edge [ source 0 target 1 ]
  edge [ source 1 target 2 ]
  edge [ source 2 target 2 ]
  edge [ source 0 target 3 ]
]"""


def test_zoo_loader_handles_parallel_links_selfloops_hyperedges_and_islands(tmp_path):
    f = tmp_path / "messy.gml"
    f.write_text(GML_MESSY)
    g, meta = load_zoo_topology(f)
    assert g.number_of_nodes() == 3            # hyperedge node and the disconnected island dropped
    assert g.number_of_edges() == 2            # parallel link collapsed, self-loop removed
    assert nx.is_connected(g) and sorted(g.nodes) == [0, 1, 2]
    assert all(d["delay"] > 0 for *_, d in g.edges(data=True))
    assert meta["delay_model"] == "geographic"


def test_zoo_loader_uses_hop_count_when_coordinates_are_missing(tmp_path):
    f = tmp_path / "nogeo.gml"
    f.write_text('graph [ node [ id 0 label "a" ] node [ id 1 label "b" ] node [ id 2 label "c" ] '
                 'edge [ source 0 target 1 ] edge [ source 1 target 2 ] ]')
    g, meta = load_zoo_topology(f)
    assert meta["delay_model"].startswith("hop-count")
    assert all(d["delay"] == 1.0 for *_, d in g.edges(data=True))
