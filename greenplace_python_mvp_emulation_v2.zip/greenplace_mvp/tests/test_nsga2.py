from greenplace.config import DelayConfig, NSGA2Config, PowerModel
from greenplace.delay import DelayEngine
from greenplace.ilp_solver import solve_exact
from greenplace.nsga2 import run_nsga2


def _small_cfg(**overrides):
    cfg = NSGA2Config(population_size=24, generations=25, k_min=1, k_max=4, random_seed=1)
    for k, v in overrides.items():
        setattr(cfg, k, v)
    return cfg


def test_pareto_front_is_all_feasible(small_graph, delay_config_loose, power_model):
    eng = DelayEngine(small_graph)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, _small_cfg())
    assert len(front) > 0
    assert all(p.feasible for p in front)


def test_pareto_front_is_non_dominated_2obj(small_graph, delay_config_loose, power_model):
    """Classic 2-objective (energy, delay) non-domination check — uses
    optimize_migration=False so this test verifies exactly the two
    dimensions it inspects (with the 3rd objective active, two points can
    legitimately differ only on migration_burden and *appear* dominated in
    a 2D energy/delay projection while genuinely being mutually
    non-dominated in the full 3D objective space — see the 3-objective
    variant of this test below)."""
    eng = DelayEngine(small_graph)
    cfg = _small_cfg(optimize_migration=False)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, cfg)
    for i, a in enumerate(front):
        for j, b in enumerate(front):
            if i == j:
                continue
            dominates = (
                a.energy_w <= b.energy_w
                and a.worst_case_delay_ms <= b.worst_case_delay_ms
                and (a.energy_w < b.energy_w or a.worst_case_delay_ms < b.worst_case_delay_ms)
            )
            assert not dominates, "Pareto front contains a dominated solution"


def test_pareto_front_is_non_dominated_3obj(small_graph, delay_config_loose, power_model):
    """Same check, but over the full (energy, delay, migration_burden)
    objective space actually used when optimize_migration=True (the default)."""
    eng = DelayEngine(small_graph)
    cfg = _small_cfg(optimize_migration=True)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, cfg)
    for i, a in enumerate(front):
        for j, b in enumerate(front):
            if i == j:
                continue
            a_obj = (a.energy_w, a.worst_case_delay_ms, a.migration_burden)
            b_obj = (b.energy_w, b.worst_case_delay_ms, b.migration_burden)
            dominates = all(x <= y for x, y in zip(a_obj, b_obj)) and any(x < y for x, y in zip(a_obj, b_obj))
            assert not dominates, "Pareto front contains a dominated solution"


def test_pareto_front_respects_delay_bound(small_graph, delay_config_loose, power_model):
    eng = DelayEngine(small_graph)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, _small_cfg())
    for p in front:
        assert p.worst_case_delay_ms <= delay_config_loose.max_switch_to_controller_delay_ms + 1e-9


def test_pareto_front_respects_k_bounds(small_graph, delay_config_loose, power_model):
    eng = DelayEngine(small_graph)
    cfg = _small_cfg(k_min=2, k_max=3)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, cfg)
    for p in front:
        assert 2 <= len(p.controllers) <= 3


def test_nsga2_within_tolerance_of_exact_on_tiny_graph(tiny_graph, delay_config_loose, power_model):
    """Cross-validation: NSGA-II's best energy should be close to the exact optimum."""
    eng = DelayEngine(tiny_graph)
    exact_placement, _info = solve_exact(tiny_graph, eng, power_model, delay_config_loose,
                                          k_min=1, k_max=len(tiny_graph.nodes))
    cfg = _small_cfg(k_min=1, k_max=len(tiny_graph.nodes), generations=40)
    front = run_nsga2(tiny_graph, eng, power_model, delay_config_loose, cfg)
    best_nsga2_energy = min(p.energy_w for p in front)

    tolerance = 0.15  # heuristic should be within 15% of exact on a trivially small graph
    assert best_nsga2_energy <= exact_placement.energy_w * (1 + tolerance)


def test_migration_aware_front_carries_burden_values(small_graph, delay_config_loose, power_model):
    eng = DelayEngine(small_graph)
    cfg = _small_cfg(optimize_migration=True)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, cfg)
    assert len(front) > 0
    assert all(p.migration_burden >= 0 for p in front)


def test_migration_aware_search_still_respects_delay_bound(small_graph, delay_config_loose, power_model):
    """Adding the 3rd objective must not weaken the hard delay constraint."""
    eng = DelayEngine(small_graph)
    cfg = _small_cfg(optimize_migration=True)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, cfg)
    for p in front:
        assert p.worst_case_delay_ms <= delay_config_loose.max_switch_to_controller_delay_ms + 1e-9


def test_migration_objective_can_be_disabled(small_graph, delay_config_loose, power_model):
    """optimize_migration=False should reproduce plain 2-objective behavior
    (front members still carry a migration_burden value for reporting, but
    it plays no role in the dominance comparison used to build the front)."""
    eng = DelayEngine(small_graph)
    cfg = _small_cfg(optimize_migration=False)
    front = run_nsga2(small_graph, eng, power_model, delay_config_loose, cfg)
    assert len(front) > 0
    assert all(p.feasible for p in front)
