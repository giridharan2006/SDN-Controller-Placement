import pytest

from greenplace.config import DelayConfig, PowerModel, RuntimeConfig
from greenplace.runtime import RuntimeManager, generate_diurnal_trace


def test_diurnal_trace_shape_and_bounds():
    trace = generate_diurnal_trace(timesteps=48, seed=0)
    assert len(trace) == 48
    assert (trace >= 0).all() and (trace <= 1).all()


def test_runtime_never_violates_delay_bound(medium_graph):
    delay_cfg = DelayConfig(max_switch_to_controller_delay_ms=25.0)
    runtime_cfg = RuntimeConfig(controller_capacity=6, timesteps=24)
    candidates = set(list(medium_graph.nodes)[:6])  # 6 candidates x capacity 6 = 36 >= 15 nodes

    manager = RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, runtime_cfg)
    trace = generate_diurnal_trace(timesteps=24, seed=1)
    results = manager.run(trace)

    for r in results:
        assert r.feasible
        assert r.worst_case_delay_ms <= delay_cfg.max_switch_to_controller_delay_ms + 1e-9


def test_runtime_sleeps_controllers_at_low_load(medium_graph):
    delay_cfg = DelayConfig(max_switch_to_controller_delay_ms=30.0)
    runtime_cfg = RuntimeConfig(controller_capacity=8, timesteps=24)
    candidates = set(list(medium_graph.nodes)[:6])

    manager = RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, runtime_cfg)
    trace = generate_diurnal_trace(timesteps=24, seed=1)
    results = manager.run(trace)

    max_active = max(r.active_controllers for r in results)
    min_active = min(r.active_controllers for r in results)
    # Over a diurnal cycle we expect the manager to actually vary controller count,
    # not just run everything awake all the time.
    assert min_active < max_active


def test_runtime_rejects_undersized_candidate_pool(medium_graph):
    delay_cfg = DelayConfig(max_switch_to_controller_delay_ms=30.0)
    runtime_cfg = RuntimeConfig(controller_capacity=2, timesteps=10)  # too small on purpose
    candidates = {list(medium_graph.nodes)[0]}  # 1 controller x capacity 2 = 2 << 15 nodes

    with pytest.raises(ValueError):
        RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, runtime_cfg)


def test_migrations_are_counted_and_non_negative(medium_graph):
    delay_cfg = DelayConfig(max_switch_to_controller_delay_ms=30.0)
    runtime_cfg = RuntimeConfig(controller_capacity=8, timesteps=24)
    candidates = set(list(medium_graph.nodes)[:6])

    manager = RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, runtime_cfg)
    trace = generate_diurnal_trace(timesteps=24, seed=2)
    results = manager.run(trace)

    assert all(r.migrations >= 0 for r in results)
    assert results[0].migrations == 0  # nothing to migrate from on the very first step


def test_hysteresis_reduces_transitions_vs_no_dwell_time(medium_graph):
    """A minimum dwell time between sleep decisions should reduce (or at
    worst not increase) how often the active-controller count changes,
    compared to reacting to every single-timestep noise fluctuation.
    """
    delay_cfg = DelayConfig(max_switch_to_controller_delay_ms=30.0)
    candidates = set(list(medium_graph.nodes)[:6])
    trace = generate_diurnal_trace(timesteps=48, seed=1, noise=0.15)  # noisier trace to stress-test

    cfg_no_dwell = RuntimeConfig(controller_capacity=6, timesteps=48, load_ema_alpha=1.0, min_dwell_steps=0)
    cfg_dwell = RuntimeConfig(controller_capacity=6, timesteps=48, load_ema_alpha=0.3, min_dwell_steps=3)

    results_no_dwell = RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, cfg_no_dwell).run(trace)
    results_dwell = RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, cfg_dwell).run(trace)

    transitions_no_dwell = sum(1 for r in results_no_dwell if r.changed)
    transitions_dwell = sum(1 for r in results_dwell if r.changed)

    assert transitions_dwell <= transitions_no_dwell


def test_delay_bound_still_respected_with_hysteresis(medium_graph):
    """Smoothing/dwell-time must never come at the cost of the hard delay
    guarantee — this is the one invariant that must never be traded away.
    """
    delay_cfg = DelayConfig(max_switch_to_controller_delay_ms=25.0)
    runtime_cfg = RuntimeConfig(controller_capacity=6, timesteps=48, load_ema_alpha=0.3, min_dwell_steps=3)
    candidates = set(list(medium_graph.nodes)[:6])
    manager = RuntimeManager(medium_graph, candidates, PowerModel(), delay_cfg, runtime_cfg)
    trace = generate_diurnal_trace(timesteps=48, seed=1)
    results = manager.run(trace)
    assert all(r.feasible and r.worst_case_delay_ms <= 25.0 + 1e-9 for r in results)
