import networkx as nx
import pytest

from greenplace.config import PowerModel
from greenplace.delay import DelayEngine
from greenplace.power import control_plane_energy_w, energy_breakdown


@pytest.fixture
def star_graph():
    """Controller at node 0; three switches, each 1 hop away."""
    g = nx.Graph()
    g.add_edge(0, 1, delay=1.0)
    g.add_edge(0, 2, delay=1.0)
    g.add_edge(0, 3, delay=1.0)
    return g


def test_energy_matches_hand_calculation(star_graph):
    pm = PowerModel(controller_active_w=100.0, link_hop_w=5.0)
    eng = DelayEngine(star_graph)
    controllers = {0}
    assignment = {1: 0, 2: 0, 3: 0, 0: 0}
    energy = control_plane_energy_w(controllers, assignment, eng, pm)
    # 1 controller x 100W + 3 switches x 1 hop x 5W = 100 + 15 = 115
    assert energy == pytest.approx(115.0)


def test_more_controllers_increase_base_energy(star_graph):
    pm = PowerModel(controller_active_w=100.0, link_hop_w=5.0)
    eng = DelayEngine(star_graph)
    e_one = control_plane_energy_w({0}, {1: 0, 2: 0, 3: 0}, eng, pm)
    e_two = control_plane_energy_w({0, 1}, {1: 1, 2: 0, 3: 0}, eng, pm)
    assert e_two > e_one  # extra controller power dominates the saved hop


def test_energy_breakdown_fields(star_graph):
    pm = PowerModel(controller_active_w=100.0, link_hop_w=5.0)
    eng = DelayEngine(star_graph)
    breakdown = energy_breakdown({0}, {1: 0, 2: 0, 3: 0}, eng, pm)
    assert breakdown["num_controllers"] == 1
    assert breakdown["total_link_hops"] == 3
    assert breakdown["total_w"] == pytest.approx(115.0)
