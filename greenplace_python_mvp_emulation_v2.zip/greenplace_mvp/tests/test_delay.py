import networkx as nx
import pytest

from greenplace.delay import DelayEngine


@pytest.fixture
def line_graph():
    """0 -1ms- 1 -2ms- 2 -3ms- 3   (a simple line, hand-checkable)"""
    g = nx.Graph()
    g.add_edge(0, 1, delay=1.0)
    g.add_edge(1, 2, delay=2.0)
    g.add_edge(2, 3, delay=3.0)
    return g


def test_direct_neighbor_delay(line_graph):
    eng = DelayEngine(line_graph)
    assert eng.delay(0, 1) == pytest.approx(1.0)


def test_multi_hop_delay_sums_correctly(line_graph):
    eng = DelayEngine(line_graph)
    # 0 -> 3 must go through 1 and 2: 1 + 2 + 3 = 6
    assert eng.delay(0, 3) == pytest.approx(6.0)


def test_self_delay_is_zero(line_graph):
    eng = DelayEngine(line_graph)
    assert eng.delay(2, 2) == 0.0


def test_hop_count(line_graph):
    eng = DelayEngine(line_graph)
    assert eng.hop_count(0, 3) == 3
    assert eng.hop_count(0, 1) == 1
    assert eng.hop_count(0, 0) == 0


def test_nearest_picks_closest_candidate(line_graph):
    eng = DelayEngine(line_graph)
    controller, d = eng.nearest(0, {2, 3})
    assert controller == 2  # delay(0,2)=3 < delay(0,3)=6
    assert d == pytest.approx(3.0)


def test_worst_case_delay():
    g = nx.Graph()
    g.add_edge(0, 1, delay=1.0)
    g.add_edge(0, 2, delay=5.0)
    eng = DelayEngine(g)
    assignment = {1: 0, 2: 0}
    assert eng.worst_case_delay(assignment) == pytest.approx(5.0)
