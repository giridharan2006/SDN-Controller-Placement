from greenplace.config import DelayConfig, PowerModel
from greenplace.delay import DelayEngine
from greenplace.ilp_solver import solve_exact
from greenplace.placement import evaluate_placement
import itertools


def test_exact_solver_finds_true_optimum_on_tiny_graph(tiny_graph, delay_config_loose):
    """Cross-check solve_exact against a brute-force reference computed
    independently in the test itself (not reusing solver internals)."""
    eng = DelayEngine(tiny_graph)
    pm = PowerModel()
    nodes = list(tiny_graph.nodes)

    reference_best = None
    for k in range(1, len(nodes) + 1):
        for combo in itertools.combinations(nodes, k):
            placement = evaluate_placement(tiny_graph, set(combo), eng, pm, delay_config_loose)
            if placement.feasible and (reference_best is None or placement.energy_w < reference_best):
                reference_best = placement.energy_w

    placement, info = solve_exact(tiny_graph, eng, pm, delay_config_loose, k_min=1, k_max=len(nodes))
    assert placement.feasible
    assert placement.energy_w == reference_best
    assert info["status"] in ("optimal", "Optimal")


def test_exact_solver_respects_delay_bound(small_graph, delay_config_tight):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    placement, _info = solve_exact(small_graph, eng, pm, delay_config_tight, k_min=1, k_max=len(small_graph.nodes))
    if placement.feasible:
        assert placement.worst_case_delay_ms <= delay_config_tight.max_switch_to_controller_delay_ms + 1e-9


def test_exact_solver_respects_k_bounds(small_graph, delay_config_loose):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    placement, _info = solve_exact(small_graph, eng, pm, delay_config_loose, k_min=2, k_max=3)
    assert 2 <= len(placement.controllers) <= 3
