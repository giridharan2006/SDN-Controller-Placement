import sys
from pathlib import Path

# Make the greenplace package importable when running `pytest` from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from greenplace.topology import generate_synthetic_topology
from greenplace.config import PowerModel, DelayConfig


@pytest.fixture
def tiny_graph():
    """A 4-node topology small enough to hand-verify and brute-force exactly."""
    return generate_synthetic_topology(n_nodes=4, seed=1, extra_edge_prob=0.3)


@pytest.fixture
def small_graph():
    return generate_synthetic_topology(n_nodes=8, seed=2, extra_edge_prob=0.2)


@pytest.fixture
def medium_graph():
    return generate_synthetic_topology(n_nodes=15, seed=3, extra_edge_prob=0.15)


@pytest.fixture
def power_model():
    return PowerModel()


@pytest.fixture
def delay_config_loose():
    return DelayConfig(max_switch_to_controller_delay_ms=50.0)


@pytest.fixture
def delay_config_tight():
    return DelayConfig(max_switch_to_controller_delay_ms=6.0)
