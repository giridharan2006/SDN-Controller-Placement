"""Tests for the Mininet/Ryu emulation package.

Everything except the last test is pure Python (no root, no Mininet, no Ryu). The integration test runs a real
2-switch Mininet network with two Ryu controllers and is skipped unless GREENPLACE_EMU_IT=1, root and all tools exist.
"""
import json
import os
import py_compile
import socket
import subprocess
import sys
import time
from pathlib import Path

import networkx as nx
import pytest

ROOT = Path(__file__).resolve().parents[1]
ABILENE = ROOT / "data" / "real_topologies" / "Abilene.gml"
NSFNET = ROOT / "data" / "real_topologies" / "Nsfnet.gml"

from emulation import analysis as A  # noqa: E402
from emulation.controllers import ControllerManager, last_heartbeat, port_open  # noqa: E402
from emulation.monitor import rapl_status  # noqa: E402
from emulation.schedule import build_plan, validate_plan  # noqa: E402
from emulation.topo_spec import build_spec, follow, host_ip  # noqa: E402
from greenplace.topology import load_zoo_topology  # noqa: E402


# ------------------------------------------------------------------------------------------------ schedule
@pytest.fixture(scope="module")
def abilene_plan():
    return build_plan(ABILENE, "diurnal", 0, 0)


def test_plan_matches_simulator(abilene_plan):
    """The emulation replays exactly the runtime manager's decisions: same migrations as the simulator."""
    assert validate_plan(abilene_plan) == []
    assert abilene_plan.n_reassignments == abilene_plan.sim_summary["migrations"]
    assert len(abilene_plan.steps) == 96


def test_plan_action_order_is_safe(abilene_plan):
    prev_active = set()
    for s in abilene_plan.steps:
        assert set(s.assignment.values()) <= set(s.active), "switch assigned to a sleeping controller"
        assert set(s.wake) == set(s.active) - prev_active
        assert set(s.sleep) == prev_active - set(s.active)
        for u, frm, to in s.reassign:
            assert s.assignment[u] == to and frm != to
        prev_active = set(s.active)


def test_plan_uses_greenplace_pool_and_given_pool(abilene_plan):
    # the pool is a GreenPlace pick: delay-feasible and inside the topology
    assert set(abilene_plan.pool) <= set(range(abilene_plan.n_switches))
    forced = build_plan(ABILENE, "diurnal", 0, 0, pool=abilene_plan.pool)
    assert [s.assignment for s in forced.steps] == [s.assignment for s in abilene_plan.steps]


# ------------------------------------------------------------------------------------------------ topology
@pytest.mark.parametrize("gml", [ABILENE, NSFNET])
def test_spec_ports_and_loop_free_routes(gml):
    g, meta = load_zoo_topology(gml)
    spec = build_spec(g)
    ports = {}
    for u, v, pu, pv, d in spec.links:
        assert pu >= 2 and pv >= 2 and d > 0
        assert (u, pu) not in ports and (v, pv) not in ports
        ports[(u, pu)], ports[(v, pv)] = v, u
    for s in spec.nodes:
        for d in spec.nodes:
            walk = follow(spec, s, d)                      # raises on a loop
            assert walk[0] == s and walk[-1] == d
            assert walk == spec.paths[(s, d)]
            assert nx.is_simple_path(g, walk) or len(walk) == 1


def test_host_addressing_unique():
    ips = {host_ip(i) for i in range(600)}
    assert len(ips) == 600


# ------------------------------------------------------------------------------------------------ analysis
def _events():
    return [
        {"ts": 10.000, "ctrl": "1", "ev": "ready", "dpid": 3},
        {"ts": 20.010, "ctrl": "1", "ev": "down", "dpid": 3},
        {"ts": 20.015, "ctrl": "2", "ev": "features", "dpid": 3},
        {"ts": 20.020, "ctrl": "2", "ev": "ready", "dpid": 3},
    ]


def test_match_handovers_timings():
    h = [{"switch": 2, "dpid": 3, "from": 1, "to": 2, "t_cmd": 20.000}]
    A.match_handovers(h, _events())
    assert h[0]["ok"] and h[0]["handshake_ms"] == pytest.approx(15.0, abs=1e-6)
    assert h[0]["ready_ms"] == pytest.approx(20.0, abs=1e-6)
    assert h[0]["old_down_ms"] == pytest.approx(10.0, abs=1e-6)


def test_match_handovers_missing_ready_is_failure():
    h = [{"switch": 2, "dpid": 3, "from": 1, "to": 9, "t_cmd": 20.0}]
    A.match_handovers(h, _events())
    assert not h[0]["ok"] and h[0]["ready_ms"] is None


def test_traffic_join_loss_and_latency():
    sent = [{"kind": "P", "dst": "10.0.0.2", "sport": "20000", "seq": str(i), "send_ts": str(100 + i)} for i in range(4)]
    recv = [{"kind": "P", "src": "10.0.0.1", "sport": "20000", "seq": "0", "send_ts": "100", "recv_ts": "100.010"},
            {"kind": "P", "src": "10.0.0.1", "sport": "20001", "seq": "2", "send_ts": "102", "recv_ts": "102.030"},
            {"kind": "P", "src": "10.0.0.9", "sport": "20001", "seq": "1", "send_ts": "102", "recv_ts": "102.030"}]
    pk = A.join_traffic(sent, recv, "10.0.0.1")
    assert [p["lost"] for p in pk] == [False, True, False, True]
    ll = A.loss_latency(pk)
    assert ll["lost"] == 2 and ll["loss_pct"] == 50.0
    assert ll["latency_ms"]["median"] == pytest.approx(20.0, abs=0.01)


def test_classification_and_bursts():
    paths = {(0, 1): [0, 1], (1, 0): [1, 0]}
    ip2 = {"10.0.0.1": 0, "10.0.0.2": 1}
    windows = {1: [(50.0, 50.1)]}
    pk = [{"src": "10.0.0.1", "dst": "10.0.0.2", "send_ts": t, "lost": False, "latency_ms": 1.0}
          for t in (10.0, 49.0, 50.05, 51.0, 60.0)]
    A.classify_packets(pk, paths, ip2, windows, clear_s=2.0)
    assert [p["cls"] for p in pk] == ["baseline", "near", "affected", "near", "baseline"]
    ho = {"switch": 1, "step": 3, "t_cmd": 50.0, "t_ready": 50.02}
    b = [{"send_ts": t, "lost": t == 50.03, "latency_ms": 2.0, "switch": 1, "step": 3} for t in (49.8, 50.03, 50.2)]
    A.burst_phases(b, ho)
    assert [p["phase"] for p in b] == ["before", "during", "after"]
    row = A.per_handover_bursts([ho], b)[0]
    assert row["burst_during_lost"] == 1 and row["burst_before_lost"] == 0


def test_stream_gaps():
    pk = [{"send_ts": 1.0 + i * 0.01, "recv_ts": 1.0 + i * 0.01 + 0.001, "lost": False} for i in range(10)]
    pk[5]["lost"], pk[5]["recv_ts"] = True, None
    r = A.stream_gaps(pk, [(1.045, 1.055)])
    assert r["lost"] == 1 and r["lost_in_windows"] == 1 and r["max_gap_ms"] == pytest.approx(20.0, abs=0.01)


def test_resource_summary_split():
    rows = [{"t": "1.0", "kind": "controller", "id": "4", "cpu_percent": "10", "rss_mb": "40"},
            {"t": "2.0", "kind": "controller", "id": "4", "cpu_percent": "30", "rss_mb": "42"}]
    r = A.resource_summary(rows, [(1.5, 2.5)])["controller:4"]
    assert r["cpu_mean"] == 20 and r["cpu_mean_in_windows"] == 30 and r["cpu_mean_outside"] == 10
    assert r["rss_mb_peak"] == 42


# ------------------------------------------------------------------------------------------------ tools
def test_ryu_app_compiles():
    py_compile.compile(str(ROOT / "emulation" / "ryu_app" / "gp_controller.py"), doraise=True)


def _wait_for_file(path, proc, timeout_s=20.0):
    t0 = time.time()
    while not path.exists():
        if proc.poll() is not None:
            raise AssertionError(f"receiver exited early with code {proc.returncode}")
        if time.time() - t0 > timeout_s:
            raise AssertionError(f"receiver not ready after {timeout_s}s")
        time.sleep(0.01)


# The delays reproduce what a loaded machine does to process start-up. The original test fixed an absolute deadline
# before starting either process and slept a fixed 0.3 s instead of checking readiness, so a late sender sent nothing
# (deadline already past) and a late receiver dropped the first packets (port not yet bound).
@pytest.mark.parametrize("receiver_delay,sender_delay", [(0.0, 0.0), (0.6, 0.0), (0.0, 1.3)],
                         ids=["no-delay", "late-receiver", "late-sender"])
def test_traffic_probe_localhost(tmp_path, receiver_delay, sender_delay):
    """Probe sender/receiver round trip on loopback (no Mininet): every packet is logged and matched.

    Synchronisation: the receiver signals readiness with --ready-file only after its socket is bound; the sender is
    started only after that and sends a fixed --count (no wall-clock window); the receiver exits after --expect
    datagrams, with --until only as a safety deadline."""
    probe = ROOT / "emulation" / "traffic_probe.py"
    n = 40
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    ready = tmp_path / "rx.ready"
    rx_cmd = (f"sleep {receiver_delay}; exec {sys.executable} {probe} recv --port {port} --out {tmp_path / 'r.csv'} "
              f"--ready-file {ready} --expect {n} --until {time.time() + 60}")
    rx = subprocess.Popen(["sh", "-c", rx_cmd])
    try:
        _wait_for_file(ready, rx)
        tx_cmd = (f"sleep {sender_delay}; exec {sys.executable} {probe} probes --dsts 127.0.0.1 --port {port} "
                  f"--rate 200 --count {n} --sport-lo 41000 --sport-hi 41999 --out {tmp_path / 's.csv'}")
        subprocess.run(["sh", "-c", tx_cmd], check=True, timeout=60)
        rx.wait(timeout=60)
    finally:
        if rx.poll() is None:
            rx.kill()
    assert rx.returncode == 0
    sent = A.read_csv(tmp_path / "s.csv")
    pk = A.join_traffic(sent, A.read_csv(tmp_path / "r.csv"), "127.0.0.1")
    assert len(sent) == n, f"sender wrote {len(sent)} packets, expected {n}"
    assert sum(p["lost"] for p in pk) == 0


def test_controller_manager_lifecycle_with_stub(tmp_path):
    """Start / health / stop logic, using a stub 'ryu-manager' that listens and writes heartbeats."""
    stub = tmp_path / "fake-ryu-manager"
    stub.write_text(f"""#!{sys.executable}
import json, os, socket, sys, time
port = int(sys.argv[sys.argv.index('--ofp-tcp-listen-port') + 1])
cfg = json.load(open(os.environ['GP_EMU_CONFIG']))
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(('127.0.0.1', port)); s.listen()
while True:
    with open(cfg['events_path'], 'a') as fh:
        fh.write(json.dumps({{'ts': time.time(), 'ctrl': cfg['label'], 'ev': 'heartbeat', 'dpid': None}}) + '\\n')
    time.sleep(0.2)
""")
    stub.chmod(0o755)
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        base = s.getsockname()[1]
    cm = ControllerManager(tmp_path, {"1": {}}, str(stub), base_port=base, ready_timeout_s=10)
    cm.assign_ports([7])
    dt = cm.start(7)
    assert 0 < dt < 10
    h = cm.health(7)
    assert h["alive"] and h["port_open"] and h["healthy"]
    assert last_heartbeat(cm.events_path, "7") is not None
    cm.stop(7)
    assert not port_open(base)
    assert not cm.health(7)["healthy"]
    events = [x["event"] for x in cm.log]
    assert events == ["wake", "sleep"]


def test_rapl_status_never_invents_power():
    st = rapl_status()
    assert isinstance(st["available"], bool)
    if not st["available"]:
        assert st["reason"]


# ------------------------------------------------------------------------------------------------ integration
def _it_ready():
    if os.environ.get("GREENPLACE_EMU_IT") != "1":
        return "set GREENPLACE_EMU_IT=1 to run the Mininet integration test"
    if os.geteuid() != 0:
        return "needs root"
    from emulation.env_check import check
    c = check()
    return None if c["ready"] else "emulation prerequisites missing (python -m emulation.env_check)"


@pytest.mark.skipif(_it_ready() is not None, reason=str(_it_ready()))
def test_mininet_two_switch_handover(tmp_path):
    """Real Mininet: 3-node line, two controllers, one break-before-make and one make-before-break hand-over."""
    from emulation.controllers import find_ryu_manager
    from emulation.runner import build_network, ovs_controller_state, target, vsctl
    g = nx.path_graph(3)
    for u, v in g.edges():
        g[u][v]["delay"] = 1.0
    spec = build_spec(g)
    subprocess.run(["mn", "-c"], capture_output=True)
    net, sw, hosts = build_network(g, spec, "kernel" if Path("/sys/module/openvswitch").exists() else "user", False)
    cm = ControllerManager(tmp_path, spec.routes_json(), find_ryu_manager())
    try:
        cm.assign_ports([0, 2])
        cm.start(0)
        cm.start(2)
        hs = []
        for i in spec.nodes:
            h = {"switch": i, "dpid": spec.dpid(i), "from": None, "to": 0, "t_cmd": time.time()}
            vsctl("set-controller", spec.sw(i), target(cm.ports[0]))
            hs.append(h)
        time.sleep(1.5)
        A.match_handovers(hs, A.read_events(cm.events_path))
        assert all(h["ok"] for h in hs)
        # break-before-make: s3 -> controller 2
        h = {"switch": 2, "dpid": 3, "from": 0, "to": 2, "t_cmd": time.time()}
        vsctl("set-controller", "s3", target(cm.ports[2]))
        time.sleep(1.0)
        # make-before-break: s2 -> controller 2
        h2 = {"switch": 1, "dpid": 2, "from": 0, "to": 2, "t_cmd": time.time()}
        vsctl("set-controller", "s2", target(cm.ports[0]), target(cm.ports[2]))
        time.sleep(1.0)
        vsctl("set-controller", "s2", target(cm.ports[2]))
        time.sleep(0.5)
        A.match_handovers([h, h2], A.read_events(cm.events_path))
        assert h["ok"] and h2["ok"] and 0 < h["ready_ms"] < 5000 and 0 < h2["ready_ms"] < 5000
        st = ovs_controller_state()
        assert [t for t, _ in st["s3"]] == [target(cm.ports[2])]
        assert [t for t, _ in st["s2"]] == [target(cm.ports[2])]
        # data plane through all three switches after the hand-overs
        probe = ROOT / "emulation" / "traffic_probe.py"
        until = time.time() + 1.5
        rx = hosts[2].popen([sys.executable, str(probe), "recv", "--out", str(tmp_path / "r.csv"),
                             "--until", str(until + 1)])
        time.sleep(0.3)
        hosts[0].cmd(f"{sys.executable} {probe} probes --dsts {host_ip(2)} --rate 20 --out {tmp_path / 's.csv'} "
                     f"--until {until}")
        rx.wait(timeout=10)
        pk = A.join_traffic(A.read_csv(tmp_path / "s.csv"), A.read_csv(tmp_path / "r.csv"), host_ip(0))
        assert len(pk) > 10 and sum(p["lost"] for p in pk) == 0
    finally:
        cm.stop_all()
        net.stop()


def test_stream_gap_decomposition(tmp_path):
    """A sender pause shows up as send_gap ≈ recv_gap; a transit delay as network_excess; overlap with an on-path
    hand-over is detected; nothing is lost."""
    from emulation.stream_gaps import run_gaps
    d = tmp_path / "run"
    d.mkdir()
    (d / "topology_spec.json").write_text(json.dumps({"hosts": {"h1": "10.0.0.1", "h2": "10.0.0.2"}}))
    (d / "plan.json").write_text(json.dumps({"n_switches": 2}))
    A.write_csv(d / "handovers.csv", [{"switch": 1, "initial": "False", "t_cmd": 100.30, "t_ready": 100.32}],
                ["switch", "initial", "t_cmd", "t_ready"])
    A.write_csv(d / "streams.csv", [{"src": "h1", "dst": "h2", "path": "s1 s2"}], ["src", "dst", "path"])
    send = [100.00 + 0.01 * i for i in range(10)] + [100.20 + 0.01 * i for i in range(10)]   # 110 ms sender pause
    recv = [t + 0.001 for t in send]
    recv[15] += 0.080                                   # one packet delayed 80 ms in transit
    recv[16:] = [max(r, recv[15] + 0.0001 * k) for k, r in enumerate(recv[16:], 1)]
    A.write_csv(d / "stream_0.csv", [{"kind": "S", "dst": "10.0.0.2", "sport": 10000, "seq": i, "send_ts": t}
                                     for i, t in enumerate(send)], ["kind", "dst", "sport", "seq", "send_ts"])
    A.write_csv(d / "recv_0.csv", [], ["kind", "src", "sport", "seq", "send_ts", "recv_ts"])
    A.write_csv(d / "recv_1.csv", [{"kind": "S", "src": "10.0.0.1", "sport": 10000, "seq": i, "send_ts": send[i],
                                    "recv_ts": t} for i, t in enumerate(recv)],
                ["kind", "src", "sport", "seq", "send_ts", "recv_ts"])
    gaps = run_gaps(d, threshold_ms=50)
    assert len(gaps) == 2
    pause, delay = sorted(gaps, key=lambda g: g["t_start"])
    assert pause["send_gap_ms"] == pytest.approx(110, abs=0.5) and abs(pause["network_excess_ms"]) < 1
    assert delay["network_excess_ms"] == pytest.approx(80, abs=1) and delay["on_path_handover"]
    assert all(g["lost_in_gap"] == 0 for g in gaps)
