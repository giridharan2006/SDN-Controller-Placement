import networkx as nx

from greenplace.topology import generate_backbone_like_topology, generate_synthetic_topology, load_topology_json


def test_synthetic_topology_is_connected():
    g = generate_synthetic_topology(n_nodes=10, seed=5)
    assert nx.is_connected(g)


def test_synthetic_topology_edges_have_delay():
    g = generate_synthetic_topology(n_nodes=6, seed=7)
    for _u, _v, data in g.edges(data=True):
        assert "delay" in data
        assert data["delay"] > 0


def test_load_topology_json(tmp_path):
    fixture = tmp_path / "toy.json"
    fixture.write_text(
        '{"nodes": [0,1,2,3], "edges": [[0,1,2.0],[1,2,3.0],[2,3,1.0],[3,0,4.0]]}'
    )
    g = load_topology_json(fixture)
    assert set(g.nodes) == {0, 1, 2, 3}
    assert g[0][1]["delay"] == 2.0
    assert nx.is_connected(g)


def test_backbone_like_topology_connected_and_sized():
    g = generate_backbone_like_topology(n_nodes=34, seed=1)
    assert nx.is_connected(g)
    assert g.number_of_nodes() == 34


def test_backbone_like_topology_realistic_sparsity():
    """Real WAN backbones are sparse (avg degree roughly 2-3.5), unlike a
    dense random graph at this node count — this is what motivated adding
    this generator alongside the plain ring-plus-chords one."""
    g = generate_backbone_like_topology(n_nodes=40, seed=2)
    avg_degree = sum(d for _, d in g.degree()) / g.number_of_nodes()
    assert 2.0 <= avg_degree <= 3.5


def test_backbone_like_topology_edges_have_positive_delay():
    g = generate_backbone_like_topology(n_nodes=20, seed=3)
    assert all(d["delay"] > 0 for _, _, d in g.edges(data=True))
