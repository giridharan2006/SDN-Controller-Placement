"""Tests for the v3 additions: traffic scenarios, NSGA-III / MOPSO / EnPlace-style, indicators, burden hook."""
import numpy as np
import pytest

from greenplace import baselines as B
from greenplace import moea
from greenplace.config import DelayConfig, NSGA2Config, PowerModel
from greenplace.delay import DelayEngine
from greenplace.lifecycle import simulate
from greenplace.metrics import front_indicators, hypervolume_3d, igd
from greenplace.nsga2 import run_nsga2
from greenplace.topology import generate_backbone_like_topology
from greenplace.traffic import REAL, SYNTHETIC, get_trace


@pytest.fixture(scope="module")
def prob():
    g = generate_backbone_like_topology(20, seed=1)
    eng = DelayEngine(g)
    diam = max(d for s in eng._dist.values() for d in s.values())
    return B.Problem(g, eng, PowerModel(), DelayConfig(0.4 * diam))


@pytest.mark.parametrize("kind", SYNTHETIC + REAL)
def test_traces_valid(kind):
    t = get_trace(kind, seed=3, steps=96)
    assert t.shape == (96,) and t.min() >= 0.05 - 1e-9 and t.max() <= 1.0 + 1e-9
    assert np.allclose(t, get_trace(kind, seed=3, steps=96))          # deterministic


def test_diurnal_matches_legacy_generator():
    from greenplace.runtime import generate_diurnal_trace
    assert np.allclose(get_trace("diurnal", 2, 96), generate_diurnal_trace(timesteps=96, seed=2))


def test_das_dennis_counts():
    assert moea.das_dennis(3, 4).shape == (15, 3)
    assert np.allclose(moea.das_dennis(3, 4).sum(1), 1.0)


def test_hypervolume_3d_known_values():
    assert hypervolume_3d([(0, 0, 0)], (1, 1, 1)) == pytest.approx(1.0)
    assert hypervolume_3d([(0, 0, .5), (.5, .5, 0)], (1, 1, 1)) == pytest.approx(0.625)
    assert hypervolume_3d([(2, 2, 2)], (1, 1, 1)) == 0.0
    # dominated point adds nothing
    assert hypervolume_3d([(0, 0, 0), (.5, .5, .5)], (1, 1, 1)) == pytest.approx(1.0)


def test_igd_zero_for_identical_fronts():
    pts = [(0, 1, 1), (1, 0, 1)]
    assert igd(pts, pts, 1.0) == 0.0 and igd([(5, 5, 5)], pts, 1.0) > 0


@pytest.mark.parametrize("algo", ["nsga3", "mopso"])
def test_moea_fronts_feasible_and_nondominated(prob, algo):
    fn = moea.run_nsga3 if algo == "nsga3" else moea.run_mopso
    front = fn(prob, 1, 6, seed=0, pop=20, gens=15) if algo == "nsga3" else fn(prob, 1, 6, seed=0, swarm=20, iters=15)
    assert front and all(isinstance(q.controllers, (set, frozenset)) for q in front)
    feas = [q for q in front if q.feasible]
    assert feas, "search should find at least one feasible placement on an easy instance"
    for a in feas:
        for b in feas:
            if a is b:
                continue
            ao = (a.energy_w, a.worst_case_delay_ms, a.migration_burden); bo = (b.energy_w, b.worst_case_delay_ms, b.migration_burden)
            assert not (all(x <= y for x, y in zip(ao, bo)) and any(x < y for x, y in zip(ao, bo)))


def test_enplace_style_is_feasible(prob):
    s = moea.enplace_style(prob)
    assert prob.evaluate(s).feasible


def test_burden_hook_replaces_third_objective(prob):
    cfg = NSGA2Config(population_size=16, generations=6, k_min=1, k_max=5, random_seed=0)
    front = run_nsga2(prob.graph, prob.engine, prob.power, prob.delay_config, cfg, burden_fn=lambda pl: 7.0)
    assert front and all(q.migration_burden == 7.0 for q in front)


def test_simulate_reports_state_changes_and_avg_active(prob):
    pool = B.greedy_cover(prob, 4)
    cap = int(np.ceil(20 / 4)) + 2
    r = simulate(prob, pool, cap, get_trace("diurnal", 0, 96))
    assert r["state_changes"] >= r["transitions"] >= 0
    assert r["min_active"] <= r["avg_active"] <= r["max_active"]


def test_front_indicators_prefer_dominating_front(prob):
    good = B.nsga2_front(prob, 1, 6, 0, True, 20, 15)
    worse = [prob.evaluate(set(list(prob.nodes)[:6]))]
    q = front_indicators({"good": good, "worse": worse})
    assert q["good"]["hv"] >= q["worse"]["hv"]


def test_study3_runs_on_tiny_topology(tmp_path):
    from greenplace.benchmark import BenchConfig
    from greenplace.study3 import SCENARIOS, run_topology3
    from greenplace.topology import save_topology_gml
    f = tmp_path / "tiny.gml"
    save_topology_gml(generate_backbone_like_topology(14, seed=2), f)
    cfg = BenchConfig(seeds=1, nsga_pop=12, nsga_gens=5, mip_time_limit_s=10)
    rows, cands, qual = run_topology3(f, cfg, seeds=[0], with_sim=False)
    by = {r["method"]: r for r in rows}
    assert {"greenplace", "nsga3", "mopso", "enplace", "exact_mip", "greenplace_sil"} <= set(by)
    for r in rows:
        for sc in SCENARIOS:
            assert r[f"{sc}__violations"] == 0
    assert cands and qual
    assert all(q["hv"] >= 0 for q in qual)


def test_mip_info_reports_lower_bound(prob):
    s, info = B.exact_mip(prob, 1, None, 20)
    assert info["model_energy_w"] <= prob.evaluate(s).energy_w + 1e-9    # free assignment <= nearest assignment


def test_demo_dashboard_renders_from_shipped_results(tmp_path):
    import subprocess, sys
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    r = subprocess.run([sys.executable, str(root / "scripts" / "demo_dashboard.py"), "--no-live", "--out", str(tmp_path)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr[-500:]
    page = (tmp_path / "dashboard.html").read_text()
    assert "not</b> the best static placer" in page and "Scorecard" in page
