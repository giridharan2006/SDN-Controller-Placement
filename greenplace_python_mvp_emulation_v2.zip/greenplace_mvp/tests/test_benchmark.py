"""Smoke test of the benchmark harness on a small synthetic topology file."""
import networkx as nx

from greenplace.benchmark import BenchConfig, STATIC_METHODS, run_topology
from greenplace.topology import generate_backbone_like_topology, save_topology_gml


def test_run_topology_produces_complete_consistent_rows(tmp_path):
    g = generate_backbone_like_topology(n_nodes=14, seed=1)
    f = tmp_path / "tiny.gml"
    save_topology_gml(g, f)
    cfg = BenchConfig(seeds=1, nsga_pop=12, nsga_gens=6, mip_time_limit_s=10)
    rows = run_topology(f, cfg)
    methods = {r["method"] for r in rows}
    assert set(STATIC_METHODS) <= methods and "greenplace_no_hysteresis" in methods
    for r in rows:
        assert r["pool_k"] >= r["k_floor"] or r["method"] in ("random",)  # pools must serve peak load
        assert r["avg_energy_w"] > 0 and r["migrations"] >= 0
        assert r["violations"] == 0                                        # delay bound never broken
    by = {r["method"]: r for r in rows}
    # exact MIP is a lower bound on static energy for every feasible heuristic
    for m in STATIC_METHODS:
        if by[m]["static_feasible"]:
            assert by["exact_mip"]["static_energy_w"] <= by[m]["static_energy_w"] + 1e-6


# ---------------------------------------------------------------------------
# simulation-in-the-loop selection
# ---------------------------------------------------------------------------
import pytest

from greenplace.benchmark import BenchConfig, build_set
from greenplace.selection import select_by_simulation
from greenplace.placement import Placement


def _pl(name, energy, feasible=True):
    return Placement(controllers={name}, energy_w=energy, migration_burden=0, feasible=feasible,
                     worst_case_delay_ms=1.0)


def _fake_sim(table):
    """simulate_fn stub: table maps controller-name -> (avg_energy, migrations)."""
    def f(p, pool, capacity, trace):
        e, m = table[next(iter(pool))]
        return {"avg_energy_w": e, "migrations": m}
    return f


def test_sil_picks_fewest_simulated_migrations_within_energy_slack():
    front = [_pl("a", 100), _pl("b", 105), _pl("c", 110)]
    sim = _fake_sim({"a": (500, 40), "b": (505, 10), "c": (530, 2)})     # c has fewest migrations but +6% energy
    pick, _ = select_by_simulation(None, front, 6, [0], energy_slack=0.02, simulate_fn=sim)
    assert next(iter(pick.controllers)) == "b"                           # c is outside the 2% slack
    pick, _ = select_by_simulation(None, front, 6, [0], energy_slack=0.10, simulate_fn=sim)
    assert next(iter(pick.controllers)) == "c"                           # wider slack admits c
    pick, _ = select_by_simulation(None, front, 6, [0], energy_slack=0.0, simulate_fn=sim)
    assert next(iter(pick.controllers)) == "a"                           # zero slack = pure energy


def test_sil_ignores_infeasible_and_returns_none_if_nothing_feasible():
    sim = _fake_sim({"a": (1, 1), "b": (1, 1)})
    assert select_by_simulation(None, [_pl("a", 1, False)], 6, [0], simulate_fn=sim)[0] is None
    pick, _ = select_by_simulation(None, [_pl("a", 1, False), _pl("b", 9)], 6, [0], simulate_fn=sim)
    assert next(iter(pick.controllers)) == "b"


def test_sil_candidate_window_and_cap():
    front = [_pl("a", 100), _pl("b", 200)]                               # b is outside the 1.25x window
    sim = _fake_sim({"a": (500, 50), "b": (400, 0)})
    pick, info = select_by_simulation(None, front, 6, [0], window=1.25, simulate_fn=sim)
    assert next(iter(pick.controllers)) == "a" and info["n_candidates"] == 1


def test_sil_exposes_exploratory_slack_picks():
    front = [_pl("a", 100), _pl("b", 105)]
    sim = _fake_sim({"a": (500, 40), "b": (520, 5)})
    _, info = select_by_simulation(None, front, 6, [0], energy_slack=0.02, simulate_fn=sim, slacks=(0.0, 0.05))
    assert next(iter(info["by_slack"][0.0].controllers)) == "a"
    assert next(iter(info["by_slack"][0.05].controllers)) == "b"


def test_sil_refuses_to_train_on_evaluation_seeds(tmp_path):
    from greenplace import baselines as B
    from greenplace.config import DelayConfig, PowerModel
    from greenplace.delay import DelayEngine
    from greenplace.topology import generate_backbone_like_topology
    g = generate_backbone_like_topology(n_nodes=10, seed=1)
    p = B.Problem(g, DelayEngine(g), PowerModel(), DelayConfig(50.0))
    bad = BenchConfig(seeds=3, sil_train_seeds=(1, 100), nsga_pop=8, nsga_gens=2)   # seed 1 is an evaluation seed
    with pytest.raises(AssertionError):
        build_set("greenplace_sil", p, 4, bad, 0, "pool", 3, capacity=3)


def test_sil_end_to_end_row_schema(tmp_path):
    from greenplace.benchmark import run_topology
    from greenplace.topology import generate_backbone_like_topology, save_topology_gml
    g = generate_backbone_like_topology(n_nodes=14, seed=2)
    f = tmp_path / "t.gml"
    save_topology_gml(g, f)
    cfg = BenchConfig(seeds=1, nsga_pop=12, nsga_gens=4, methods=("greenplace_sil", "nsga2_2obj_sil"),
                      sil_max_candidates=3, include_hysteresis_ablation=False)
    rows = run_topology(f, cfg)
    names = {r["method"] for r in rows}
    assert {"greenplace_sil", "nsga2_2obj_sil"} <= names
    assert all(r["violations"] == 0 for r in rows)
    assert all(r["static_valid"] is False for r in rows if r["method"] in ("greenplace_sil", "nsga2_2obj_sil"))


def test_place_on_topology_cli_runs_and_writes_json(tmp_path):
    import json, subprocess, sys
    from pathlib import Path
    from greenplace.topology import generate_backbone_like_topology, save_topology_gml
    g = generate_backbone_like_topology(n_nodes=14, seed=4)
    f = tmp_path / "net.gml"
    save_topology_gml(g, f)
    out = tmp_path / "res.json"
    script = Path(__file__).resolve().parents[1] / "scripts" / "place_on_topology.py"
    r = subprocess.run([sys.executable, str(script), str(f), "--pop", "12", "--gens", "4", "--out", str(out)],
                       capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr
    d = json.loads(out.read_text())
    assert d["simulation_pick"]["delay_violations"] == 0 and d["proxy_pick"]["pool_size"] >= d["peak_pool_min"]
