from greenplace.config import DelayConfig, PowerModel
from greenplace.delay import DelayEngine
from greenplace.placement import evaluate_placement, worst_case_migration_burden


def test_infeasible_when_delay_bound_too_tight(small_graph):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    tight = DelayConfig(max_switch_to_controller_delay_ms=0.01)
    nodes = list(small_graph.nodes)
    placement = evaluate_placement(small_graph, {nodes[0]}, eng, pm, tight)
    assert placement.feasible is False
    assert placement.violation_ms > 0


def test_feasible_with_loose_bound(small_graph, delay_config_loose):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    nodes = list(small_graph.nodes)
    placement = evaluate_placement(small_graph, {nodes[0]}, eng, pm, delay_config_loose)
    assert placement.feasible is True
    assert placement.violation_ms == 0.0


def test_every_switch_assigned(small_graph, delay_config_loose):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    nodes = list(small_graph.nodes)
    placement = evaluate_placement(small_graph, {nodes[0], nodes[3]}, eng, pm, delay_config_loose)
    assert set(placement.assignment.keys()) == set(small_graph.nodes)


def test_empty_controller_set_is_infeasible(small_graph, delay_config_loose):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    placement = evaluate_placement(small_graph, set(), eng, pm, delay_config_loose)
    assert placement.feasible is False


def test_placement_carries_migration_burden(small_graph, delay_config_loose):
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    nodes = list(small_graph.nodes)
    placement = evaluate_placement(small_graph, {nodes[0], nodes[4]}, eng, pm, delay_config_loose)
    assert placement.migration_burden >= 0


def test_generic_migration_burden_is_max_cluster_size():
    """Without policy context, burden falls back to the largest single-controller cluster."""
    assignment = {1: 0, 2: 0, 3: 0, 4: 5}  # controller 0 has 3 switches, controller 5 has 1
    assert worst_case_migration_burden(assignment) == 3.0


def test_generic_migration_burden_empty_assignment():
    assert worst_case_migration_burden({}) == 0.0


def test_policy_linked_migration_burden_targets_lowest_priority_controller(small_graph, delay_config_loose):
    """With graph/delay_engine/bound supplied, burden should reflect the
    controller the runtime manager's coverage_priority would sleep FIRST,
    not simply whichever controller happens to have the most switches.
    """
    eng = DelayEngine(small_graph)
    pm = PowerModel()
    nodes = list(small_graph.nodes)
    controllers = {nodes[0], nodes[4]}
    placement = evaluate_placement(small_graph, controllers, eng, pm, delay_config_loose)
    # burden must correspond to one of the two controllers' actual load, not an arbitrary number
    counts = {}
    for _sw, c in placement.assignment.items():
        counts[c] = counts.get(c, 0) + 1
    assert placement.migration_burden in counts.values()
