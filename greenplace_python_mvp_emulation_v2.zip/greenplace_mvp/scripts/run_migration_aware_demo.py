"""Demo: does the migration-aware 3rd NSGA-II objective actually matter?

Runs NSGA-II twice on each of several independent (topology, traffic-trace)
seeds — once optimizing only (energy, delay) as in most prior work, once
also optimizing worst-case migration burden (this project's sharpened
contribution) — picks a comparable-energy solution from each front, and
feeds BOTH into the runtime manager over the same trace. Reports migrations
and energy AVERAGED ACROSS SEEDS, not a single run: an earlier version of
this script drew a conclusion from one seed and got misled by noise (a
single run can show either solver "winning" by chance when migration counts
are small integers) — see the writeup in README for that story.

Usage:
    python scripts/run_migration_aware_demo.py [--quick]

    --quick   2 seeds instead of 5, smaller population/generations — a fast
              live-demo pass. The full 5-seed run is more statistically
              convincing; --quick is for demonstrating the mechanism live.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from greenplace.config import DelayConfig, NSGA2Config, PowerModel, RuntimeConfig
from greenplace.delay import DelayEngine
from greenplace.metrics import export_json, plot_pareto_front
from greenplace.nsga2 import run_nsga2
from greenplace.runtime import RuntimeManager, generate_diurnal_trace
from greenplace.topology import generate_backbone_like_topology

OUT_DIR = Path(__file__).resolve().parents[1] / "outputs"

N_NODES = 30
DELAY_BOUND_MS = 6.0
RUNTIME_CFG = RuntimeConfig(controller_capacity=8, timesteps=96, load_ema_alpha=0.3, min_dwell_steps=2)
ENERGY_SLACK = 1.15  # 3-objective pick must stay within 15% of the 2-objective pick's energy


def pick_feasible_lowest_energy(front, delay_slack_ms: float = 1.0):
    feasible = [p for p in front if p.feasible]
    if not feasible:
        return None
    best_delay = min(p.worst_case_delay_ms for p in feasible)
    near_best_delay = [p for p in feasible if p.worst_case_delay_ms <= best_delay + delay_slack_ms]
    return min(near_best_delay, key=lambda p: p.energy_w)


def run_one_seed(seed: int, nsga2_base: dict):
    graph = generate_backbone_like_topology(n_nodes=N_NODES, seed=100 + seed)
    power_model = PowerModel()
    delay_config = DelayConfig(max_switch_to_controller_delay_ms=DELAY_BOUND_MS)
    delay_engine = DelayEngine(graph)

    front_2obj = run_nsga2(graph, delay_engine, power_model, delay_config,
                            NSGA2Config(**nsga2_base, random_seed=seed, optimize_migration=False))
    front_3obj = run_nsga2(graph, delay_engine, power_model, delay_config,
                            NSGA2Config(**nsga2_base, random_seed=seed, optimize_migration=True))

    pick_2obj = pick_feasible_lowest_energy(front_2obj)
    feasible_3obj = [p for p in front_3obj if p.feasible]
    if pick_2obj is None or not feasible_3obj:
        return None  # this seed's topology/bound combination didn't yield a feasible front; skip it

    energy_budget = pick_2obj.energy_w * ENERGY_SLACK
    comparable = [p for p in feasible_3obj if p.energy_w <= energy_budget]
    pick_3obj = min(comparable, key=lambda p: p.migration_burden) if comparable else pick_feasible_lowest_energy(front_3obj)

    trace = generate_diurnal_trace(timesteps=96, seed=seed)
    run_2obj = RuntimeManager(graph, pick_2obj.controllers, power_model, delay_config, RUNTIME_CFG).run(trace)
    run_3obj = RuntimeManager(graph, pick_3obj.controllers, power_model, delay_config, RUNTIME_CFG).run(trace)

    return {
        "seed": seed,
        "pick_2obj": pick_2obj.summary(),
        "pick_3obj": pick_3obj.summary(),
        "migrations_2obj": sum(r.migrations for r in run_2obj),
        "migrations_3obj": sum(r.migrations for r in run_3obj),
        "avg_energy_2obj": sum(r.energy_w for r in run_2obj) / len(run_2obj),
        "avg_energy_3obj": sum(r.energy_w for r in run_3obj) / len(run_3obj),
        "violations_2obj": sum(1 for r in run_2obj if not r.feasible),
        "violations_3obj": sum(1 for r in run_3obj if not r.feasible),
        "front_2obj_size": len(front_2obj),
        "front_3obj_size": len(front_3obj),
        "front_3obj_for_plot": front_3obj if seed == 0 else None,  # only keep one for the plot
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true", help="2 seeds + smaller NSGA-II settings for a fast demo.")
    args = parser.parse_args()

    n_seeds = 2 if args.quick else 5
    nsga2_base = dict(population_size=30, generations=40, k_min=3, k_max=10) if args.quick \
        else dict(population_size=60, generations=100, k_min=3, k_max=10)

    print(f"Running {n_seeds} independent (topology, trace) seeds"
          f"{' (quick mode)' if args.quick else ' — this takes a minute or two'}...\n")
    all_results = []
    for seed in range(n_seeds):
        r = run_one_seed(seed, nsga2_base)
        if r is None:
            print(f"seed {seed}: skipped (no feasible front at this delay bound/k_max)")
            continue
        print(f"seed {seed}: 2obj migrations={r['migrations_2obj']:3d} energy={r['avg_energy_2obj']:7.1f}W  "
              f"| 3obj migrations={r['migrations_3obj']:3d} energy={r['avg_energy_3obj']:7.1f}W")
        all_results.append(r)

    if not all_results:
        print("No feasible seeds — widen the delay bound or raise k_max and retry.")
        return

    n = len(all_results)
    avg_mig_2obj = sum(r["migrations_2obj"] for r in all_results) / n
    avg_mig_3obj = sum(r["migrations_3obj"] for r in all_results) / n
    avg_energy_2obj = sum(r["avg_energy_2obj"] for r in all_results) / n
    avg_energy_3obj = sum(r["avg_energy_3obj"] for r in all_results) / n
    wins = sum(1 for r in all_results if r["migrations_3obj"] <= r["migrations_2obj"])
    total_violations = sum(r["violations_2obj"] + r["violations_3obj"] for r in all_results)

    print(f"\n=== Averaged across {n} seeds ===")
    print(f"  Avg runtime migrations : 2obj={avg_mig_2obj:.1f}   3obj={avg_mig_3obj:.1f}   "
          f"({'-' if avg_mig_2obj == 0 else f'{100*(avg_mig_2obj-avg_mig_3obj)/avg_mig_2obj:+.1f}%'})")
    print(f"  Avg runtime energy     : 2obj={avg_energy_2obj:.1f}W   3obj={avg_energy_3obj:.1f}W")
    print(f"  Seeds where 3obj <= 2obj on migrations: {wins}/{n}")
    print(f"  Delay-bound violations across all runs: {total_violations} (must be 0)")
    assert total_violations == 0, "Delay bound was violated — this should never happen by construction."

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    plot_pareto_front(
        all_results[0]["front_3obj_for_plot"],
        title=f"{N_NODES}-node topology (seed 0): GreenPlace (migration-aware NSGA-II)",
        out_path=OUT_DIR / "pareto_migration_aware.png", color_by_migration=True,
        series_label="GreenPlace (migration-aware NSGA-II)",
    )
    export_json(
        {
            "config": {"n_seeds": n_seeds, "n_nodes": N_NODES, "delay_bound_ms": DELAY_BOUND_MS,
                       "nsga2": nsga2_base, "runtime": RUNTIME_CFG.to_dict(), "quick_mode": args.quick},
            "per_seed": [{k: v for k, v in r.items() if k != "front_3obj_for_plot"} for r in all_results],
            "summary": {
                "avg_migrations_2obj": avg_mig_2obj, "avg_migrations_3obj": avg_mig_3obj,
                "avg_energy_2obj": avg_energy_2obj, "avg_energy_3obj": avg_energy_3obj,
                "seeds_3obj_better_or_equal": wins, "n_seeds": n,
            },
        },
        OUT_DIR / "migration_aware_comparison.json",
    )
    print(f"\nPlot and JSON written to {OUT_DIR}")


if __name__ == "__main__":
    main()
