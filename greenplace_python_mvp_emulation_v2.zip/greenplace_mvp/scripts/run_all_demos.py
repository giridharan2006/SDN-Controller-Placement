"""GreenPlace — run the entire demo pipeline in one command.

This is the single script to run for a live demonstration. It runs, in
order: topology generation, the exact-ILP-vs-NSGA-II validation, the
runtime elastic-manager demo, and the migration-aware-objective comparison
— then prints one consolidated summary table pulling the real numbers back
out of the JSON files each stage just wrote (not hardcoded), so the summary
can never drift from what actually ran.

Usage:
    python scripts/run_all_demos.py            # full run (~2-3 minutes)
    python scripts/run_all_demos.py --quick     # fast pass for a live demo (~30-60s)

Every stage can also be run individually — see README.md.
"""
import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs"
PY = sys.executable

STAGES = [
    ("Generate topology fixtures", "generate_topologies.py", False),
    ("Phase 1: ILP vs. NSGA-II validation", "run_ilp_vs_nsga2.py", True),
    ("Phase 1 -> Phase 2: runtime elastic manager", "run_runtime_demo.py", True),
    ("Migration-aware objective (multi-seed)", "run_migration_aware_demo.py", True),
]


def banner(text: str) -> None:
    line = "=" * 78
    print(f"\n{line}\n  {text}\n{line}")


def run_stage(label: str, script: str, quick: bool, quick_flag: bool) -> float:
    banner(label)
    cmd = [PY, str(ROOT / "scripts" / script)]
    if quick_flag and quick:
        cmd.append("--quick")
    t0 = time.perf_counter()
    result = subprocess.run(cmd, cwd=ROOT)
    elapsed = time.perf_counter() - t0
    if result.returncode != 0:
        print(f"\n[FAILED] {script} exited with code {result.returncode} after {elapsed:.1f}s")
        sys.exit(result.returncode)
    print(f"\n[done in {elapsed:.1f}s]")
    return elapsed


def load_json(path: Path):
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def print_final_summary(total_elapsed: float) -> None:
    banner("FINAL SUMMARY (read back from the JSON each stage wrote)")

    # --- Phase 1: exact vs NSGA-II ---
    gaps = []
    for name in ["tiny_4node", "small_8node", "small_10node"]:
        data = load_json(OUT_DIR / f"result_{name}.json")
        if data:
            gaps.append((name, data["gap_pct"]))
    if gaps:
        print("\nPhase 1 — NSGA-II vs. exact ILP (validation topologies):")
        for name, gap in gaps:
            print(f"    {name:15s}  gap = {gap:+.2f}%")

    # --- Phase 1 -> 2: runtime savings ---
    rt = load_json(OUT_DIR / "summary_runtime.json")
    if rt:
        print("\nPhase 2 — runtime elastic manager (96 timesteps, 2 synthetic days):")
        print(f"    Always-on baseline energy   : {rt['always_on_energy_w']:.1f} W")
        print(f"    Average managed energy      : {rt['avg_managed_energy_w']:.1f} W")
        print(f"    Average energy savings      : {rt['savings_pct']:.1f}%")
        print(f"    Active controllers (min/max): {rt['min_active_controllers']} / {rt['max_active_controllers']}")
        print(f"    Total switch migrations     : {rt['total_migrations']}")
        print(f"    Delay-bound violations      : {rt['delay_violations']} (must be 0)")

    # --- Migration-aware objective ---
    ma = load_json(OUT_DIR / "migration_aware_comparison.json")
    if ma:
        s = ma["summary"]
        print(f"\nMigration-aware objective ({s['n_seeds']} seeds):")
        print(f"    Avg. migrations, energy/delay-only NSGA-II : {s['avg_migrations_2obj']:.1f}")
        print(f"    Avg. migrations, migration-aware NSGA-II   : {s['avg_migrations_3obj']:.1f}")
        if s["avg_migrations_2obj"] > 0:
            reduction = 100 * (s["avg_migrations_2obj"] - s["avg_migrations_3obj"]) / s["avg_migrations_2obj"]
            print(f"    Reduction from adding migration awareness  : {reduction:+.1f}%")
        print(f"    Seeds where migration-aware <= baseline    : {s['seeds_3obj_better_or_equal']}/{s['n_seeds']}")

    print(f"\nAll plots, CSVs, and JSON results are in: {OUT_DIR}")
    print(f"Total pipeline runtime: {total_elapsed:.1f}s")
    print("\n" + "=" * 78)
    print("  Every number above was regenerated just now, from a fixed random seed.")
    print("  Nothing here is hardcoded or copy-pasted from an earlier run.")
    print("=" * 78)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--with-benchmark", action="store_true",
                         help="Also run the real-topology benchmark vs. existing approaches "
                              "(quick settings, ~5 min) and write its report.")
    parser.add_argument("--quick", action="store_true",
                         help="Faster settings on every stage (~30-60s total instead of ~2-3 min). "
                              "Good for a live demo; run without --quick beforehand if you want the "
                              "fully-converged numbers cited in the project documentation.")
    args = parser.parse_args()

    banner("GREENPLACE — FULL DEMO PIPELINE" + ("  [QUICK MODE]" if args.quick else ""))
    print("Energy-Efficient SDN Controller Placement Under Delay Constraints")
    print(f"Python: {sys.version.split()[0]}   Working directory: {ROOT}")

    t_start = time.perf_counter()
    for label, script, quick_flag in STAGES:
        run_stage(label, script, args.quick, quick_flag)
    if args.with_benchmark:
        run_stage("Real-topology benchmark vs. existing approaches (quick)", "run_benchmark.py", True, True)
        banner("Benchmark analysis")
        subprocess.run([PY, str(ROOT / "scripts" / "analyze_benchmark.py"), "--tag", "quick"], cwd=ROOT, check=False)
    total_elapsed = time.perf_counter() - t_start

    print_final_summary(total_elapsed)


if __name__ == "__main__":
    main()
