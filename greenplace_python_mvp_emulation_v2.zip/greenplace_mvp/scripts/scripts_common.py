import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from greenplace.topology import load_zoo_topology


def discover(topo_dir: Path, lo: int, hi: int, names=None):
    out = []
    for f in sorted(topo_dir.glob("*.gml")):
        if names and f.stem not in names:
            continue
        try:
            _, meta = load_zoo_topology(f)
        except Exception as e:
            print(f"  skip {f.stem}: {e}")
            continue
        if lo <= meta["n"] <= hi:
            out.append((meta["n"], f))
    out.sort(key=lambda x: (x[0], x[1].stem))
    return [f for _, f in out]
