"""Run the Mininet + OVS + Ryu emulation (needs root). Thin wrapper around `python -m emulation.runner`.

    sudo -E python3 scripts/run_emulation.py --topology Abilene Nsfnet --traces diurnal:0 bursty:0
See emulation/README.md.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from emulation.runner import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
