"""Analyse the extended study (outputs/study3/<tag>) -> results.json + CSV tables + figures.

Unit of analysis: the TOPOLOGY (seed-means), so n = number of networks (paired tests, no pseudo-replication).
Families of tests are Holm-corrected. Effect sizes: mean paired % difference with a percentile-bootstrap 95% CI
(10,000 resamples of topologies) and Cliff's delta. Everything not pre-specified is labelled exploratory.
"""
import argparse, glob, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SCEN = ("diurnal", "two_peak", "flash_crowd", "bursty", "trend", "noisy", "geant", "abilene")
SHIFT = SCEN[1:]
RNG = np.random.default_rng(12345)
P_C = 150.0


def load(tag, root):
    d = Path(root) / tag
    rd = lambda n: pd.concat([pd.read_json(f, lines=True) for f in sorted(glob.glob(str(d / f"{n}_shard*.jsonl")))], ignore_index=True)
    return rd("rows"), rd("cands"), rd("quality")


def holm(ps):
    ps = np.asarray(ps, float); order = np.argsort(ps); m = len(ps); out = np.empty(m); run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * ps[i]); out[i] = min(1.0, run)
    return out


def cliff(x, y):
    x, y = np.asarray(x), np.asarray(y)
    gt = (x[:, None] > y[None, :]).sum(); lt = (x[:, None] < y[None, :]).sum()
    return float((gt - lt) / (len(x) * len(y)))


def boot_ci(v, B=10000):
    v = np.asarray(v, float)
    if len(v) < 3:
        return (float("nan"), float("nan"))
    bs = RNG.choice(v, size=(B, len(v)), replace=True).mean(1)
    return (float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5)))


def topo_means(df, method, col):
    s = df[df.method == method].groupby("name")[col].mean()
    return s


def paired(df, a, b, col, lower_better=True):
    """a vs b on per-topology seed-means. Returns dict (negative pct => a lower than b)."""
    x, y = topo_means(df, a, col), topo_means(df, b, col)
    idx = x.index.intersection(y.index); x, y = x[idx].values, y[idx].values
    out = {"a": a, "b": b, "col": col, "n": int(len(idx)), "mean_a": float(x.mean()) if len(x) else float("nan"),
           "mean_b": float(y.mean()) if len(y) else float("nan")}
    if len(x) == 0:
        return out
    pct = np.where(y != 0, (x - y) / np.where(y == 0, 1, y) * 100, 0.0)
    out["pct_mean"] = float(pct.mean()); out["pct_median"] = float(np.median(pct)); out["pct_ci"] = boot_ci(pct)
    out["diff_mean"] = float((x - y).mean())
    out["wins"] = int((x < y - 1e-9).sum()); out["ties"] = int((abs(x - y) <= 1e-9).sum()); out["losses"] = int((x > y + 1e-9).sum())
    out["cliffs_delta"] = cliff(x, y)
    d = x - y
    if len(x) >= 6 and np.any(d != 0):
        try:
            out["p"] = float(stats.wilcoxon(x, y, zero_method="wilcox").pvalue)
        except ValueError:
            out["p"] = 1.0
    else:
        out["p"] = 1.0
    return out


def family(df, pairs, col):
    res = [paired(df, a, b, col) for a, b in pairs]
    adj = holm([r.get("p", 1.0) for r in res])
    for r, q in zip(res, adj):
        r["p_holm"] = float(q)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="main")
    ap.add_argument("--root", default=str(ROOT / "outputs" / "study3"))
    a = ap.parse_args()
    rows, cands, qual = load(a.tag, a.root)
    out_dir = Path(a.root) / a.tag; (out_dir / "tables").mkdir(exist_ok=True)
    R = {"n_topologies": int(rows.name.nunique()), "n_seeds": int(rows.seed.nunique()),
         "topologies_n_range": [int(rows.n.min()), int(rows.n.max())]}
    main_rows = rows[rows.method != "greenplace_no_hysteresis"]

    # ---------------- 1. static quality (MIP-relative) ----------------
    st = main_rows[main_rows.static_valid == True].copy()
    st_all = st.copy()
    st = st[st.static_feasible == True]            # gap is only meaningful for feasible placements; infeasible counted separately
    lbf = out_dir / "mip_lb.json"
    if not lbf.exists():   # smoke runs reuse the shipped bound of the main study
        lbf = out_dir.parent / "main" / "mip_lb.json"
    lbj = json.loads(lbf.read_text())
    mip = pd.Series({k: v["lb_energy_w"] for k, v in lbj.items()})      # free-assignment MIP optimum = lower bound
    st["mip"] = st.name.map(mip)
    st["gap_pct"] = (st.static_energy_w - st.mip) / st.mip * 100
    tab = []
    for m, g in st.groupby("method"):
        tab.append({"method": m, "gap_mean_pct": g.groupby("name").gap_pct.mean().mean(),
                    "gap_median_pct": g.groupby("name").gap_pct.mean().median(),
                    "infeasible_topologies": int((st_all[st_all.method == m].groupby("name").static_feasible.mean() < 1).sum()),
                    "optimal_topologies": int((g.groupby("name").gap_pct.mean().abs() < 1e-6).sum()),   # reaches the lower bound exactly
                    "runtime_s": g.t_static_s.mean(skipna=True)})
    R["static"] = sorted(tab, key=lambda r: r["gap_mean_pct"])
    mip_status = main_rows[(main_rows.method == "exact_mip")].mip_status.value_counts().to_dict()
    R["mip_status_counts"] = mip_status
    ms = st[st.method == "exact_mip"].groupby("name").static_energy_w.mean()
    best_h = st[~st.method.isin(["exact_mip"])].groupby("name").static_energy_w.min()
    R["mip_set_vs_best_heuristic"] = {"n_heuristic_beats_mip_set": int(((ms - best_h) > 1e-6).sum()), "n": int(len(ms)),
                                      "max_excess_pct": float(((ms - best_h) / best_h * 100).max()),
                                      "mip_set_gap_to_lb_mean_pct": float(((ms - mip.reindex(ms.index)) / mip.reindex(ms.index) * 100).mean()),
                                      "all_optimal": bool(all(v["status"] == "Optimal" for v in lbj.values()))}

    # ---------------- 2. lifecycle on diurnal (selection distribution) ----------------
    life = []
    for m, g in main_rows.groupby("method"):
        r = {"method": m, "n_topologies": int(g.name.nunique())}
        for k in ("avg_energy_w", "migrations", "violations", "state_changes", "avg_active"):
            r[k] = g.groupby("name")[f"diurnal__{k}"].mean().mean()
        r["pool_static_energy_w"] = g.groupby("name").pool_static_energy_w.mean().mean()
        r["elastic_saving_pct"] = (1 - r["avg_energy_w"] / r["pool_static_energy_w"]) * 100
        life.append(r)
    R["lifecycle_diurnal"] = sorted(life, key=lambda r: r["migrations"])

    D = lambda c: f"diurnal__{c}"
    core = ["nsga2_2obj", "exact_mip", "nsga3", "mopso", "enplace", "greedy_cover", "greco", "ga_energy", "k_median", "k_center", "betweenness", "random"]
    R["tests_gp_vs_baselines_migrations"] = family(main_rows, [("greenplace", b) for b in core], D("migrations"))
    R["tests_gp_vs_baselines_energy"] = family(main_rows, [("greenplace", b) for b in core], D("avg_energy_w"))
    R["tests_gp_vs_baselines_violations"] = family(main_rows, [("greenplace", b) for b in core], D("violations"))

    # ---------------- 3. component ablation ----------------
    abl = [("nsga2_2obj_migsel", "nsga2_2obj"), ("greenplace", "nsga2_2obj_migsel"), ("greenplace_energypick", "nsga2_2obj"),
           ("greenplace", "greenplace_energypick"), ("greenplace", "nsga2_2obj"), ("greenplace_sil", "greenplace"),
           ("greenplace", "greenplace_no_hysteresis")]
    R["ablation_migrations"] = family(rows, abl, D("migrations"))
    R["ablation_energy"] = family(rows, abl, D("avg_energy_w"))
    R["tests_sil"] = family(main_rows, [("greenplace_sil", "greenplace"), ("greenplace_sil", "nsga2_2obj"), ("greenplace_sil", "exact_mip")], D("migrations"))
    R["tests_sil_energy"] = family(main_rows, [("greenplace_sil", "greenplace"), ("greenplace_sil", "nsga2_2obj"), ("greenplace_sil", "exact_mip")], D("avg_energy_w"))
    # simulated-migration NSGA-II: matched-topology subset
    sim_topos = set(main_rows[main_rows.method == "simnsga"].name)
    sub = main_rows[main_rows.name.isin(sim_topos) & main_rows.seed.isin(sorted(main_rows[main_rows.method == "simnsga"].seed.unique()))]
    sim_m = [m for m in ("simnsga", "simnsga_sil") if (sub.method == m).any()]
    R["simnsga_subset"] = {"n_topologies": len(sim_topos),
                           "tests_migrations": family(sub, [(m, b) for m in sim_m for b in ("greenplace", "greenplace_sil", "nsga2_2obj", "exact_mip")], D("migrations")),
                           "tests_energy": family(sub, [(m, b) for m in sim_m for b in ("greenplace", "greenplace_sil", "nsga2_2obj", "exact_mip")], D("avg_energy_w")),
                           "means": {m: {"migrations": float(topo_means(sub, m, D("migrations")).mean()), "energy": float(topo_means(sub, m, D("avg_energy_w")).mean())}
                                     for m in ("simnsga", "simnsga_sil", "greenplace", "greenplace_sil", "nsga2_2obj", "exact_mip") if (sub.method == m).any()},
                           "runtime_s": float(sub[sub.method == "simnsga"].t_pool_s.mean()), "runtime_nsga2_s": float(sub[sub.method == "greenplace"].t_pool_s.mean())}

    # ---------------- 4. distribution shift / real traces ----------------
    shift = []
    focus = ["greenplace", "greenplace_sil", "nsga2_2obj", "exact_mip", "nsga3", "mopso", "greedy_cover", "enplace"]
    for sc in SCEN:
        row = {"scenario": sc}
        for m in focus:
            row[f"{m}_migs"] = float(topo_means(main_rows, m, f"{sc}__migrations").mean())
            row[f"{m}_energy"] = float(topo_means(main_rows, m, f"{sc}__avg_energy_w").mean())
            row[f"{m}_viol"] = float(topo_means(main_rows, m, f"{sc}__violations").mean())
        t1 = paired(main_rows, "greenplace", "nsga2_2obj", f"{sc}__migrations"); t2 = paired(main_rows, "greenplace", "exact_mip", f"{sc}__migrations")
        t3 = paired(main_rows, "greenplace", "nsga2_2obj", f"{sc}__avg_energy_w")
        row.update(gp_vs_nsga2_migs_pct=t1.get("pct_mean"), gp_vs_nsga2_migs_ci=t1.get("pct_ci"), gp_vs_nsga2_p=t1.get("p"),
                   gp_vs_mip_migs_pct=t2.get("pct_mean"), gp_vs_mip_p=t2.get("p"), gp_vs_nsga2_energy_pct=t3.get("pct_mean"), gp_vs_nsga2_energy_p=t3.get("p"))
        # elasticity saving vs always-on pool (greenplace)
        g = main_rows[main_rows.method == "greenplace"]
        row["gp_elastic_saving_pct"] = float((1 - g.groupby("name")[f"{sc}__avg_energy_w"].mean() / g.groupby("name").pool_static_energy_w.mean()).mean() * 100)
        shift.append(row)
    adj = holm([r["gp_vs_nsga2_p"] for r in shift if r["gp_vs_nsga2_p"] is not None])
    for r, q in zip(shift, adj):
        r["gp_vs_nsga2_p_holm"] = float(q)
    R["shift"] = shift

    # ---------------- 5. transition / migration cost sweep ----------------
    STEP_S, STEPS = 900.0, 96
    sweep = []
    for tau in (0, 30, 120, 300, 900):          # seconds of full controller power burnt per sleep/wake event
        for nu in (0, 1, 5):                    # seconds of controller power per migrated switch
            row = {"boot_s": tau, "mig_s": nu}
            for m in ("greenplace", "nsga2_2obj", "exact_mip", "greenplace_sil"):
                g = main_rows[main_rows.method == m]
                eff = g[D("avg_energy_w")] + P_C * (tau * g[D("state_changes")] + nu * g[D("migrations")]) / (STEPS * STEP_S)
                tmp = g.assign(eff=eff)
                row[m] = float(tmp.groupby("name").eff.mean().mean())
                row[f"{m}_vs_alwayson_pct"] = float(((tmp.groupby("name").eff.mean() / g.groupby("name").pool_static_energy_w.mean()) - 1).mean() * 100)
            e1 = main_rows[main_rows.method == "greenplace"]; e2 = main_rows[main_rows.method == "nsga2_2obj"]
            f = lambda g: (g[D("avg_energy_w")] + P_C * (tau * g[D("state_changes")] + nu * g[D("migrations")]) / (STEPS * STEP_S)).groupby(g.name).mean()
            x, y = f(e1), f(e2); pct = ((x - y) / y * 100).values
            row["gp_vs_nsga2_pct"] = float(pct.mean()); row["gp_vs_nsga2_ci"] = boot_ci(pct)
            try:
                row["gp_vs_nsga2_p"] = float(stats.wilcoxon(x, y).pvalue)
            except ValueError:
                row["gp_vs_nsga2_p"] = 1.0
            sweep.append(row)
    R["transition_sweep"] = sweep

    # ---------------- 6. power-model sensitivity ----------------
    ps = []
    for pl in (1.0, 2.5, 5.0, 10.0, 25.0):         # link W/hop (default 5; controller fixed 150 W)
        for idle in (0.0, 0.1, 0.3):               # sleeping-controller power as fraction of active
            row = {"p_link_w": pl, "idle_frac": idle}
            def eff(g):
                link_part = g[D("avg_energy_w")] - P_C * g[D("avg_active")]
                return P_C * g[D("avg_active")] + link_part * (pl / 5.0) + idle * P_C * (g.pool_k - g[D("avg_active")])
            for m in ("greenplace", "nsga2_2obj", "exact_mip"):
                g = main_rows[main_rows.method == m]; row[m] = float(eff(g).groupby(g.name).mean().mean())
            g1 = main_rows[main_rows.method == "greenplace"]; g2 = main_rows[main_rows.method == "nsga2_2obj"]
            x, y = eff(g1).groupby(g1.name).mean(), eff(g2).groupby(g2.name).mean()
            row["gp_vs_nsga2_energy_pct"] = float(((x - y) / y * 100).mean())
            # elastic saving of GreenPlace vs its own always-on pool under this power model
            ao = (P_C * g1.pool_k + (g1.pool_static_energy_w - P_C * g1.pool_k) * (pl / 5.0))
            row["gp_elastic_saving_pct"] = float((1 - eff(g1).groupby(g1.name).mean() / ao.groupby(g1.name).mean()).mean() * 100)
            ps.append(row)
    R["power_sensitivity"] = ps

    # ---------------- 7. front quality (HV / IGD) ----------------
    qual = qual.assign(igd=qual.igd.replace([np.inf], 2.0))      # empty feasible front -> penalty 2.0 (> sqrt(3)*1.1)
    qual["is_empty"] = (qual.front_n == 0)
    qt = []
    for mode in ("pool", "static"):
        q = qual[qual["mode"] == mode]
        for algo, g in q.groupby("algo"):
            qt.append({"mode": mode, "algo": algo, "hv": float(g.groupby("name").hv.mean().mean()), "igd": float(g.groupby("name").igd.mean().mean()),
                       "front_n": float(g.groupby("name").front_n.mean().mean()), "empty_front_frac": float(g.is_empty.mean())})
    R["quality"] = qt
    qtests = []
    for mode in ("pool", "static"):
        q = qual[qual["mode"] == mode].rename(columns={"algo": "method"})
        for col, lower in (("hv", False), ("igd", True)):
            fam = family(q, [("greenplace", b) for b in ("nsga2_2obj", "nsga3", "mopso")], col)
            for r in fam:
                r["mode"] = mode
            qtests += fam
    R["quality_tests"] = qtests

    # ---------------- 8. candidate-table selector study (learned surrogate) ----------------
    R["selector"] = selector_study(cands)

    # ---------------- 9. pareto-count among all methods (diurnal; energy, migrations) ----------------
    cnt, tot = {}, 0
    meths = [m for m in main_rows.method.unique() if m not in ("simnsga", "simnsga_sil")]
    for nm, g in main_rows[main_rows.method.isin(meths)].groupby("name"):
        mm = g.groupby("method")[[D("avg_energy_w"), D("migrations")]].mean()
        tot += 1
        for m, (e, mg) in mm.iterrows():
            dom = ((mm[D("avg_energy_w")] <= e + 1e-9) & (mm[D("migrations")] <= mg + 1e-9) &
                   ((mm[D("avg_energy_w")] < e - 1e-9) | (mm[D("migrations")] < mg - 1e-9))).any()
            cnt[m] = cnt.get(m, 0) + (0 if dom else 1)
    R["pareto_counts"] = {"n_topologies": tot, "n_methods": len(meths), "nondominated": dict(sorted(cnt.items(), key=lambda kv: -kv[1]))}

    def clean(o):
        if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)): return [clean(v) for v in o]
        if isinstance(o, (np.floating, np.integer)): o = o.item()
        if isinstance(o, float) and not np.isfinite(o): return None
        return o
    (out_dir / "results.json").write_text(json.dumps(clean(R), indent=1, default=str))
    for k in ("static", "lifecycle_diurnal", "shift", "transition_sweep", "power_sensitivity", "quality"):
        pd.DataFrame(R[k]).to_csv(out_dir / "tables" / f"{k}.csv", index=False)
    print("wrote", out_dir / "results.json")


def selector_study(c):
    from sklearn.ensemble import GradientBoostingRegressor
    feats = ["burden", "e_ratio", "k_over_floor", "delay_ms", "energy_w", "k", "n", "capacity"]
    c = c.copy()
    c["group"] = c["name"] + "#" + c.seed.astype(str)
    names = sorted(c.name.unique())
    # leave-one-topology-out surrogate predicting simulated migrations & energy on the SELECTION trace (diurnal, eval seed)
    c["pred_migs"] = np.nan; c["pred_energy"] = np.nan
    if len(names) >= 4:
        for nm in names:
            tr, te = c[c.name != nm], c[c.name == nm]
            for tgt, col in (("migs_diurnal", "pred_migs"), ("energy_diurnal", "pred_energy")):
                y = tr[tgt] / tr.k_floor if tgt.startswith("migs") else tr[tgt] / tr.energy_w
                mdl = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0).fit(tr[feats], y)
                pr = mdl.predict(te[feats])
                c.loc[te.index, col] = pr * (te.k_floor if tgt.startswith("migs") else te.energy_w)
    rules = {}
    def sel(g, rule):
        if rule == "min_energy": return g.loc[g.e_ratio.idxmin()]
        if rule == "proxy":
            ok = g[g.e_ratio <= 1.15]; return ok.loc[ok.burden.idxmin()] if len(ok) else g.loc[g.e_ratio.idxmin()]
        if rule == "sil":
            best = g.train_energy.min(); ok = g[g.train_energy <= best * 1.02]; return ok.loc[ok.train_migs.idxmin()]
        if rule == "surrogate":
            if g.pred_migs.isna().any(): return None
            best = g.pred_energy.min(); ok = g[g.pred_energy <= best * 1.02]; return ok.loc[ok.pred_migs.idxmin()]
        if rule == "oracle":
            best = g.energy_diurnal.min(); ok = g[g.energy_diurnal <= best * 1.02]; return ok.loc[ok.migs_diurnal.idxmin()]
        if rule == "random": return g.sample(1, random_state=0).iloc[0]
    out = {}
    for rule in ("min_energy", "proxy", "sil", "surrogate", "oracle", "random"):
        recs = []
        for gname, g in c.groupby("group"):
            s = sel(g, rule)
            if s is None: continue
            rec = {"name": g["name"].iloc[0]}
            for sc in ("diurnal",) + SHIFT:
                rec[f"migs_{sc}"] = s[f"migs_{sc}"]; rec[f"energy_{sc}"] = s[f"energy_{sc}"]
            rec["migs_shift"] = np.mean([s[f"migs_{sc}"] for sc in SHIFT]); rec["energy_shift"] = np.mean([s[f"energy_{sc}"] for sc in SHIFT])
            recs.append(rec)
        if not recs: continue
        df = pd.DataFrame(recs)
        out[rule] = df.groupby("name").mean(numeric_only=True)
    res = {"n_groups": int(c.group.nunique()), "n_candidates": int(len(c)), "rules": {}}
    rhos = {}
    for gname, g in c.groupby("group"):
        if len(g) >= 4 and g.burden.nunique() > 1 and g.migs_diurnal.nunique() > 1:
            rhos.setdefault(g["name"].iloc[0], []).append(stats.spearmanr(g.burden, g.migs_diurnal)[0])
    rv = np.array([np.mean(v) for v in rhos.values()])
    res["proxy_rho"] = {"mean": float(rv.mean()), "ci": boot_ci(rv), "n_topologies": int(len(rv))}
    for rule, df in out.items():
        res["rules"][rule] = {"migs_diurnal": float(df.migs_diurnal.mean()), "energy_diurnal": float(df.energy_diurnal.mean()),
                              "migs_shift": float(df.migs_shift.mean()), "energy_shift": float(df.energy_shift.mean())}
    tests = []
    for a_, b_ in (("sil", "proxy"), ("surrogate", "proxy"), ("surrogate", "sil"), ("proxy", "min_energy"), ("sil", "min_energy"), ("surrogate", "min_energy")):
        for metric in ("migs_diurnal", "migs_shift", "energy_diurnal"):
            if a_ not in out or b_ not in out: continue
            idx = out[a_].index.intersection(out[b_].index)
            if len(idx) < 6: continue
            x, y = out[a_].loc[idx, metric].values, out[b_].loc[idx, metric].values
            pct = (x - y) / np.where(y == 0, 1, y) * 100
            try: p = float(stats.wilcoxon(x, y).pvalue)
            except ValueError: p = 1.0
            tests.append({"a": a_, "b": b_, "metric": metric, "pct_mean": float(pct.mean()), "pct_ci": boot_ci(pct), "p": p})
    adj = holm([t["p"] for t in tests]) if tests else []
    for t, q in zip(tests, adj): t["p_holm"] = float(q)
    res["tests"] = tests
    return res


if __name__ == "__main__":
    main()
