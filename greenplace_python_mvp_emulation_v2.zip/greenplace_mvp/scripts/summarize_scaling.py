"""Summarise outputs/scaling/rows.json -> summary.json. Gap = (energy - MIP lower bound)/lower bound, where the lower
bound is the free-assignment MIP objective (a valid bound for nearest-assignment energy). Where the MIP hit its time limit
the bound is NOT proven; 'gap' is then relative to the best incumbent and is flagged."""
import json, sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
d = pd.DataFrame(json.loads((ROOT / "outputs" / "scaling" / "rows.json").read_text()))
unc = ROOT / "outputs" / "scaling" / "rows_mip_uncapped.json"
if unc.exists():            # replace the k_max-capped MIP by the uncapped one (valid lower bound for any placement size)
    d = pd.concat([d[d.method != "exact_mip"], pd.DataFrame(json.loads(unc.read_text()))], ignore_index=True)
hint = ROOT / "outputs" / "scaling" / "rows_hint.json"
H = pd.DataFrame(json.loads(hint.read_text())) if hint.exists() else pd.DataFrame()
d["inst"] = d.name.str.replace(r"_s\d", "", regex=True)
lb = d[d.method == "exact_mip"].set_index("name").lb
d["lb"] = d.name.map(lb)
d["gap"] = (d.energy / d.lb - 1) * 100
if len(H):
    H["inst"] = H.name.str.replace(r"_s\d", "", regex=True)
    H["lb"] = H.name.map(lb)
    H["gap"] = (H.energy / H.lb - 1) * 100
rows = []
for inst, g in d.groupby("inst"):
    mp = g[g.method == "exact_mip"]
    r = {"instance": inst, "kind": g.kind.iloc[0], "n": int(g.n.iloc[0]), "mip_status": ";".join(sorted(set(mp.status.astype(str)))),
         "mip_secs": float(mp.secs.mean()), "mip_set_gap": float(mp.gap.mean())}
    for m in ("enplace", "nsga2_2obj", "nsga3", "greenplace", "greedy_cover", "greco"):
        x = g[g.method == m]; r[m + "_gap"] = float(x.gap.mean()); r[m + "_secs"] = float(x.secs.mean())
    if len(H):
        h = H[H.inst == inst]
        for m in ("nsga2_2obj", "greenplace", "nsga3"):
            x = h[h.method == m]
            if len(x): r[m + "_hint_gap"] = float(x.gap.mean()); r[m + "_hint_secs"] = float(x.secs.mean()); r[m + "_hint_k"] = float(x.k.mean())
    rows.append(r)
rows.sort(key=lambda r: r["n"])
(ROOT / "outputs" / "scaling" / "summary.json").write_text(json.dumps({"rows": rows, "mip_limit_s": 60, "all_feasible": bool(d.feasible.all())}, indent=1))
for r in rows: print(r["instance"], r["n"], r["mip_status"], round(r["mip_secs"]), *(round(r[m + "_gap"], 1) for m in ("enplace", "nsga2_2obj", "greenplace")), round(r["mip_set_gap"], 1))
