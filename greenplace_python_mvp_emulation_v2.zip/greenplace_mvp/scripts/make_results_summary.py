"""Write outputs/study3/<tag>/RESULTS_SUMMARY.md from results.json (+ scaling summary) so docs never hand-copy numbers."""
import argparse, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser(); ap.add_argument("--tag", default="main"); a = ap.parse_args()
d = ROOT / "outputs" / "study3" / a.tag
R = json.loads((d / "results.json").read_text())
sp = ROOT / "outputs" / "scaling" / "summary.json"
SC = json.loads(sp.read_text()) if sp.exists() else None
f = lambda x, n=1: f"{x:.{n}f}"
def p(x): return "<0.001" if x < 0.001 else f"{x:.3f}"
L = {r["method"]: r for r in R["lifecycle_diurnal"]}
out = [f"# GreenPlace study v3 - results summary (auto-generated)\n",
       f"{R['n_topologies']} Topology Zoo networks, {R['n_seeds']} seeds, 8 traffic scenarios. Unit of analysis = topology (seed means); Holm-adjusted p within families.\n",
       "## Static placement: gap to the MIP lower bound (free-assignment optimum)\n", "| method | mean gap % | median % | reaches bound | infeasible nets |", "|---|---|---|---|---|"]
for r in R["static"]:
    out.append(f"| {r['method']} | {f(r['gap_mean_pct'])} | {f(r['gap_median_pct'])} | {r['optimal_topologies']}/{R['n_topologies']} | {r['infeasible_topologies']} |")
out += ["", "## Lifecycle (diurnal scenario, shared runtime manager)\n", "| method | energy W | migrations | state changes | saving vs always-on % | delay violations |", "|---|---|---|---|---|---|"]
for r in R["lifecycle_diurnal"]:
    out.append(f"| {r['method']} | {f(r['avg_energy_w'])} | {f(r['migrations'])} | {f(r['state_changes'])} | {f(r['elastic_saving_pct'])} | {f(r['violations'])} |")
out += ["", "## GreenPlace vs baselines - migrations (negative = fewer for GreenPlace)\n", "| baseline | mean % [95% CI] | median % | fewer/tie/more | Holm p | Cliff's delta |", "|---|---|---|---|---|---|"]
for t in R["tests_gp_vs_baselines_migrations"]:
    out.append(f"| {t['b']} | {f(t['pct_mean'])} [{f(t['pct_ci'][0])}, {f(t['pct_ci'][1])}] | {f(t['pct_median'])} | {t['wins']}/{t['ties']}/{t['losses']} | {p(t['p_holm'])} | {f(t['cliffs_delta'],2)} |")
out += ["", "## Traffic scenarios (GreenPlace vs 2-objective NSGA-II, migrations)\n", "| scenario | GreenPlace | NSGA-II | MIP set | GP vs NSGA-II % | Holm p | elastic saving % |", "|---|---|---|---|---|---|---|"]
for s in R["shift"]:
    out.append(f"| {s['scenario']} | {f(s['greenplace_migs'])} | {f(s['nsga2_2obj_migs'])} | {f(s['exact_mip_migs'])} | {f(s['gp_vs_nsga2_migs_pct'])} | {p(s['gp_vs_nsga2_p_holm'])} | {f(s['gp_elastic_saving_pct'])} |")
out += ["", "## Front quality (pool mode)\n", "| algo | hypervolume | IGD | front size |", "|---|---|---|---|"]
for q in R["quality"]:
    if q["mode"] == "pool": out.append(f"| {q['algo']} | {f(q['hv'],3)} | {f(q['igd'],3)} | {f(q['front_n'])} |")
out += ["", "## Selection rules (candidate table)\n", "| rule | migrations diurnal | migrations unseen | energy diurnal W |", "|---|---|---|---|"]
for k, v in R["selector"]["rules"].items():
    out.append(f"| {k} | {f(v['migs_diurnal'])} | {f(v['migs_shift'])} | {f(v['energy_diurnal'])} |")
out.append(f"\nProxy-vs-realised Spearman rho = {f(R['selector']['proxy_rho']['mean'],2)} (CI {[round(x,2) for x in R['selector']['proxy_rho']['ci']]}).")
if SC:
    out += ["", "## Scale study (gap to MIP lower bound, %)\n", "| network | n | MIP status | MIP s | MIP set | NSGA-II | GreenPlace | EnPlace-style |", "|---|---|---|---|---|---|---|---|"]
    for r in SC["rows"]:
        out.append(f"| {r['instance']} | {r['n']} | {r['mip_status']} | {f(r['mip_secs'])} | {f(r['mip_set_gap'])} | {f(r['nsga2_2obj_gap'])} | {f(r['greenplace_gap'])} | {f(r['enplace_gap'])} |")
(d / "RESULTS_SUMMARY.md").write_text("\n".join(out) + "\n")
print("wrote", d / "RESULTS_SUMMARY.md")
