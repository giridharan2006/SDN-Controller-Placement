"""Analyse benchmark results: tables, statistics, figures, and a written report.

Usage:
    python scripts/analyze_benchmark.py --tag main

Reads  outputs/benchmark/<tag>/rows.jsonl
Writes outputs/benchmark/<tag>/BENCHMARK_REPORT.md, summary.json and figures/*.png

Statistical approach (kept deliberately conservative):
  * the unit of replication is the TOPOLOGY (per-topology means over random seeds),
    because seeds on one topology are not independent evidence about topologies;
  * GreenPlace-vs-baseline comparisons use the paired Wilcoxon signed-rank test
    across topologies, Holm-corrected over the family of baselines, alongside
    win/tie/loss counts and effect sizes (medians / geometric-mean ratios with
    bootstrap 95% CIs) -- a p-value alone says nothing about how big a difference is;
  * ties are reported as ties (energy tolerance 0.5%, migrations exact).
"""
import argparse
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from greenplace.baselines import METHODS  # noqa: E402

LABEL = {k: v[0] for k, v in METHODS.items()}
LABEL["greenplace_no_hysteresis"] = "GreenPlace w/o hysteresis"
LABEL["greenplace_sil_slack0"] = "GreenPlace-SIL, slack 0% (exploratory)"
LABEL["greenplace_sil_slack5"] = "GreenPlace-SIL, slack 5% (exploratory)"
SIL_NOSTATIC = {"greenplace_sil", "nsga2_2obj_sil"}
ORDER = list(METHODS.keys())
GP = "greenplace"
ENERGY_TOL = 0.005

COLORS = {m: "#9aa5b1" for m in ORDER}
COLORS.update({"greenplace_sil": "#E67E22", "nsga2_2obj_sil": "#F5B041", "greenplace": "#C0392B", "nsga2_2obj": "#1E2761", "exact_mip": "#0E7C7B",
               "greco": "#2EC4B6", "ga_energy": "#5B6BBF"})


def bootstrap_ci(x, stat=np.mean, n=10000, seed=0):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    if len(x) == 0:
        return (np.nan, np.nan)
    boots = [stat(rng.choice(x, len(x), replace=True)) for _ in range(n)]
    return float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))


def holm(pvals):
    order = np.argsort(pvals)
    adj = np.empty(len(pvals))
    running = 0.0
    m = len(pvals)
    for rank, idx in enumerate(order):
        running = max(running, (m - rank) * pvals[idx])
        adj[idx] = min(1.0, running)
    return adj


def wilcoxon_p(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    if np.allclose(d, 0):
        return 1.0
    try:
        return float(stats.wilcoxon(d, zero_method="wilcox", alternative="two-sided").pvalue)
    except ValueError:
        return 1.0


def md_table(df, floatfmt=2):
    cols = list(df.columns)
    out = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    for _, r in df.iterrows():
        cells = []
        for c in cols:
            v = r[c]
            cells.append(f"{v:.{floatfmt}f}" if isinstance(v, (float, np.floating)) and not pd.isna(v) else str(v))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="main")
    ap.add_argument("--extra-tags", nargs="*", default=[], help="merge rows from other tags (e.g. control)")
    ap.add_argument("--out", default=str(ROOT / "outputs" / "benchmark"))
    args = ap.parse_args()
    base = Path(args.out) / args.tag
    rows = [json.loads(l) for l in (base / "rows.jsonl").read_text().splitlines()]
    for t in args.extra_tags:
        rows += [json.loads(l) for l in (Path(args.out) / t / "rows.jsonl").read_text().splitlines()]
    cfg = json.loads((base / "config.json").read_text())
    df = pd.DataFrame(rows)
    (base / "figures").mkdir(exist_ok=True)

    num = ["static_k", "static_energy_w", "static_worst_delay_ms", "static_runtime_s", "pool_k",
           "pool_static_energy_w", "pool_migration_burden", "pool_runtime_s", "avg_energy_w",
           "migrations", "violations", "transitions", "min_active", "max_active"]
    boolc = ["static_feasible", "pool_feasible"]
    for c in boolc:
        df[c] = df[c].astype(float)
    if "static_valid" not in df:
        df["static_valid"] = True
    topo = df.groupby(["name", "method"], as_index=False)[num + boolc].mean()
    info = df.groupby("name", as_index=False)[["n", "m", "bound_ms", "capacity", "k_floor", "cover_size"]].first()
    topo = topo.merge(info, on="name")
    topo["delay_model"] = topo["name"].map(df.groupby("name")["delay_model"].first())
    names = sorted(topo["name"].unique(), key=lambda s: int(info.loc[info.name == s, "n"].iloc[0]))
    T = len(names)

    main_methods = [m for m in ORDER if m in set(topo["method"])]
    P = {m: topo[topo.method == m].set_index("name").loc[names] for m in topo["method"].unique()}
    ex = P["exact_mip"]

    # ------------------------------------------------------------------ static
    static_rows = []
    for m in [x for x in main_methods if x not in SIL_NOSTATIC]:
        d = P[m]
        gap_all = (d["static_energy_w"] / ex["static_energy_w"] - 1.0) * 100
        ok = d["static_feasible"] == 1            # an infeasible placement is not a valid answer: exclude from gaps
        gap = gap_all[ok]
        static_rows.append({
            "Method": LABEL[m],
            "Always delay-feasible": f"{int(ok.sum())}/{T}",
            "Mean gap to exact (%)": gap.mean(),
            "Median gap (%)": gap.median(),
            "Matches exact (<=0.5%)": f"{int((gap.abs() <= 0.5).sum())}/{T}",
            "Mean #controllers": d["static_k"].mean(),
            "Mean runtime (s)": d["static_runtime_s"].mean(),
        })
    static_df = pd.DataFrame(static_rows)

    # --------------------------------------------------------------- lifecycle
    gpE, gpM = P[GP]["avg_energy_w"], P[GP]["migrations"]
    life_rows, pair_rows = [], []
    pvals_E, pvals_M, tmp = [], [], []
    for m in main_methods:
        d = P[m]
        ratio = d["avg_energy_w"] / gpE  # >1 means baseline uses MORE energy than GreenPlace
        lo, hi = bootstrap_ci(np.log(ratio), np.mean)
        life_rows.append({
            "Method": LABEL[m],
            "Lifecycle energy vs GreenPlace (geo-mean ratio)": float(np.exp(np.log(ratio).mean())),
            "95% CI": f"[{np.exp(lo):.3f}, {np.exp(hi):.3f}]",
            "Mean migrations": d["migrations"].mean(),
            "Mean state changes": d["transitions"].mean(),
            "Delay violations (total steps)": int(round(d["violations"].sum() * cfg["seeds"])),
            "As-published static energy vs GreenPlace lifecycle": float(
                np.exp(np.log(d["pool_static_energy_w"] / gpE).mean())),
        })
        if m == GP:
            continue
        e_w = int((d["avg_energy_w"] > gpE * (1 + ENERGY_TOL)).sum())      # GreenPlace uses less
        e_l = int((d["avg_energy_w"] < gpE * (1 - ENERGY_TOL)).sum())      # GreenPlace uses more
        m_w = int((d["migrations"] > gpM + 1e-9).sum())
        m_l = int((d["migrations"] < gpM - 1e-9).sum())
        pe, pm = wilcoxon_p(d["avg_energy_w"], gpE), wilcoxon_p(d["migrations"], gpM)
        pvals_E.append(pe); pvals_M.append(pm)
        tmp.append((m, e_w, T - e_w - e_l, e_l, m_w, T - m_w - m_l, m_l,
                    float((d["migrations"] - gpM).median()), float(np.median(d["avg_energy_w"] / gpE))))
    adjE, adjM = holm(np.array(pvals_E)), holm(np.array(pvals_M))
    for (m, ew, et, el, mw, mt, ml, dm, er), pe, pm in zip(tmp, adjE, adjM):
        pair_rows.append({
            "Baseline": LABEL[m],
            "Energy: GP better / tie / worse": f"{ew} / {et} / {el}",
            "Holm p (energy)": pe,
            "Migrations: GP fewer / tie / more": f"{mw} / {mt} / {ml}",
            "Median migr. diff (baseline-GP)": dm,
            "Holm p (migr.)": pm,
        })
    life_df, pair_df = pd.DataFrame(life_rows), pd.DataFrame(pair_rows)

    # ------------------------------------------------------ Pareto-optimality
    pareto_cnt = {m: 0 for m in main_methods}
    for nme in names:
        pts = {m: (P[m].loc[nme, "avg_energy_w"], P[m].loc[nme, "migrations"]) for m in main_methods}
        for a in main_methods:
            dominated = False
            Ea, Ma = pts[a]
            for b in main_methods:
                if a == b:
                    continue
                Eb, Mb = pts[b]
                if Eb <= Ea * (1 + ENERGY_TOL) and Mb <= Ma + 1e-9 and (Eb < Ea * (1 - ENERGY_TOL) or Mb < Ma - 1e-9):
                    dominated = True
                    break
            pareto_cnt[a] += (not dominated)
    pareto_df = pd.DataFrame({"Method": [LABEL[m] for m in main_methods],
                              "Topologies where method is Pareto-optimal (energy, migrations)":
                                  [f"{pareto_cnt[m]}/{T}" for m in main_methods]})

    # ---------------------------------------- does the migration objective work?
    corrs = []
    for nme in names:
        sub = topo[(topo.name == nme) & (topo.method.isin(main_methods))]
        if sub["pool_migration_burden"].nunique() > 1 and sub["migrations"].nunique() > 1:
            corrs.append(stats.spearmanr(sub["pool_migration_burden"], sub["migrations"]).statistic)
    mean_corr = float(np.mean(corrs)) if corrs else float("nan")
    corr_lo, corr_hi = bootstrap_ci(corrs) if corrs else (np.nan, np.nan)

    # ------------------------------------------------------- hysteresis ablation
    hyst = None
    if "greenplace_no_hysteresis" in P:
        h = P["greenplace_no_hysteresis"]
        hyst = {"migr_with": float(gpM.mean()), "migr_without": float(h["migrations"].mean()),
                "trans_with": float(P[GP]["transitions"].mean()), "trans_without": float(h["transitions"].mean())}

    # --------------------------------------------------------------- per size band
    band_rows = []
    for lo_, hi_ in ((0, 20), (21, 35), (36, 100)):
        sel = [nme for nme in names if lo_ <= int(info.loc[info.name == nme, "n"].iloc[0]) <= hi_]
        if len(sel) < 3:
            continue
        for m in ("nsga2_2obj", "exact_mip", "greco"):
            band_rows.append({
                "Nodes": f"{lo_}-{hi_}" if hi_ < 100 else f"{lo_}+", "n topologies": len(sel), "Baseline": LABEL[m],
                "GP fewer migrations (of n)": int((P[m].loc[sel, "migrations"] > gpM.loc[sel] + 1e-9).sum()),
                "GP more migrations (of n)": int((P[m].loc[sel, "migrations"] < gpM.loc[sel] - 1e-9).sum()),
                "Median energy ratio baseline/GP": float(np.median(P[m].loc[sel, "avg_energy_w"] / gpE.loc[sel])),
            })
    band_df = pd.DataFrame(band_rows)

    # ------------------------------------------------------------------ figures
    fig, ax = plt.subplots(1, 2, figsize=(14, 5.2))
    ms = [m for m in main_methods]
    gm = [float(np.exp(np.log(P[m]["avg_energy_w"] / gpE).mean())) for m in ms]
    ci = [bootstrap_ci(np.log(P[m]["avg_energy_w"] / gpE)) for m in ms]
    yerr = np.array([[g - np.exp(l), np.exp(h) - g] for g, (l, h) in zip(gm, ci)]).T
    ax[0].bar(range(len(ms)), gm, yerr=yerr, color=[COLORS[m] for m in ms], capsize=3)
    ax[0].axhline(1.0, color="k", lw=0.8, ls="--")
    ax[0].set_xticks(range(len(ms))); ax[0].set_xticklabels([LABEL[m] for m in ms], rotation=40, ha="right", fontsize=8)
    ax[0].set_ylim(0.9, 1.25)
    ax[0].set_ylabel("Energy relative to GreenPlace\n(geo-mean; >1 = uses more)")
    ax[0].set_title("(a) Lifecycle energy, same runtime manager\n(y-axis truncated at 0.9; bars show 95% CI)", fontsize=10)
    mm = [float(P[m]["migrations"].mean()) for m in ms]
    mci = [bootstrap_ci(P[m]["migrations"]) for m in ms]
    ax[1].bar(range(len(ms)), mm, yerr=np.array([[a - l, h - a] for a, (l, h) in zip(mm, mci)]).T,
              color=[COLORS[m] for m in ms], capsize=3)
    ax[1].set_xticks(range(len(ms))); ax[1].set_xticklabels([LABEL[m] for m in ms], rotation=40, ha="right", fontsize=8)
    ax[1].set_ylabel("Mean switch migrations per trace"); ax[1].set_title("(b) Runtime switch migrations\n(bars show 95% CI)", fontsize=10)
    plt.tight_layout(); plt.savefig(base / "figures" / "lifecycle_comparison.png", dpi=200); plt.close()

    fig, ax = plt.subplots(figsize=(8, 4.4))
    ms_static = [m for m in ms if m not in SIL_NOSTATIC]
    data = [((P[m]["static_energy_w"] / ex["static_energy_w"] - 1) * 100)[P[m]["static_feasible"] == 1].values for m in ms_static]
    bp = ax.boxplot(data, patch_artist=True, showfliers=True)
    for patch, m in zip(bp["boxes"], ms_static):
        patch.set_facecolor(COLORS[m])
    ax.set_xticks(range(1, len(ms_static) + 1)); ax.set_xticklabels([LABEL[m] for m in ms_static], rotation=40, ha="right", fontsize=8)
    ax.set_ylim(-5, 60)
    ax.set_ylabel("Static energy gap to exact MIP (%)")
    ax.set_title("Static placement quality across real topologies\n(y-axis clipped at 60%; betweenness is far off-scale, mean +167%)", fontsize=10)
    plt.tight_layout(); plt.savefig(base / "figures" / "static_gap.png", dpi=200); plt.close()

    fig, ax = plt.subplots(figsize=(5.4, 5))
    ax.scatter(P["nsga2_2obj"]["migrations"], gpM, c="#C0392B", s=28, alpha=0.8)
    lim = max(P["nsga2_2obj"]["migrations"].max(), gpM.max()) * 1.05 + 1
    ax.plot([0, lim], [0, lim], "k--", lw=0.8)
    ax.set_xlabel("Migrations: NSGA-II energy+delay (no migration awareness)")
    ax.set_ylabel("Migrations: GreenPlace (migration-aware)")
    ax.set_title("Per-topology migrations (below the line = GreenPlace better)")
    plt.tight_layout(); plt.savefig(base / "figures" / "migrations_scatter.png", dpi=200); plt.close()

    fig, ax = plt.subplots(figsize=(8, 4.6))
    ns = info.set_index("name").loc[names, "n"].values
    for m in ms:
        ax.scatter(ns, P[m]["static_runtime_s"].values + 1e-4, s=14, color=COLORS[m], alpha=0.8, label=LABEL[m])
    ax.set_yscale("log"); ax.set_xlabel("Topology size (nodes)"); ax.set_ylabel("Algorithm run-time per placement (s)")
    ax.legend(fontsize=6, ncol=2); ax.set_title("Scalability")
    plt.tight_layout(); plt.savefig(base / "figures" / "scalability.png", dpi=200); plt.close()

    # ------------------------------------------------- headline numbers + verdicts
    gp_better_mig_vs_2obj = int((P["nsga2_2obj"]["migrations"] > gpM + 1e-9).sum())
    gp_worse_mig_vs_2obj = int((P["nsga2_2obj"]["migrations"] < gpM - 1e-9).sum())
    summary = {
        "n_topologies": T, "size_range": [int(ns.min()), int(ns.max())],
        "config": cfg,
        "gp_vs_2obj_migrations": {"gp_fewer": gp_better_mig_vs_2obj, "gp_more": gp_worse_mig_vs_2obj,
                                    "mean_gp": float(gpM.mean()), "mean_2obj": float(P["nsga2_2obj"]["migrations"].mean())},
        "gp_lifecycle_energy_vs_2obj": float(np.exp(np.log(P["nsga2_2obj"]["avg_energy_w"] / gpE).mean())),
        "gp_static_gap_to_exact_pct_mean": float(((P[GP]["static_energy_w"] / ex["static_energy_w"] - 1) * 100)[P[GP]["static_feasible"] == 1].mean()),
        "burden_vs_migrations_spearman_mean": mean_corr,
        "gp_violations": int(P[GP]["violations"].sum()),
        "pareto_counts": pareto_cnt, "hysteresis": hyst,
        "static_operation_energy_vs_gp_lifecycle": {m: float(np.exp(np.log(P[m]["pool_static_energy_w"] / gpE).mean()))
                                                       for m in main_methods},
    }
    (base / "summary.json").write_text(json.dumps(summary, indent=2))

    # ----------------------------------------------------------------- the report
    L = []
    L.append(f"# GreenPlace benchmark report  (tag: `{args.tag}`)\n")
    L.append(f"**{T} real-world topologies** from the Internet Topology Zoo ({int(ns.min())}-{int(ns.max())} nodes; "
             f"{int((topo.drop_duplicates('name').delay_model == 'geographic').sum())} with geographic link delays, "
             f"the rest hop-count), {cfg['seeds']} random seeds per stochastic method, 96-step diurnal trace.\n")
    L.append("## What is compared, and how\n")
    L.append("All methods solve the same problem on the same graph: hard delay bound "
             f"D = {cfg['bound_frac']} x delay-diameter, per-controller capacity C = ceil(n/{cfg['cap_div']}), "
             "identical power model. **Baselines are our re-implementations of the algorithmic ideas behind "
             "existing work, not the original authors' code** (see `greenplace/baselines.py`); the study shows how the "
             "GreenPlace *approach* fares against those *approaches* on a common footing, not that it beats any paper's "
             "published numbers. Settings were fixed before the full run; a sensitivity grid is reported separately.\n")
    L.append("Two evaluations:\n\n1. **Static placement quality** - minimise energy subject to the delay bound (what most placement papers measure).\n"
             "2. **Lifecycle** - each method supplies a controller pool sized for peak load; the *same* runtime elastic manager "
             "then operates every pool over a diurnal trace. Differences are attributable to placement quality, not to who has a runtime phase.\n")
    L.append("## 1. Static placement quality\n")
    L.append(md_table(static_df) + "\n")
    L.append("![](figures/static_gap.png)\n")
    L.append("## 2. Lifecycle comparison (same runtime manager for every method)\n")
    L.append(md_table(life_df, 3) + "\n")
    L.append("![](figures/lifecycle_comparison.png)\n")
    L.append("*'As-published static energy vs GreenPlace lifecycle'* = the energy that method's pool would draw if operated always-on "
             "(how pure-placement work is deployed) divided by GreenPlace's lifecycle energy. Part of that gap is simply the runtime phase, "
             "which the other methods lack in their published form; column 'Lifecycle energy vs GreenPlace' is the like-for-like comparison.\n")
    L.append("## 3. Paired comparison: GreenPlace vs each baseline (across topologies)\n")
    L.append(md_table(pair_df, 4) + "\n")
    L.append("![](figures/migrations_scatter.png)\n")
    L.append("## 4. Pareto view: which methods are non-dominated in (lifecycle energy, migrations)?\n")
    L.append(md_table(pareto_df) + "\n")
    L.append("## 5. Does the migration-burden objective actually predict runtime migrations?\n")
    L.append(f"Mean within-topology Spearman correlation between a pool's offline migration burden and its realised runtime "
             f"migrations: **{mean_corr:.2f}** (95% CI [{corr_lo:.2f}, {corr_hi:.2f}], {len(corrs)} topologies with variation).\n")
    sil_section = []
    if "greenplace_sil" in P:
        S_ = P["greenplace_sil"]
        sE, sM = S_["avg_energy_w"], S_["migrations"]
        fam = [m for m in ("greenplace", "nsga2_2obj_sil", "nsga2_2obj", "exact_mip", "greco", "k_center")
               if m in P]
        rows_, pe_, pm_ = [], [], []
        for m in fam:
            d = P[m]
            pe_.append(wilcoxon_p(d["avg_energy_w"], sE)); pm_.append(wilcoxon_p(d["migrations"], sM))
        ae, am = holm(np.array(pe_)), holm(np.array(pm_))
        for m, pe, pm in zip(fam, ae, am):
            d = P[m]
            rows_.append({
                "Compared with": LABEL[m],
                "Mean migrations (that / SIL)": f"{d['migrations'].mean():.1f} / {sM.mean():.1f}",
                "SIL fewer / tie / more": f"{int((d['migrations'] > sM + 1e-9).sum())} / {int((abs(d['migrations'] - sM) <= 1e-9).sum())} / {int((d['migrations'] < sM - 1e-9).sum())}",
                "Holm p (migr.)": pm,
                "Energy ratio that/SIL (geo-mean)": float(np.exp(np.log(d["avg_energy_w"] / sE).mean())),
                "Holm p (energy)": pe,
            })
        sil_df = pd.DataFrame(rows_)
        sil_section.append("## 5c. Improvement experiment: GreenPlace-SIL (simulation-in-the-loop selection)\n")
        sil_section.append(
            "**Design fixed before the run:** same 3-objective NSGA-II fronts as GreenPlace (identical seeds); candidates = feasible Pareto members "
            "within 1.25x the cheapest static energy (max 10); each is simulated through the runtime manager on **2 training traces "
            "(seeds 100-101) that are never used for evaluation (seeds 0-2)**; pick = fewest simulated migrations among candidates within "
            "2% of the best simulated lifecycle energy. Hypothesis: fewer migrations than the proxy-pick GreenPlace at <=2% extra energy. "
            "Caveat: training and evaluation traces come from the same synthetic generator (different noise draws only), so this does not test "
            "robustness to a *different* traffic pattern.\n")
        sil_section.append(md_table(sil_df, 4) + "\n")
        ex_rows = []
        for m in ("greenplace_sil_slack0", "greenplace_sil", "greenplace_sil_slack5"):
            if m in P:
                ex_rows.append({"Variant": LABEL.get(m, "GreenPlace-SIL (pre-registered slack 2%)") if m != "greenplace_sil" else "GreenPlace-SIL, slack 2% (pre-registered)",
                                "Mean migrations": float(P[m]["migrations"].mean()),
                                "Lifecycle energy vs exact MIP (geo-mean)": float(np.exp(np.log(P[m]["avg_energy_w"] / ex["avg_energy_w"]).mean()))})
        if len(ex_rows) > 1:
            sil_section.append("**Exploratory (post-hoc, not part of the pre-registered claim) - sensitivity to the energy slack:**\n")
            sil_section.append(md_table(pd.DataFrame(ex_rows), 3) + "\n")
        summary["sil"] = {
            "mean_migr_sil": float(sM.mean()),
            "mean_migr_gp_proxy": float(gpM.mean()),
            "mean_energy_ratio_proxy_over_sil": float(np.exp(np.log(gpE / sE).mean())),
            "sil_fewer_than_proxy": int((gpM > sM + 1e-9).sum()), "sil_more_than_proxy": int((gpM < sM - 1e-9).sum()),
            "holm_p_migr_vs_proxy": float(am[fam.index("greenplace")]),
            "mean_migr_nsga2_2obj": float(P["nsga2_2obj"]["migrations"].mean()),
            "holm_p_migr_vs_nsga2_2obj": float(am[fam.index("nsga2_2obj")]),
            "energy_ratio_sil_over_exact": float(np.exp(np.log(sE / ex["avg_energy_w"]).mean())),
        }
        (base / "summary.json").write_text(json.dumps(summary, indent=2))
    if "nsga2_2obj_migsel" in P:
        c = P["nsga2_2obj_migsel"]
        L.append("## 5b. Control: is it the 3-objective *search*, or just the migration-aware *pick*?\n")
        L.append("`CONTROL` runs the plain 2-objective NSGA-II (same seeds, so identical fronts to the energy+delay baseline) "
                 "and then applies GreenPlace's migration-aware selection rule. If GreenPlace's gain were only due to the pick rule, "
                 "the control would match it.\n")
        pc = wilcoxon_p(c["migrations"], gpM)
        L.append(f"Mean migrations: energy+delay baseline **{P['nsga2_2obj']['migrations'].mean():.1f}**, "
                 f"control **{c['migrations'].mean():.1f}**, GreenPlace **{gpM.mean():.1f}**. "
                 f"GreenPlace fewer/tie/more migrations than the control: "
                 f"{int((c['migrations'] > gpM + 1e-9).sum())} / {int((abs(c['migrations'] - gpM) <= 1e-9).sum())} / "
                 f"{int((c['migrations'] < gpM - 1e-9).sum())} (Wilcoxon p = {pc:.3f}, uncorrected). "
                 f"Mean lifecycle energy: control {c['avg_energy_w'].mean():.0f} W vs GreenPlace {gpE.mean():.0f} W.\n")
        summary["control"] = {"mean_migr_control": float(c["migrations"].mean()), "mean_migr_gp": float(gpM.mean()),
                              "mean_migr_2obj": float(P["nsga2_2obj"]["migrations"].mean()), "p_uncorrected": pc,
                              "gp_fewer": int((c["migrations"] > gpM + 1e-9).sum()),
                              "gp_more": int((c["migrations"] < gpM - 1e-9).sum())}
        (base / "summary.json").write_text(json.dumps(summary, indent=2))
    L.extend(sil_section)
    if hyst:
        L.append("## 6. Runtime hysteresis ablation\n")
        L.append(f"Mean migrations with EMA+dwell: **{hyst['migr_with']:.1f}** vs without: **{hyst['migr_without']:.1f}**; "
                 f"controller state changes {hyst['trans_with']:.1f} vs {hyst['trans_without']:.1f}.\n")
    if len(band_df):
        L.append("## 7. Results by topology size\n")
        L.append(md_table(band_df, 2) + "\n")
    L.append("## 8. Scalability\n\n![](figures/scalability.png)\n")
    L.append("## Per-topology results (means over seeds)\n")
    keep = topo[topo.method.isin(main_methods)].copy()
    keep["method"] = keep["method"].map(LABEL)
    keep = keep[["name", "n", "method", "pool_k", "avg_energy_w", "migrations", "transitions", "violations"]]
    L.append("<details><summary>Show table</summary>\n\n" + md_table(keep.round(1), 1) + "\n\n</details>\n")
    (base / "BENCHMARK_REPORT.md").write_text("\n".join(L))
    print("\n".join(L[:30]))
    print(f"\nWrote {base/'BENCHMARK_REPORT.md'}")


if __name__ == "__main__":
    main()
