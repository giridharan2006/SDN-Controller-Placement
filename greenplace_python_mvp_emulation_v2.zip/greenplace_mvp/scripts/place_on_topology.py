"""Run GreenPlace on YOUR network and get a recommended controller pool.

Usage:
    python scripts/place_on_topology.py data/real_topologies/Geant2012.gml
    python scripts/place_on_topology.py my_network.gml --bound-ms 12 --capacity 8 --slack 0.05

What it does (Phase 1 of GreenPlace + the optional simulation-in-the-loop improvement):
  1. loads the GML (Topology Zoo quirks handled; delays from node coordinates, else 1 ms/link),
  2. derives the delay bound / switch capacity unless you pass them,
  3. runs the 3-objective NSGA-II (energy, delay, migration burden) over pools sized to serve peak load,
  4. recommends a pool two ways: the offline migration-burden pick, and the simulation-in-the-loop pick
     (each candidate rehearsed through the runtime manager on training traces),
  5. evaluates both on fresh, held-out traces and writes everything to JSON.

The slack is the explicit energy-vs-stability dial: a larger value accepts slightly more energy for fewer migrations.
"""
import argparse
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from greenplace import baselines as B  # noqa: E402
from greenplace.benchmark import BenchConfig, derive_settings  # noqa: E402
from greenplace.config import DelayConfig, PowerModel  # noqa: E402
from greenplace.lifecycle import simulate  # noqa: E402
from greenplace.runtime import generate_diurnal_trace  # noqa: E402
from greenplace.selection import select_by_simulation, select_migration_aware  # noqa: E402
from greenplace.topology import load_zoo_topology  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("gml")
    ap.add_argument("--bound-ms", type=float, help="hard switch-to-controller delay bound (default 0.35 x diameter)")
    ap.add_argument("--capacity", type=int, help="switches per controller (default ceil(n/6))")
    ap.add_argument("--slack", type=float, default=0.02, help="energy slack for the simulation pick (default 2%%)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--pop", type=int, default=40)
    ap.add_argument("--gens", type=int, default=60)
    ap.add_argument("--out", default=None, help="write JSON here (default: outputs/placement_<name>.json)")
    a = ap.parse_args()

    g, meta = load_zoo_topology(a.gml)
    cfg = BenchConfig(nsga_pop=a.pop, nsga_gens=a.gens, sil_energy_slack=a.slack)
    st = derive_settings(g, cfg)
    bound = a.bound_ms or st["bound_ms"]
    cap = a.capacity or st["capacity"]
    k_floor = math.ceil(g.number_of_nodes() / cap)
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(bound))
    cover = len(B.greedy_cover(p, 1))
    print(f"{meta['name']}: {meta['n']} nodes, {meta['m']} links, delay model: {meta['delay_model']}")
    print(f"delay bound {bound:.2f} ms | capacity {cap} switches/controller | peak-load pool >= {k_floor} | "
          f"delay-driven minimum ~{cover} controllers")

    k_max = min(g.number_of_nodes(), max(k_floor, cover) + cfg.extra_pool)
    front = B.nsga2_front(p, k_floor, k_max, a.seed, True, a.pop, a.gens)
    proxy = select_migration_aware(front, cfg.energy_slack)
    if proxy is None:
        sys.exit("No delay-feasible pool found: loosen --bound-ms or raise --gens.")
    train = [generate_diurnal_trace(cfg.trace_len, seed=s) for s in cfg.sil_train_seeds]
    sil, info = select_by_simulation(p, front, cap, train, a.slack, cfg.sil_window, cfg.sil_max_candidates)
    held_out = [generate_diurnal_trace(cfg.trace_len, seed=s) for s in (0, 1, 2)]

    def report(name, pl):
        sims = [simulate(p, set(pl.controllers), cap, t) for t in held_out]
        r = {"controllers": sorted(int(c) for c in pl.controllers), "pool_size": len(pl.controllers),
             "static_always_on_energy_w": round(pl.energy_w, 1),
             "worst_case_delay_ms": round(pl.worst_case_delay_ms, 2),
             "lifecycle_avg_energy_w": round(sum(x["avg_energy_w"] for x in sims) / len(sims), 1),
             "migrations_per_trace": round(sum(x["migrations"] for x in sims) / len(sims), 1),
             "delay_violations": sum(x["violations"] for x in sims)}
        print(f"\n[{name}]  pool of {r['pool_size']}: {r['controllers']}")
        print(f"  worst-case delay {r['worst_case_delay_ms']} ms (bound {bound:.2f}) | always-on {r['static_always_on_energy_w']} W | "
              f"with runtime manager {r['lifecycle_avg_energy_w']} W | {r['migrations_per_trace']} migrations/trace | "
              f"violations {r['delay_violations']}   (held-out traces)")
        return r

    out = {"topology": meta, "delay_bound_ms": bound, "capacity": cap, "peak_pool_min": k_floor,
           "pareto_front_size": len(front), "sil_candidates": info["n_candidates"],
           "proxy_pick": report("offline migration-burden pick", proxy),
           "simulation_pick": report(f"simulation-in-the-loop pick (slack {a.slack:.0%})", sil)}
    dest = Path(a.out) if a.out else ROOT / "outputs" / f"placement_{meta['name']}.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(out, indent=2))
    print(f"\nWrote {dest}")


if __name__ == "__main__":
    main()
