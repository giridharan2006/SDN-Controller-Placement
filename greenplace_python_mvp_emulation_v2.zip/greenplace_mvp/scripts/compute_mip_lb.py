"""MIP lower bound (free-assignment optimum) per topology, same k-range as the static study -> mip_lb.json."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "scripts"))
from greenplace import baselines as B
from greenplace.benchmark import BenchConfig, derive_settings
from greenplace.config import DelayConfig, PowerModel
from greenplace.topology import load_zoo_topology
from scripts_common import discover
cfg = BenchConfig(cap_div=6); out = {}
for f in discover(ROOT / "data" / "real_topologies", 10, 60):
    g, meta = load_zoo_topology(f); st = derive_settings(g, cfg)
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(st["bound_ms"]))
    cover = len(B.greedy_cover(p, 1)); kmax = None   # uncapped: a valid lower bound for any placement size
    s, info = B.exact_mip(p, 1, kmax, cfg.mip_time_limit_s)
    out[meta["name"]] = {"lb_energy_w": info["model_energy_w"], "status": info["status"], "mip_set_nearest_energy_w": p.evaluate(s).energy_w}
    print(meta["name"], out[meta["name"]], flush=True)
(ROOT / "outputs" / "study3" / "main" / "mip_lb.json").write_text(json.dumps(out, indent=1))
