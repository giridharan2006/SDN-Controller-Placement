"""Benchmark GreenPlace against re-implemented existing approaches on REAL topologies.

Usage:
    python scripts/run_benchmark.py                 # full run (46 real networks, 10-60 nodes)
    python scripts/run_benchmark.py --quick         # small/fast pass for a live demo
    python scripts/run_benchmark.py --names Abilene Geant2012 --seeds 3
    python scripts/run_benchmark.py --grid          # sensitivity grid over capacity x delay bound

Results are checkpointed to outputs/benchmark/<tag>/rows.jsonl as each topology finishes,
so an interrupted run resumes where it stopped. Then run:
    python scripts/analyze_benchmark.py --tag <tag>
"""
import argparse
import csv
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from greenplace.benchmark import BenchConfig, run_topology  # noqa: E402
from greenplace.topology import load_zoo_topology  # noqa: E402


def discover(topo_dir: Path, lo: int, hi: int, names=None):
    out = []
    for f in sorted(topo_dir.glob("*.gml")):
        if names and f.stem not in names:
            continue
        try:
            _, meta = load_zoo_topology(f)
        except Exception as e:
            print(f"  skip {f.stem}: {e}")
            continue
        if lo <= meta["n"] <= hi:
            out.append((meta["n"], f))
    out.sort(key=lambda x: (x[0], x[1].stem))
    return [f for _, f in out]


def run_one_setting(files, cfg: BenchConfig, tag: str, out_root: Path):
    out = out_root / tag
    out.mkdir(parents=True, exist_ok=True)
    rows_path = out / "rows.jsonl"
    (out / "config.json").write_text(json.dumps(cfg.__dict__ | {"methods": list(cfg.methods)}, indent=2))
    done = set()
    if rows_path.exists():
        for line in rows_path.read_text().splitlines():
            done.add(json.loads(line)["name"])
    t_start = time.time()
    for i, f in enumerate(files, 1):
        if f.stem in done:
            print(f"[{i}/{len(files)}] {f.stem}: already done (resume)")
            continue
        t0 = time.time()
        rows = run_topology(f, cfg)
        with open(rows_path, "a") as fh:
            for r in rows:
                fh.write(json.dumps(r, default=float) + "\n")
        print(f"[{i}/{len(files)}] {f.stem:14s} n={rows[0]['n']:3d} K={rows[0]['k_floor']} "
              f"cover={rows[0]['cover_size']}  {time.time() - t0:5.1f}s", flush=True)
    # flatten to CSV for spreadsheet users
    rows = [json.loads(l) for l in rows_path.read_text().splitlines()]
    if rows:
        with open(out / "rows.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    print(f"[{tag}] finished in {(time.time() - t_start) / 60:.1f} min -> {out}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--topologies-dir", default=str(ROOT / "data" / "real_topologies"))
    ap.add_argument("--min-nodes", type=int, default=10)
    ap.add_argument("--max-nodes", type=int, default=60)
    ap.add_argument("--names", nargs="*")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--cap-div", type=int, default=6, help="capacity C = ceil(n/cap_div)")
    ap.add_argument("--bound-frac", type=float, default=0.35, help="delay bound = frac x delay-diameter")
    ap.add_argument("--nsga-pop", type=int, default=50)
    ap.add_argument("--nsga-gens", type=int, default=80)
    ap.add_argument("--tag", default="main")
    ap.add_argument("--methods", nargs="*", help="subset of methods (e.g. the control: nsga2_2obj_migsel)")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--grid", action="store_true", help="sensitivity grid on a subset of topologies")
    ap.add_argument("--out", default=str(ROOT / "outputs" / "benchmark"))
    args = ap.parse_args()
    out_root = Path(args.out)

    if args.grid:
        files = discover(Path(args.topologies_dir), 15, 40, args.names)
        files = files[:: max(1, len(files) // 10)][:10]  # ~10 topologies spread across sizes
        print(f"Sensitivity grid on {len(files)} topologies: {[f.stem for f in files]}")
        for cap_div in (4, 6, 8):
            for bf in (0.25, 0.35, 0.5):
                cfg = BenchConfig(bound_frac=bf, cap_div=cap_div, seeds=3, nsga_pop=30, nsga_gens=40,
                                  include_hysteresis_ablation=False)
                run_one_setting(files, cfg, f"grid_c{cap_div}_b{int(bf * 100):03d}", out_root)
        return

    hi = 35 if args.quick else args.max_nodes
    files = discover(Path(args.topologies_dir), args.min_nodes, hi, args.names)
    if not files:
        sys.exit("No topologies found. Run: python scripts/fetch_real_topologies.py")
    cfg = BenchConfig(bound_frac=args.bound_frac, cap_div=args.cap_div,
                      seeds=2 if args.quick else args.seeds,
                      nsga_pop=30 if args.quick else args.nsga_pop,
                      nsga_gens=40 if args.quick else args.nsga_gens)
    if args.methods:
        cfg.methods = tuple(args.methods)
        cfg.include_hysteresis_ablation = False
        if set(cfg.methods) & {"greenplace_sil", "nsga2_2obj_sil"} and args.tag == "main":
            sys.exit("Use --tag sil (or another tag) for SIL runs so main results are not mixed.")
    tag = "quick" if args.quick and args.tag == "main" else args.tag
    print(f"Benchmarking {len(files)} real topologies  (tag={tag}, seeds={cfg.seeds}, "
          f"bound={cfg.bound_frac}xdiameter, capacity=n/{cfg.cap_div})")
    run_one_setting(files, cfg, tag, out_root)


if __name__ == "__main__":
    main()
