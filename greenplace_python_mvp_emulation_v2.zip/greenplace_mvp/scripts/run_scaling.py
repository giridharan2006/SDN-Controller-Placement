"""Scale study: where does the exact MIP stop being practical and do the heuristics hold up?

Static placement (minimum energy under the hard delay bound) on large real Zoo networks and synthetic
backbone-like networks of 100-400 nodes. The MIP gets a fixed wall-clock limit; we report its status,
the best objective it returns, and every other method's gap to the best objective found by ANY method.
Usage: python scripts/run_scaling.py [--mip-limit 60] [--out outputs/scaling]
"""
import argparse, json, math, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from greenplace import baselines as B, moea  # noqa: E402
from greenplace.benchmark import BenchConfig, derive_settings  # noqa: E402
from greenplace.config import DelayConfig, PowerModel  # noqa: E402
from greenplace.selection import select_min_energy, select_migration_aware  # noqa: E402
from greenplace.topology import generate_backbone_like_topology, load_zoo_topology  # noqa: E402

ZOO = ["Interoute", "Deltacom", "Pern", "Colt", "Cogentco", "Kdl"]
SYN_N = [100, 200, 300, 400]


def timed(f):
    t = time.perf_counter()
    try:
        return f(), time.perf_counter() - t, None
    except Exception as e:                      # record, never crash the study
        return None, time.perf_counter() - t, f"{type(e).__name__}: {e}"[:120]


def run_instance(g, name, kind, seed, cfg, mip_limit, rows, mip_only=False, mip_uncapped=False, kmax_hint=None):
    st = derive_settings(g, cfg)
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(st["bound_ms"]))
    n = g.number_of_nodes()
    cover = len(B.greedy_cover(p, 1))
    kmax = min(n, max(1, cover) + cfg.extra_pool)
    if kmax_hint is not None:                      # size-hinted run: search ceiling from the uncapped MIP's controller count
        kmax = min(n, 2 * kmax_hint + 4)
    res = {}

    def rec(m, out, secs, err, extra=None):
        if out is None:
            res[m] = dict(energy=None, feasible=False, secs=secs, err=err, k=None)
        else:
            q = p.evaluate(set(out))
            res[m] = dict(energy=q.energy_w, feasible=q.feasible, secs=secs, err=err, k=len(out))
        if extra:
            res[m].update(extra)

    if not mip_only and kmax_hint is None:
        rec("greedy_cover", *timed(lambda: B.greedy_cover(p, 1)))
        rec("greco", *timed(lambda: B.greco_style(p, min_size=1)))
        rec("enplace", *timed(lambda: moea.enplace_style(p, 1, swap_passes=2 if n <= 200 else 0)))
    for m, aware in (() if mip_only else (("nsga2_2obj", False), ("greenplace", True))):
        def go():
            fr = B.nsga2_front(p, 1, kmax, seed, aware, cfg.nsga_pop, cfg.nsga_gens)
            pk = select_min_energy(fr) if not aware else select_migration_aware(fr, cfg.energy_slack)
            return set(pk.controllers) if pk else None
        rec(m, *timed(go))
    if not mip_only:
        rec("nsga3", *timed(lambda: set(select_min_energy(moea.run_nsga3(p, 1, kmax, seed, cfg.nsga_pop, cfg.nsga_gens)).controllers)))
    if seed == 0 and kmax_hint is None:          # the MIP is deterministic: run once per instance
        def mip():
            s, info = B.exact_mip(p, 1, None if mip_uncapped else kmax, mip_limit)
            return (s, info)
        out, secs, err = timed(mip)
        if out is None:
            res["exact_mip"] = dict(energy=None, feasible=False, secs=secs, err=err, k=None, status="error")
        else:
            s, info = out
            q = p.evaluate(set(s))
            res["exact_mip"] = dict(energy=q.energy_w, feasible=q.feasible, secs=secs, err=None, k=len(s),
                                    status=str(info.get("status", "")), lb=info.get("model_energy_w"))
    for m, r in res.items():
        rows.append({"name": name, "kind": kind, "n": n, "m": g.number_of_edges(), "seed": seed, "method": m,
                     "bound_ms": st["bound_ms"], "mip_limit_s": mip_limit, **r})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mip-limit", type=float, default=60.0)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--out", default=str(ROOT / "outputs" / "scaling"))
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--size-hint", action="store_true", help="re-run NSGA-II/GreenPlace/NSGA-III with k_max = 2*k(uncapped MIP)+4; writes rows_hint.json")
    ap.add_argument("--mip-uncapped-only", action="store_true", help="re-run only the MIP without the k_max cap (valid lower bound); writes rows_mip_uncapped.json")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    cfg = BenchConfig(cap_div=6, nsga_pop=40, nsga_gens=60)
    rows = []
    hint_rows = json.loads((out / "rows_mip_uncapped.json").read_text()) if a.size_hint else []
    jobs = [("zoo", z) for z in ZOO] + [("synthetic", f"syn{n}") for n in SYN_N]
    for kind, nm in jobs:
        if a.only and nm not in a.only:
            continue
        for seed in range(a.seeds):
            if kind == "zoo":
                g, _ = load_zoo_topology(ROOT / "data" / "real_topologies" / f"{nm}.gml")
            else:
                g = generate_backbone_like_topology(int(nm[3:]), seed=seed)
            t = time.time()
            if a.mip_uncapped_only and seed > 0 and kind == "zoo":
                continue
            iname = nm if kind == "zoo" else f"{nm}_s{seed}"
            hint = None
            if a.size_hint:
                hint = next(r["k"] for r in hint_rows if r["name"] == iname and r["method"] == "exact_mip")
            run_instance(g, iname, kind, seed if kind == "zoo" else 0, cfg, a.mip_limit, rows,
                         mip_only=a.mip_uncapped_only, mip_uncapped=a.mip_uncapped_only, kmax_hint=hint)
            if kind == "synthetic":
                pass
            print(f"{nm} seed{seed} n={g.number_of_nodes()} {time.time()-t:.0f}s", flush=True)
            (out / ("rows_mip_uncapped.json" if a.mip_uncapped_only else "rows_hint.json" if a.size_hint else "rows.json")).write_text(json.dumps(rows, indent=1, default=float))
            if kind == "zoo" and seed == 0:
                pass
    print("done ->", out)


if __name__ == "__main__":
    main()
