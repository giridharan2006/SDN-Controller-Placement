"""Generate and save small/medium synthetic topology fixtures used by the
other demo scripts and the test suite.

For REAL backbone topologies (Internet2 OS3E, GEANT, etc.), download GML
files from the Internet Topology Zoo (https://topology-zoo.org/dataset.html)
into data/topologies/ and load them with greenplace.topology.load_topology_gml
instead — synthetic topologies here are for fast local development only.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from greenplace.topology import generate_synthetic_topology, save_topology_gml

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "topologies"


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    fixtures = {
        "tiny_4node.gml": dict(n_nodes=4, seed=1, extra_edge_prob=0.3),
        "small_8node.gml": dict(n_nodes=8, seed=2, extra_edge_prob=0.2),
        "medium_15node.gml": dict(n_nodes=15, seed=3, extra_edge_prob=0.15),
        "medium_25node.gml": dict(n_nodes=25, seed=4, extra_edge_prob=0.1),
    }

    for filename, params in fixtures.items():
        g = generate_synthetic_topology(**params)
        path = OUT_DIR / filename
        save_topology_gml(g, path)
        print(f"Wrote {path}  ({g.number_of_nodes()} nodes, {g.number_of_edges()} edges)")


if __name__ == "__main__":
    main()
