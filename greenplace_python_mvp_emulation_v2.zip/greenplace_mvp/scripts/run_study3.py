"""Run the extended (v3) study. Sharded + resumable:  python scripts/run_study3.py --shard 0 --nshards 2
Output: outputs/study3/<tag>/{rows,cands,quality}.jsonl  (appended per topology)."""
import argparse, json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from greenplace.benchmark import BenchConfig  # noqa: E402
from greenplace.study3 import run_topology3  # noqa: E402
from scripts_common import discover  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="main")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--shard", type=int, default=0)
    ap.add_argument("--nshards", type=int, default=1)
    ap.add_argument("--min-nodes", type=int, default=10)
    ap.add_argument("--max-nodes", type=int, default=60)
    ap.add_argument("--names", nargs="*")
    ap.add_argument("--cap-div", type=int, default=6)
    ap.add_argument("--bound-frac", type=float, default=0.35)
    ap.add_argument("--nsga-pop", type=int, default=40)
    ap.add_argument("--nsga-gens", type=int, default=60)
    ap.add_argument("--no-sim", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "outputs" / "study3"))
    a = ap.parse_args()
    files = discover(ROOT / "data" / "real_topologies", a.min_nodes, a.max_nodes, a.names)
    files = files[a.shard::a.nshards]
    cfg = BenchConfig(bound_frac=a.bound_frac, cap_div=a.cap_div, seeds=a.seeds, nsga_pop=a.nsga_pop, nsga_gens=a.nsga_gens)
    out = Path(a.out) / a.tag; out.mkdir(parents=True, exist_ok=True)
    (out / f"config_shard{a.shard}.json").write_text(json.dumps({k: (list(v) if isinstance(v, tuple) else v) for k, v in cfg.__dict__.items()}, indent=2))
    done = set()
    marker = out / f"done_shard{a.shard}.txt"
    if marker.exists():
        done = set(marker.read_text().split())
    for i, f in enumerate(files, 1):
        if f.stem in done:
            print(f"[{i}/{len(files)}] {f.stem}: resume-skip"); continue
        t0 = time.time()
        rows, cands, qual = run_topology3(f, cfg, with_sim=not a.no_sim)
        for name, data in (("rows", rows), ("cands", cands), ("quality", qual)):
            with open(out / f"{name}_shard{a.shard}.jsonl", "a") as fh:
                for r in data:
                    fh.write(json.dumps(r, default=float) + "\n")
        with open(marker, "a") as fh:
            fh.write(f.stem + "\n")
        print(f"[{i}/{len(files)}] {f.stem:16s} n={rows[0]['n']:3d} {time.time()-t0:6.1f}s", flush=True)


if __name__ == "__main__":
    main()
