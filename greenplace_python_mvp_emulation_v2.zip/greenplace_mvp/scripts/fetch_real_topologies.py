"""Download real-world network topologies from the Internet Topology Zoo.

The Zoo (Knight et al., IEEE JSAC 2011, doi:10.1109/JSAC.2011.111002; data
licensed CC BY) is a collection of 250+ real ISP / research-network topologies
with node coordinates. The original site (topology-zoo.org) is being wound down,
so this script uses the long-term GitHub mirror (mroughan/InternetTopologyZoo).

Usage:
    python scripts/fetch_real_topologies.py              # the curated set below (~65 networks)
    python scripts/fetch_real_topologies.py --all        # every GML file in the mirror (250+)
    python scripts/fetch_real_topologies.py --names Abilene Geant2012 Janet

Files are written to data/real_topologies/ (existing files are skipped).
Please cite the Topology Zoo paper if you use these in published work.
"""
import argparse
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

RAW = "https://raw.githubusercontent.com/mroughan/InternetTopologyZoo/master/gml/{name}.gml"
TREE = "https://api.github.com/repos/mroughan/InternetTopologyZoo/git/trees/master?recursive=1"
OUT = Path(__file__).resolve().parents[1] / "data" / "real_topologies"

CURATED = """Abilene Arnes Atmnet Bellcanada Belnet2010 Bics Biznet Cernet Cesnet201006 Cogentco Colt
Compuserve Cudi Deltacom Dfn Digex Ernet Funet Garr201201 Geant2012 Grnet Harnet Heanet Hibernia
Highwinds Iinet Intellifiber Internet2 Internetmci Interoute Iris Karen Kdl Layer42 Missouri Napnet
Netrail Noel Nordu2005 Nsfnet Ntelos Ntt Oteglobe Peer1 Pern Quest Rediris Renater2010 Rnp Sanet Savvis
Shentel Sinet Sprint Sunet Surfnet Switch Syringa Telcove Tinet Tw Ulaknet Uninett2011 Uunet Xeex
Xspedius Zamren""".split()


def http_get(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "greenplace-fetch/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def list_all_names() -> list:
    try:
        tree = json.loads(http_get(TREE).decode())["tree"]
        names = [Path(t["path"]).stem for t in tree if t["path"].startswith("gml/") and t["path"].endswith(".gml")]
        if names:
            return sorted(names)
    except Exception as e:  # rate-limited or offline
        print(f"  (could not list the full archive via the GitHub API: {e}); using the curated list", file=sys.stderr)
    return CURATED


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--all", action="store_true", help="fetch every GML in the mirror")
    ap.add_argument("--names", nargs="*", help="specific network names, e.g. Abilene Geant2012")
    args = ap.parse_args()

    names = args.names or (list_all_names() if args.all else CURATED)
    OUT.mkdir(parents=True, exist_ok=True)
    ok = skipped = failed = 0
    for name in names:
        dest = OUT / f"{name}.gml"
        if dest.exists() and dest.stat().st_size > 0:
            skipped += 1
            continue
        try:
            dest.write_bytes(http_get(RAW.format(name=name)))
            ok += 1
            print(f"  fetched {name}")
        except (urllib.error.URLError, TimeoutError) as e:
            failed += 1
            print(f"  FAILED  {name}: {e}", file=sys.stderr)
    print(f"\n{ok} downloaded, {skipped} already present, {failed} failed -> {OUT}")


if __name__ == "__main__":
    main()
