"""Benchmark: exact solver vs. NSGA-II heuristic on small topologies.

This is the core validation experiment from the project framework: confirm
the NSGA-II Pareto front's best energy is close to the true optimum on
topologies small enough to solve exactly, before trusting NSGA-II on
larger WAN-scale topologies where exact solving is infeasible.

Usage:
    python scripts/run_ilp_vs_nsga2.py [--quick]

    --quick   Fewer NSGA-II generations/population for a fast live demo
              (still validates correctly, just a looser search).
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from greenplace.config import DelayConfig, NSGA2Config, PowerModel
from greenplace.delay import DelayEngine
from greenplace.metrics import export_csv, export_json, plot_pareto_front, placements_to_records
from greenplace.optimizer import optimize
from greenplace.topology import generate_synthetic_topology

OUT_DIR = Path(__file__).resolve().parents[1] / "outputs"


def run_one(name: str, graph, delay_config: DelayConfig, power_model: PowerModel, k_max: int, quick: bool):
    print(f"\n--- {name} ({graph.number_of_nodes()} nodes) ---")

    t0 = time.perf_counter()
    exact_placements, exact_info = optimize(
        graph, method="exact", power_model=power_model, delay_config=delay_config, k_min=1, k_max=k_max
    )
    t_exact = time.perf_counter() - t0
    exact = exact_placements[0]
    print(f"Exact   : energy={exact.energy_w:.1f}W  delay={exact.worst_case_delay_ms:.2f}ms  "
          f"controllers={len(exact.controllers)}  runtime={t_exact:.3f}s  backend={exact_info['backend']}")

    t0 = time.perf_counter()
    pop, gens = (30, 30) if quick else (60, 80)
    nsga2_cfg = NSGA2Config(population_size=pop, generations=gens, k_min=1, k_max=k_max, random_seed=42)
    nsga2_front, nsga2_info = optimize(
        graph, method="nsga2", power_model=power_model, delay_config=delay_config,
        nsga2_config=nsga2_cfg, k_min=1, k_max=k_max,
    )
    t_nsga2 = time.perf_counter() - t0
    best = min(nsga2_front, key=lambda p: p.energy_w)
    gap_pct = 100.0 * (best.energy_w - exact.energy_w) / exact.energy_w if exact.feasible else float("nan")
    print(f"NSGA-II : best energy={best.energy_w:.1f}W (gap {gap_pct:+.1f}% vs exact)  "
          f"front_size={len(nsga2_front)}  runtime={t_nsga2:.3f}s")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    plot_pareto_front(
        nsga2_front, title=f"{name}: GreenPlace (NSGA-II) vs. exact optimum",
        out_path=OUT_DIR / f"pareto_{name}.png", highlight=exact,
        series_label="GreenPlace (NSGA-II placement)",
        highlight_label="Exact ILP (baseline, not GreenPlace)",
    )
    export_csv(placements_to_records(nsga2_front), OUT_DIR / f"pareto_{name}.csv")
    export_json(
        {"exact": exact.summary(), "exact_info": exact_info,
         "nsga2_front": placements_to_records(nsga2_front), "nsga2_info": nsga2_info,
         "gap_pct": gap_pct, "runtime_exact_s": t_exact, "runtime_nsga2_s": t_nsga2},
        OUT_DIR / f"result_{name}.json",
    )
    return gap_pct


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true", help="Faster settings for a live demo.")
    args = parser.parse_args()

    power_model = PowerModel()
    # A tighter bound is used deliberately: it's loose enough for a single
    # controller on the tiny 4-node graph (a real, if simple, trade-off point)
    # but tight enough to force multiple controllers on the 8/10-node graphs —
    # which is what actually exercises the multi-objective Pareto search.
    delay_config = DelayConfig(max_switch_to_controller_delay_ms=5.0)

    experiments = [
        ("tiny_4node", generate_synthetic_topology(n_nodes=4, seed=1, extra_edge_prob=0.3), 4),
        ("small_8node", generate_synthetic_topology(n_nodes=8, seed=2, extra_edge_prob=0.2), 6),
        ("small_10node", generate_synthetic_topology(n_nodes=10, seed=6, extra_edge_prob=0.2), 7),
    ]

    gaps = []
    for name, graph, k_max in experiments:
        gap = run_one(name, graph, delay_config, power_model, k_max, args.quick)
        gaps.append((name, gap))

    print("\n=== Summary: NSGA-II energy gap vs. exact optimum ===")
    for name, gap in gaps:
        print(f"  {name:15s}  {gap:+.2f}%")
    print(f"\nPlots and CSV/JSON results written to {OUT_DIR}")


if __name__ == "__main__":
    main()
