"""Figures for paper v3, generated ONLY from results.json (+ scaling rows.json)."""
import argparse, json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150,
                     "font.family": "DejaVu Serif"})
C = {"gp": "#1b6e5a", "gpsil": "#2a9d8f", "base": "#8d99ae", "bad": "#c1121f", "acc": "#e9a03b"}
LAB = {"greenplace": "GreenPlace", "greenplace_sil": "GreenPlace-SIL", "nsga2_2obj": "NSGA-II (2-obj)", "exact_mip": "Exact MIP",
       "nsga3": "NSGA-III", "mopso": "MOPSO", "enplace": "EnPlace-style", "greedy_cover": "Greedy cover", "greco": "GreCo-style",
       "ga_energy": "GA (energy)", "k_median": "k-median", "k_center": "k-center", "betweenness": "Betweenness", "random": "Random",
       "nsga2_2obj_migsel": "NSGA-II + mig. pick", "greenplace_energypick": "3-obj, energy pick", "simnsga": "Sim-in-loop NSGA-II"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="main")
    ap.add_argument("--root", default=str(ROOT / "outputs" / "study3"))
    ap.add_argument("--scaling", default=str(ROOT / "outputs" / "scaling" / "rows.json"))
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    d = Path(a.root) / a.tag
    R = json.loads((d / "results.json").read_text())
    out = Path(a.out) if a.out else d / "figures"; out.mkdir(parents=True, exist_ok=True)

    # Fig A: migrations & energy by method (diurnal)
    L = [r for r in R["lifecycle_diurnal"] if r["method"] in LAB and r["method"] not in ("simnsga",)]
    L.sort(key=lambda r: r["migrations"])
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.3), sharey=True)
    names = [LAB[r["method"]] for r in L]; y = np.arange(len(L))
    cols = [C["gp"] if r["method"].startswith("greenplace") else C["base"] for r in L]
    ax[0].barh(y, [r["migrations"] for r in L], color=cols); ax[0].set_yticks(y, names); ax[0].set_xlabel("switch migrations / 96 steps (lower = better)")
    ax[0].invert_yaxis()
    e0 = min(r["avg_energy_w"] for r in L)
    ax[1].barh(y, [(r["avg_energy_w"] / e0 - 1) * 100 for r in L], color=cols); ax[1].set_xlabel("mean lifecycle energy vs. best (%)")
    fig.tight_layout(); fig.savefig(out / "fig_methods.png", bbox_inches="tight"); plt.close(fig)

    # Fig B: front quality
    q = {(r["mode"], r["algo"]): r for r in R["quality"]}
    fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.8))
    algos = ["nsga2_2obj", "greenplace", "nsga3", "mopso"]
    for i, (m, ttl) in enumerate((("pool", "Hypervolume (higher = better)"), ("pool", "IGD (lower = better)"))):
        key = "hv" if i == 0 else "igd"
        v = [q[(m, al)][key] for al in algos]
        ax[i].bar(range(4), v, color=[C["base"], C["gp"], C["acc"], C["bad"]])
        ax[i].set_xticks(range(4), ["NSGA-II\n2-obj", "NSGA-II\n3-obj", "NSGA-III", "MOPSO"], fontsize=8); ax[i].set_title(ttl, fontsize=9)
    fig.tight_layout(); fig.savefig(out / "fig_quality.png", bbox_inches="tight"); plt.close(fig)

    # Fig C: distribution shift
    S = R["shift"]
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    x = np.arange(len(S)); w = 0.38
    ax.bar(x - w / 2, [s["gp_vs_nsga2_migs_pct"] for s in S], w, label="vs. NSGA-II (2-obj)", color=C["gp"])
    ax.bar(x + w / 2, [s["gp_vs_mip_migs_pct"] for s in S], w, label="vs. exact MIP", color=C["acc"])
    ax.axhline(0, color="k", lw=0.6); ax.set_xticks(x, [s["scenario"].replace("_", "\n") for s in S], fontsize=8)
    ax.set_ylabel("GreenPlace migrations,\nmean paired change (%)"); ax.legend(frameon=False, fontsize=8)
    ax.set_xlabel("traffic scenario (diurnal = training distribution; the other seven are unseen)", fontsize=8)
    fig.tight_layout(); fig.savefig(out / "fig_shift.png", bbox_inches="tight"); plt.close(fig)

    # Fig D: transition-cost sweep (mig_s = 0)
    T = [t for t in R["transition_sweep"] if t["mig_s"] == 0]
    fig, ax = plt.subplots(figsize=(5.2, 3.0))
    tau = [t["boot_s"] for t in T]
    ax.plot(tau, [t["greenplace_vs_alwayson_pct"] for t in T], "-o", color=C["gp"], label="GreenPlace")
    ax.plot(tau, [t["nsga2_2obj_vs_alwayson_pct"] for t in T], "-s", color=C["base"], label="NSGA-II (2-obj)")
    ax.plot(tau, [t["exact_mip_vs_alwayson_pct"] for t in T], "-^", color=C["acc"], label="Exact MIP")
    ax.axhline(0, color="k", lw=0.6)
    ax.set_xlabel("boot cost per sleep/wake event (s of full controller power)"); ax.set_ylabel("effective energy vs. always-on pool (%)")
    ax.legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig(out / "fig_transition.png", bbox_inches="tight"); plt.close(fig)

    # Fig E: selector study
    rules = R["selector"]["rules"]
    order = [r for r in ("min_energy", "proxy", "sil", "surrogate", "oracle") if r in rules]
    lab = {"min_energy": "min-energy", "proxy": "proxy (v2)", "sil": "simulation", "surrogate": "learned\nsurrogate", "oracle": "oracle*"}
    fig, ax = plt.subplots(figsize=(5.6, 2.9)); x = np.arange(len(order)); w = 0.38
    ax.bar(x - w / 2, [rules[r]["migs_diurnal"] for r in order], w, label="training distribution", color=C["gp"])
    ax.bar(x + w / 2, [rules[r]["migs_shift"] for r in order], w, label="unseen scenarios (mean of 7)", color=C["acc"])
    ax.set_xticks(x, [lab[r] for r in order], fontsize=8); ax.set_ylabel("migrations / 96 steps"); ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(out / "fig_selector.png", bbox_inches="tight"); plt.close(fig)

    # Fig F: scaling (from summary.json: gap to the MIP lower bound, wall-clock)
    sp = Path(a.scaling).with_name("summary.json")
    if sp.exists():
        S = json.loads(sp.read_text())["rows"]
        fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.0))
        ns = [r["n"] for r in S]
        for m, c, mk, lab in (("mip_set", C["acc"], "^", "Exact MIP (set, nearest-assigned)"), ("greenplace_hint", C["gp"], "o", "GreenPlace (size-hinted k ceiling)"),
                              ("nsga2_2obj_hint", C["base"], "s", "NSGA-II (size-hinted k ceiling)"), ("enplace", "#6a4c93", "d", "EnPlace-style"), ("greedy_cover", C["bad"], "x", "Greedy cover")):
            base_m = m.replace("_hint", ""); sfx = "_hint" if m.endswith("_hint") else ""
            gk = "mip_set_gap" if m == "mip_set" else base_m + sfx + "_gap"; tk = "mip_secs" if m == "mip_set" else base_m + sfx + "_secs"
            ax[0].plot(ns, [r[gk] for r in S], marker=mk, color=c, label=lab, lw=1, ls="none" if False else "-")
            ax[1].plot(ns, [r[tk] for r in S], marker=mk, color=c, lw=1)
        ax[0].set_xlabel("nodes n"); ax[0].set_ylabel("gap to MIP lower bound (%)"); ax[0].legend(frameon=False, fontsize=6.5)
        ax[1].set_xlabel("nodes n"); ax[1].set_ylabel("wall-clock (s)"); ax[1].set_yscale("log")
        fig.tight_layout(); fig.savefig(out / "fig_scaling.png", bbox_inches="tight"); plt.close(fig)
    print("figures ->", out)


if __name__ == "__main__":
    main()
