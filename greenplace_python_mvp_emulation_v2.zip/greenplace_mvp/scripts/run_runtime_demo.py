"""Demo: offline NSGA-II placement feeding the runtime elastic manager
over a synthetic diurnal traffic trace ('Phase 1 feeds Phase 2').

Usage:
    python scripts/run_runtime_demo.py [--quick]

    --quick   Fewer NSGA-II generations for a fast live demo.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from greenplace.config import DelayConfig, NSGA2Config, PowerModel, RuntimeConfig
from greenplace.metrics import export_csv, plot_runtime_trace
from greenplace.optimizer import optimize
from greenplace.runtime import RuntimeManager, generate_diurnal_trace
from greenplace.topology import generate_synthetic_topology

OUT_DIR = Path(__file__).resolve().parents[1] / "outputs"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true", help="Faster settings for a live demo.")
    args = parser.parse_args()

    graph = generate_synthetic_topology(n_nodes=20, seed=11, extra_edge_prob=0.12)
    power_model = PowerModel()
    delay_config = DelayConfig(max_switch_to_controller_delay_ms=18.0)

    # --- Phase 1: offline NSGA-II placement -> take the largest-k feasible
    # front member as the runtime candidate pool (the "maximum wake" set;
    # the runtime manager decides how much of it actually needs to stay awake).
    pop, gens = (30, 40) if args.quick else (60, 100)
    nsga2_cfg = NSGA2Config(population_size=pop, generations=gens, k_min=2, k_max=7, random_seed=7)
    front, info = optimize(
        graph, method="nsga2", power_model=power_model, delay_config=delay_config,
        nsga2_config=nsga2_cfg, k_min=2, k_max=7,
    )
    print(f"Phase 1: NSGA-II Pareto front size = {len(front)}")
    candidate_placement = max(front, key=lambda p: len(p.controllers))
    candidates = candidate_placement.controllers
    print(f"Phase 1: runtime candidate pool = {sorted(candidates)} "
          f"({len(candidates)} controllers, {candidate_placement.energy_w:.1f}W if all awake)")

    # --- Phase 2: runtime elastic management over a 2-day synthetic trace.
    runtime_cfg = RuntimeConfig(controller_capacity=6, timesteps=96)
    manager = RuntimeManager(graph, candidates, power_model, delay_config, runtime_cfg)
    trace = generate_diurnal_trace(timesteps=96, seed=3)
    results = manager.run(trace)

    always_on_energy = candidate_placement.energy_w
    avg_energy = sum(r.energy_w for r in results) / len(results)
    savings_pct = 100.0 * (always_on_energy - avg_energy) / always_on_energy
    total_migrations = sum(r.migrations for r in results)
    violations = sum(1 for r in results if not r.feasible)
    min_active = min(r.active_controllers for r in results)
    max_active = max(r.active_controllers for r in results)

    print("\nPhase 2 results over 96 timesteps (2 synthetic days):")
    print(f"  Always-on energy (baseline)      : {always_on_energy:.1f} W")
    print(f"  Average runtime-managed energy   : {avg_energy:.1f} W")
    print(f"  Average energy savings           : {savings_pct:.1f}%")
    print(f"  Active controllers (min / max)   : {min_active} / {max_active}")
    print(f"  Total switch migrations          : {total_migrations}")
    print(f"  Delay-bound violations           : {violations} (must be 0)")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    plot_runtime_trace(results, OUT_DIR / "runtime_trace.png")
    export_csv(
        [
            {"t": r.t, "load_factor": round(r.load_factor, 3), "active_controllers": r.active_controllers,
             "energy_w": round(r.energy_w, 2), "worst_case_delay_ms": round(r.worst_case_delay_ms, 3),
             "migrations": r.migrations, "feasible": r.feasible}
            for r in results
        ],
        OUT_DIR / "runtime_trace.csv",
    )
    with open(OUT_DIR / "summary_runtime.json", "w", encoding="utf-8") as f:
        json.dump({
            "always_on_energy_w": round(always_on_energy, 2),
            "avg_managed_energy_w": round(avg_energy, 2),
            "savings_pct": round(savings_pct, 2),
            "min_active_controllers": min_active,
            "max_active_controllers": max_active,
            "total_migrations": total_migrations,
            "delay_violations": violations,
            "timesteps": len(results),
        }, f, indent=2)
    print(f"\nPlot, CSV, and summary JSON written to {OUT_DIR}")

    assert violations == 0, "Delay bound was violated — this should never happen by construction."


if __name__ == "__main__":
    main()
