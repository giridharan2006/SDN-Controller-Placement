"""Summarise the sensitivity grid (capacity x delay bound) from `run_benchmark.py --grid`.

Shows WHERE GreenPlace's advantages hold and where they vanish, rather than a
single favourable operating point.   Usage: python scripts/analyze_sensitivity.py
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "outputs" / "benchmark"


def main():
    out_rows = []
    for d in sorted(BASE.glob("grid_c*_b*")):
        f = d / "rows.jsonl"
        if not f.exists():
            continue
        cfg = json.loads((d / "config.json").read_text())
        df = pd.DataFrame([json.loads(l) for l in f.read_text().splitlines()])
        t = df.groupby(["name", "method"], as_index=False)[
            ["avg_energy_w", "migrations", "pool_static_energy_w", "pool_k", "violations"]].mean()
        g = t[t.method == "greenplace"].set_index("name")
        x = t[t.method == "nsga2_2obj"].set_index("name").loc[g.index]
        e = t[t.method == "exact_mip"].set_index("name").loc[g.index]
        k = df.groupby("name")[["k_floor", "cover_size"]].first().loc[g.index]
        d_m = x["migrations"] - g["migrations"]
        try:
            p = stats.wilcoxon(d_m).pvalue if not np.allclose(d_m, 0) else 1.0
        except ValueError:
            p = 1.0
        out_rows.append({
            "capacity C=n/": cfg["cap_div"], "delay bound (x diam)": cfg["bound_frac"], "topologies": len(g),
            "elastic headroom (K-cover, mean)": float((k.k_floor - k.cover_size).mean()),
            "runtime saves vs always-on (%)": float((1 - g.avg_energy_w / g.pool_static_energy_w).mean() * 100),
            "GP migr.": float(g.migrations.mean()), "2-obj migr.": float(x.migrations.mean()),
            "GP fewer/tie/more vs 2-obj": f"{int((d_m > 1e-9).sum())}/{int((d_m.abs() <= 1e-9).sum())}/{int((d_m < -1e-9).sum())}",
            "Wilcoxon p": p,
            "energy: GP / exact": float(np.exp(np.log(g.avg_energy_w / e.avg_energy_w).mean())),
        })
    res = pd.DataFrame(out_rows)
    if res.empty:
        sys.exit("No grid results yet - run: python scripts/run_benchmark.py --grid")
    res = res.sort_values(["capacity C=n/", "delay bound (x diam)"])
    md = ["# Sensitivity grid: where do GreenPlace's advantages hold?\n",
          "Each row is one (capacity, delay-bound) setting on the same ~10 real topologies "
          "(3 seeds, NSGA-II pop 30 x 40 generations). Larger C=n/k divisor = smaller controllers = more peak-load "
          "pool needed = more elastic headroom. p-values are uncorrected (9 settings; treat as descriptive).\n",
          "| " + " | ".join(res.columns) + " |", "|" + "|".join(["---"] * len(res.columns)) + "|"]
    for _, r in res.iterrows():
        md.append("| " + " | ".join(f"{v:.3f}" if isinstance(v, float) else str(v) for v in r) + " |")
    (BASE / "SENSITIVITY_REPORT.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
