"""Sim-in-loop NSGA-II + simulation-based (SIL) pick, small networks (n<=40), seeds 0-4.
Appends rows (method='simnsga_sil') to outputs/study3/<tag>/rows_shard9.jsonl in the same schema used by the analysis."""
import argparse, json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from greenplace import baselines as B  # noqa: E402
from greenplace.benchmark import BenchConfig, derive_settings  # noqa: E402
from greenplace.config import DelayConfig, PowerModel  # noqa: E402
from greenplace.lifecycle import simulate  # noqa: E402
from greenplace.selection import select_by_simulation  # noqa: E402
from greenplace.simnsga import run_sim_nsga2  # noqa: E402
from greenplace.study3 import SCENARIOS  # noqa: E402
from greenplace.topology import load_zoo_topology  # noqa: E402
from greenplace.traffic import get_trace  # noqa: E402
from scripts_common import discover  # noqa: E402

ap = argparse.ArgumentParser(); ap.add_argument("--tag", default="main"); ap.add_argument("--max-n", type=int, default=40); ap.add_argument("--seeds", type=int, default=5)
a = ap.parse_args()
cfg = BenchConfig(cap_div=6, seeds=10, nsga_pop=40, nsga_gens=60)
out = ROOT / "outputs" / "study3" / a.tag / "rows_shard9.jsonl"
done = set(json.loads(l)["name"] for l in out.read_text().splitlines()) if out.exists() else set()
train = [get_trace("diurnal", sd, cfg.trace_len) for sd in cfg.sil_train_seeds]
for f in discover(ROOT / "data" / "real_topologies", 10, a.max_n):
    g, meta = load_zoo_topology(f)
    if meta["name"] in done: continue
    st = derive_settings(g, cfg); p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(st["bound_ms"]))
    K, C = st["k_floor"], st["capacity"]; cover = len(B.greedy_cover(p, 1)); kmax = min(meta["n"], max(K, cover) + cfg.extra_pool)
    rows = []
    for seed in range(a.seeds):
        t0 = time.perf_counter()
        fr, _ = run_sim_nsga2(p, C, train[:1], K, kmax, seed, pop=30, gens=30)
        pk, _ = select_by_simulation(p, fr, C, train, cfg.sil_energy_slack, cfg.sil_window, cfg.sil_max_candidates)
        pool = set(pk.controllers) if pk else B.greedy_cover(p, K)
        pl = p.evaluate(pool)
        row = {**meta, "bound_ms": round(st["bound_ms"], 3), "capacity": C, "k_floor": K, "cover_size": cover, "method": "simnsga_sil", "seed": seed,
               "static_k": 0, "static_energy_w": pl.energy_w, "static_feasible": pl.feasible, "static_valid": False, "pool_k": len(pool),
               "pool_static_energy_w": pl.energy_w, "pool_feasible": pl.feasible, "pool_burden": pl.migration_burden, "mip_status": "",
               "t_pool_s": time.perf_counter() - t0, "t_static_s": float("nan")}
        for sc in SCENARIOS:
            for k, v in simulate(p, pool, C, get_trace(sc, seed, cfg.trace_len)).items(): row[f"{sc}__{k}"] = v
        rows.append(row)
    with open(out, "a") as fh:
        for r in rows: fh.write(json.dumps(r, default=float) + "\n")
    print(meta["name"], meta["n"], flush=True)
