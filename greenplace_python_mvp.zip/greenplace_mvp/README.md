# GreenPlace — Python MVP

> **Read first (v3):** the numbers in Section 3 (56.1% savings, −78.2% migrations) come from the *synthetic-topology demo* and do **not** generalise. The evidence to trust is the **v3 study** (Section 9 / `BENCHMARKING.md`): 46 Topology Zoo networks, 10 seeds, 8 traffic scenarios (two real traces), 19 methods/variants. GreenPlace is *not* best at static energy, is tied on lifecycle energy, and has ~23% fewer runtime migrations than NSGA-II energy+delay (Holm p < 0.001; vs the exact-MIP set median −10%, uncertain size). The exact MIP out-scales every metaheuristic up to 709 nodes, so the project's value is lifecycle behaviour, not scalability. **Correction:** earlier docs called the MIP set the "exact optimum"; it optimises free assignment while all methods are scored with nearest-controller assignment, so its objective is only a *lower bound* (Section 9). All v3 numbers: `outputs/study3/main/RESULTS_SUMMARY.md`. Step-by-step instructions: `GreenPlace_Build_Run_Demo_Guide.pdf`.

Energy-Efficient SDN Controller Placement Under Delay Constraints.

A working, tested Python implementation of the two-phase framework from the
project's literature review: an offline multi-objective placement optimizer
(exact ILP baseline + self-contained NSGA-II) feeding a runtime elastic
controller-sleep/switch-migration manager — now with the project's sharpened
novelty contribution (a migration-aware Pareto objective) implemented and
empirically validated, not just described.

---

## Visualise the tested networks, and adding Janos-US (v3.2)

```bash
python scripts/visualize_topologies.py      # -> outputs/topologies/gallery.html (+ contact_sheet_*.png)
```
Maps of all 46 tested networks with size, derived test settings and per-network outcome (GreenPlace vs NSGA-II migrations; losses shown in red).

**Janos-US is not in the study.** It is an SNDlib network (not in the Topology Zoo) and SNDlib could not be reached from the build environment. The loader is ready: download `janos-us.txt` (and `janos-us-ca.txt`) from sndlib.put.poznan.pl (native format), put them in `data/real_topologies/`, then
```bash
python scripts/run_study3.py --tag janos --names janos-us janos-us-ca --seeds 10
python scripts/visualize_topologies.py
```
(`.txt` SNDlib files are parsed by `greenplace.topology.load_sndlib_native`; delay = great-circle distance at 2/3 c, as for Zoo files.) To fold them into the headline tables, rerun `analyze_study3.py` after merging rows -- until then they are listed as "added, not yet run".

## Demo in one command (v3.1)

```bash
python scripts/demo_dashboard.py            # ~40 s: live benchmark on Abilene + shipped 46-network study
python scripts/demo_dashboard.py --topology Sprint --seeds 5
python scripts/demo_dashboard.py --no-live  # instant re-render from shipped results
```
Animated view of the program running (controllers sleeping/waking, switches migrating, live power and migration counters, both pools side by side): `python scripts/demo_animation.py [--topology Karen --seed 1]` -> `outputs/demo/animation.html`. It is one network / one seed, an illustration (on Karen GreenPlace needs *more* migrations than NSGA-II; on Hibernia fewer).

Opens-ready file: `outputs/demo/dashboard.html` (charts + a scorecard that lists, per metric, the best method and where GreenPlace ranks -- including metrics where it is not best). A condensed two-column conference paper generator is in `paper_src/conf/`.

## 1. What's implemented

| Module | Framework phase | What it does |
|---|---|---|
| `greenplace/topology.py` | — | Load GML topologies (Internet Topology Zoo format), a plain synthetic generator, and a geographic-proxy **backbone-like** generator sized/shaped closer to Internet2/GEANT |
| `greenplace/delay.py` | — | Shortest-path propagation delay engine (cached all-pairs Dijkstra) + `coverage_priority`, the shared wake/sleep ranking used by both the offline objective and the runtime manager |
| `greenplace/power.py` | — | Control-plane energy model (controller + control-link-hop power) |
| `greenplace/placement.py` | — | `Placement` data structure + feasibility/energy/migration-burden evaluation |
| `greenplace/ilp_solver.py` | Phase 1a | Exact solver — full MIP via PuLP/CBC if installed, exhaustive-search fallback otherwise |
| `greenplace/nsga2.py` | Phase 1b | Self-contained NSGA-II (Deb et al., 2002): constrained-domination, crowding distance, elitist selection, **3rd migration-burden objective (optional, on by default)** |
| `greenplace/optimizer.py` | Phase 1 | Unified entry point selecting `"exact"` or `"nsga2"` |
| `greenplace/runtime.py` | Phase 2 | Traffic-driven controller sleep/wake manager with delay-bounded, capacity-aware switch migration, **EMA traffic smoothing + sleep dwell-time (anti-flap)** |
| `greenplace/metrics.py` | — | Pareto hypervolume, CSV/JSON export, plotting (including migration-burden color-coding) |

All of it is tested — 84/84 checks pass (v3 adds NSGA-III, MOPSO, EnPlace-style, 3-D hypervolume/IGD, traffic scenarios, burden hook); see [Section 4](#4-running-the-tests).

---

## 2. Setup

### Opening in PyCharm

This project ships as a ready-to-open PyCharm/IntelliJ project (`.idea/` +
`greenplace_mvp.iml`). To open it:

1. **File → Open...** and select the `greenplace_mvp` folder (the one
   containing `greenplace_mvp.iml`, not a parent folder).
2. PyCharm will flag the interpreter as unconfigured (it can't know your
   machine's Python path in advance) — go to
   **Settings/Preferences → Project: greenplace_mvp → Python Interpreter →
   Add Interpreter → Add Local Interpreter**, choose **Virtualenv → New**,
   and let it create `.venv` inside the project. PyCharm will then offer to
   install `requirements.txt` automatically — accept that.
3. `tests/` is already marked as a **Test Sources Root** and pytest is set
   as the default test runner, so right-clicking `tests/` → **Run 'pytest in
   tests'** works immediately.
4. Seven ready-made **Run Configurations** are included in the run-configuration
   dropdown (top right toolbar): **"0. Full Demo"** (the whole pipeline, start
   here), **"0b. Full Demo (Quick Mode)"**, the four individual stages (1-4),
   and **All Tests (pytest)** — just select one and click ▶.

If you'd rather set it up from a terminal instead (also works — PyCharm will
pick up an existing `.venv` automatically next time you open the project):

### Command-line setup (any OS)

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

`pulp` is optional — if it's not installed, `ilp_solver.py` automatically
falls back to an exhaustive search that is still *exact* (not a heuristic)
for the small topologies (~roughly ≤12-14 nodes) it's used on.

---

## 3. Running the demos

**Fastest path — one command runs everything:**

```bash
python demo.py            # full pipeline, ~1 minute, the numbers cited in this README
python demo.py --quick    # same pipeline, faster settings, ~10-30s — good for a live demo
```

This runs all four stages in order and ends with one consolidated summary table,
read back from the JSON files each stage just wrote (not hardcoded), so what you
see on screen always matches what's in `outputs/`.

**Or run each stage individually** (each also accepts `--quick` except the first):

```bash
# 1. Generate topology fixtures (synthetic ring + backbone-proxy) into data/topologies/
python scripts/generate_topologies.py

# 2. Core validation experiment: NSGA-II vs. the exact solver
python scripts/run_ilp_vs_nsga2.py

# 3. Phase 1 -> Phase 2 demo: offline placement feeding the runtime manager
#    over a synthetic 2-day diurnal traffic trace
python scripts/run_runtime_demo.py

# 4. Does the migration-aware objective actually help? Multi-seed comparison.
python scripts/run_migration_aware_demo.py
```

All four scripts write plots, CSVs, and JSON summaries to `outputs/`. Sample
results from a real run (checked in):

- **`outputs/pareto_small_10node.png`** — NSGA-II Pareto front vs. the exact
  optimum (star) on a 10-node topology: 0.0% energy gap.
- **`outputs/runtime_trace.png`** — 3-panel diurnal-trace / active-controller
  / energy view over 96 timesteps. **56.1% average energy savings** vs. an
  always-on baseline, **zero delay-bound violations**, and — after the
  hysteresis fix (Section 5) — a clean staircase pattern instead of rapid

  flapping: **54 total migrations**, down from 249 before the fix.
- **`outputs/pareto_migration_aware.png`** — Pareto front color-coded by
  migration burden, showing the genuine 3-way trade-off between energy,
  delay, and migration cost.
- **`outputs/migration_aware_comparison.json`** — the 5-seed statistical
  comparison behind the headline number below.

### Does the migration-aware objective actually work? (yes — but the first test of it was misleading)

The literature review's sharpened novelty claim was to add *expected future
migration cost* as a third NSGA-II objective, using the same coverage-priority
policy the runtime manager uses to decide which controller to sleep first
(rather than a generic proxy unrelated to the actual runtime policy).

**First attempt, honestly reported:** a single-seed anecdotal test initially
showed the migration-aware pick doing *worse* (more runtime migrations) than
the plain energy/delay optimizer. Investigating showed two real problems,
not "the idea doesn't work":
1. The original migration-burden metric (max cluster size in the fully-awake
   placement) had no real connection to what the runtime manager actually
   sleeps first — fixed by rewriting it to use the same `coverage_priority`
   ranking the runtime manager itself uses.
2. A single run's migration *count* is a small integer and dominated by
   noise — one lucky/unlucky seed says very little.

**After fixing the metric and testing across 5 independent seeds** (different
topology + traffic trace per seed):

| | 2-objective (energy, delay only) | 3-objective (+ migration burden) |
|---|---|---|
| Avg. runtime migrations | 11.0 | **2.4 (-78.2%)** |
| Avg. runtime energy | 1080.9 W | **944.8 W (also lower)** |
| Seeds where 3-objective is <= 2-objective | -- | 4/5 |
| Delay-bound violations (either) | 0 | 0 |

The migration-aware objective genuinely reduces runtime churn, and — a
pleasant, unplanned side effect — the larger, more diverse 3-objective
Pareto front also surfaced lower-energy feasible points the 2-objective
search's sparser front had discarded. This is now backed by a real,
reproducible multi-seed experiment, not a single anecdote — worth
re-running with more seeds and on real Internet2/GEANT data before it goes
in a paper, but it's no longer just a hypothesis.

---

## 4. Running the tests

```bash
pytest
```

64 tests across 9 files. The ones that matter most for this
project's actual research claims:

- **`tests/test_ilp_solver.py`** — cross-checks the exact solver against an
  independently-written brute-force reference inside the test itself.
- **`tests/test_nsga2.py`** — non-domination checked in BOTH the classic 2D
  (energy, delay) space and the full 3D space used when the migration
  objective is active (an earlier version of this test only checked 2D and
  produced a false failure once the 3rd objective was added — worth reading
  the comment in that file if you're extending the objective set further).
- **`tests/test_runtime.py`** — delay bound is *never* violated, including
  under the hysteresis/smoothing changes, and dwell-time genuinely reduces
  controller-count transitions on a noisy trace.
- **`tests/test_placement.py`** — the migration-burden metric matches its
  policy-linked definition, not an arbitrary number.

---

## 5. What changed since the first MVP cut (this round of work)

0. **Literature base expanded from 28 to 43 sources (final master list).** The project's literature review, gap analysis, and problem statement were rewritten against a merged 43-source review (see the "Energy-Efficient SDN Controller Placement Literature Review" and companion "Annotated Bibliography" documents). This did **not** trigger a structural rewrite of the algorithms below — the new sources reinforce and better-cite specific design choices already made (Killi & Rao 2017's capacity-aware reassignment for `runtime.py`; Kazemiesfeh et al. 2025's multi-threshold migration policy for the EMA/dwell-time hysteresis; Ul Huque et al. 2017's controller-count-minimization framing for the NSGA-II `k_min`/`k_max` search range; Jalili et al. 2018 as the confirmed full citation for the NSGA-II ancestor paper) rather than contradicting them. Docstrings in `power.py`, `runtime.py`, and `nsga2.py` were updated accordingly; no algorithmic behavior changed.

1. **Migration-aware Pareto objective — implemented and validated.** See the
   experiment writeup above. This was the project's stated "sharpened
   contribution" and is no longer just documented intent.
2. **Runtime controller flapping — fixed.** Root cause was reacting to raw
   per-timestep traffic noise. Fix: EMA smoothing (`RuntimeConfig.load_ema_alpha`)
   on the traffic signal plus a minimum dwell time between *sleep* decisions
   (`RuntimeConfig.min_dwell_steps`) — waking is never gated, only sleeping,
   so the delay-bound safety guarantee is never delayed. Migrations dropped
   from 249 to 54 on the same demo scenario.
3. **Realistic backbone-scale topology generator.** `generate_backbone_like_topology()`
   places nodes geographically, connects them via a minimum spanning tree
   (guaranteed connectivity, backbone-like sparsity) plus nearest-neighbor
   edges, and derives delay from geographic distance — producing 34/40-node,
   ~2.6-avg-degree topologies structurally closer to Internet2/GEANT than the
   original ring-plus-chords generator. Synthetic only — real Topology Zoo networks are
   now bundled and benchmarked (see Section 8).
4. **A real bug found and fixed along the way:** the capacity-constrained
   greedy assignment could fail to find a feasible solution even when one
   existed (greedy bipartite matching isn't globally optimal). Added a
   guaranteed-feasible fallback (uncapacitated nearest-assignment, since the
   delay bound — not capacity — is this project's true hard invariant)
   instead of letting it crash.

---

## 6. Project layout

```
greenplace_mvp/
├── demo.py                # <- run this first: the entire pipeline in one command
├── .idea/                # PyCharm/IntelliJ project config (see Section 2)
│   └── runConfigurations/  # 12 ready-made run configs: demos, benchmark, analysis, place-on-topology, pytest
├── greenplace_mvp.iml    # PyCharm module file (project root = module root)
├── greenplace/          # the actual package (see table above)
├── scripts/
│   ├── run_all_demos.py     # orchestrates the four stages below + prints the summary
│   ├── generate_topologies.py
│   ├── run_ilp_vs_nsga2.py
│   ├── run_runtime_demo.py
│   ├── run_migration_aware_demo.py
│   ├── fetch_real_topologies.py / run_benchmark.py / analyze_benchmark.py / analyze_sensitivity.py
│   └── place_on_topology.py   # run GreenPlace on YOUR .gml network
├── tests/                # pytest suite, one file per module (marked as Test Sources Root)
├── data/
│   ├── topologies/        # generated GML fixtures (synthetic + backbone-proxy)
│   ├── real_topologies/   # 67 Internet Topology Zoo GML files
│   └── traffic_traces/     # (reserved for saved real/synthetic traces)
├── outputs/                 # plots/CSV/JSON written by the demo scripts
├── requirements.txt
├── pytest.ini
├── .gitignore
└── README.md
```

---

## 7. Honest gaps / things to tighten next

1. **Real topologies — now done, with a sobering result.** The pipeline was run on 46 real Topology Zoo networks
   (Section 8, `BENCHMARKING.md`). Remaining gaps: networks above 60 nodes were not benchmarked, 9 of 46 networks lack
   coordinates (hop-count delay), and traffic is still a synthetic diurnal curve rather than measured traces.
2. **MOPSO backend.** (v3: a plain binary MOPSO now exists in `greenplace/moea.py` and is weak; a `pymoo` backend is still a possible extension.) Originally only NSGA-II was implemented. `optimizer.py` is
   structured so a MOPSO (or `pymoo`-backed) solver can be added as a new
   `method=` branch without touching anything else.
3. **The -78.2% migration figure was superseded.** On real topologies the migration-aware objective gives about -26% migrations
   versus the NSGA-II energy+delay baseline (significant, Holm p = 0.007), shrinking to ~7-46% across the sensitivity grid. The
   synthetic -78.2% (and 56.1% runtime savings) should not be cited as general performance. The offline migration-burden proxy
   also correlates only weakly (Spearman ~0.26) with realised migrations. A simulation-in-the-loop pick was tried (BENCHMARKING.md
   Section 9): it did not cut migrations further but lowers energy ~1.6% at equal migrations.
4. **Capacity-aware assignment is greedy, not optimal.** `assign_with_capacity`
   in `runtime.py` uses a simple greedy nearest-with-spare-capacity heuristic,
   with a guaranteed-feasible (uncapacitated) fallback when it fails. Fine
   for the MVP; a min-cost-flow or small LP formulation would give a
   tighter, provably-optimal assignment if capacity becomes a bottleneck.
5. **Formal delay-violation-probability bound** and **joint controller+link
   sleep co-scheduling** remain the two stretch-goal directions noted in the
   literature review's novelty-sharpening section — not started.

None of these block using the MVP today — they're the natural remaining
"Weeks 5-9" work from the project timeline.


---

## 8. Benchmarking against existing approaches on real-world topologies

GreenPlace can be compared against re-implementations of nine existing approach families (k-center/k-median, greedy cover, betweenness,
GreCo-style consolidation, single-objective GA, exact MIP, NSGA-II without migration awareness, random) on real networks from the
**Internet Topology Zoo** (67 are bundled in `data/real_topologies/`; `scripts/fetch_real_topologies.py --all` pulls the full 250+).

```bash
python scripts/run_benchmark.py --quick && python scripts/analyze_benchmark.py --tag quick
```

**Headline, stated plainly (46 real networks):** GreenPlace is *not* better at static energy (6.4% above the exact optimum) and is *tied* on
lifecycle energy with the best energy-focused methods; its advantage is **fewer runtime switch migrations** (-26% vs NSGA-II energy+delay, significant)
and it is the Pareto-optimal choice on the most networks (25/46 among the original 11 methods; 19/46 among 13). The synthetic-demo figures above (56.1% / 78.2%) do **not** generalise to real topologies.
A pre-registered improvement (simulation-in-the-loop selection, `greenplace.selection.select_by_simulation`) did **not** reduce migrations further, but gives the same migrations at ~1.6% lower lifecycle energy and is Pareto-optimal on 31/46 networks. Try it on your own network: `python scripts/place_on_topology.py my_network.gml`.
See **`BENCHMARKING.md`** for the protocol, full results, the control experiment and the limitations, and `outputs/benchmark/` for the data, figures and reports.


---

## 9. Study v3 — what was added and what it found (reproducible)

New modules: `greenplace/moea.py` (NSGA-III, binary MOPSO, EnPlace-style heuristic), `greenplace/traffic.py` (6 synthetic scenarios + real GÉANT/Abilene traces from `data/traffic/`), `greenplace/simnsga.py` (simulation-in-the-search NSGA-II), `greenplace/study3.py` (harness), 3-D hypervolume/IGD in `metrics.py`. Scripts: `run_study3.py`, `run_simnsga_sil.py`, `compute_mip_lb.py`, `run_scaling.py`, `summarize_scaling.py`, `analyze_study3.py`, `make_figures3.py`, `make_results_summary.py`. Reproducibility: `Dockerfile`, `requirements.lock`, `Makefile`, `.github/workflows/ci.yml`, `LICENSE` (MIT; edit the copyright line), `CITATION.cff` and `.zenodo.json` (placeholders for authors/URL), and an **untested** Mininet/Ryu harness in `emulation/`.

```bash
make test                      # 85 tests
make quick                     # ~3 min smoke study + analysis
python scripts/run_study3.py --tag main --seeds 10 --shard 0 --nshards 2 &   # full study (hours); run shard 1 too
python scripts/run_simnsga_sil.py ; python scripts/compute_mip_lb.py ; python scripts/run_scaling.py --mip-limit 60
python scripts/run_scaling.py --mip-uncapped-only ; python scripts/summarize_scaling.py
python scripts/analyze_study3.py --tag main ; python scripts/make_figures3.py --tag main ; python scripts/make_results_summary.py
```

**Findings, stated plainly** (full tables in `outputs/study3/main/RESULTS_SUMMARY.md`): see the paper draft v3. Negative results: the learned surrogate selector is no better than the proxy; the simulation pick lowers energy but not migrations; simulated migrations *inside* the search trade away elasticity unless combined with the energy-constrained simulation pick (small networks only, 18x run-time); elastic savings shrink as the link-power term grows or sleeping controllers draw idle power; fewer migrations do not change energy even at high transition costs. **No emulation was run.**

**Correction to earlier results.** The MIP optimises over free switch→controller assignment; methods are scored with nearest-controller assignment. Static gaps are therefore reported against the MIP objective as a lower bound (`outputs/study3/main/mip_lb.json`); on 10 of 46 networks a heuristic scored up to 3.3% *better* than the MIP's own set. Lifecycle results are unaffected. The v2 figures (6.4% gap, "0.8% GA") used the MIP set as the reference and should be read as such.
