#!/usr/bin/env python3
"""Animated, self-contained HTML that shows the program RUNNING on one real network.

    python scripts/demo_animation.py                         # Hibernia, diurnal traffic  -> outputs/demo/animation.html
    python scripts/demo_animation.py --topology Geant2012 --scenario geant --seed 1

What it shows (all computed live by this repository's code, nothing is canned):
  Phase 1  the NSGA-II Pareto front (energy vs delay, colour = migration burden) and the two picks
           (left: energy+delay NSGA-II, right: GreenPlace migration-aware pick)
  Phase 2  the runtime manager stepping through a day of traffic for BOTH controller pools on the same map:
           controllers sleeping/waking, switches changing controller (flashes), live power and migration counters.
It is a single network and a single seed -- an illustration, not evidence. The page says so and quotes the
46-network study for the real comparison.
"""
import argparse, json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402
import networkx as nx  # noqa: E402
from greenplace import baselines as B  # noqa: E402
from greenplace.benchmark import BenchConfig, derive_settings  # noqa: E402
from greenplace.config import DelayConfig, PowerModel, RuntimeConfig  # noqa: E402
from greenplace.runtime import RuntimeManager  # noqa: E402
from greenplace.selection import select_min_energy, select_migration_aware  # noqa: E402
from greenplace.topology import load_zoo_topology  # noqa: E402
from greenplace.traffic import get_trace  # noqa: E402


def run_pool(p, pool, C, trace):
    rt = RuntimeConfig(controller_capacity=C, timesteps=len(trace), load_ema_alpha=0.3, min_dwell_steps=2)
    mgr = RuntimeManager(p.graph, pool, p.power, p.delay_config, rt, delay_engine=p.engine)
    steps, prev = [], None
    for t, load in enumerate(trace):
        r = mgr.step(t, float(load))
        asg = {int(k): int(v) for k, v in mgr.prev_assignment.items()}
        moved = [] if prev is None else [u for u, c in asg.items() if prev.get(u) != c]
        prev = asg
        steps.append({"active": sorted(int(c) for c in mgr.active), "asg": [asg[u] for u in sorted(asg)], "moved": moved,
                      "energy": round(r.energy_w, 1), "migs": int(r.migrations), "delay": round(r.worst_case_delay_ms, 2), "ok": bool(r.feasible)})
    return steps


def layout(g):
    ok = all("Latitude" in g.nodes[u] and "Longitude" in g.nodes[u] for u in g)
    if ok:
        pos = {u: (g.nodes[u]["Longitude"], -g.nodes[u]["Latitude"]) for u in g}
    else:
        pos = nx.spring_layout(g, seed=1)
    xs = np.array([v[0] for v in pos.values()]); ys = np.array([v[1] for v in pos.values()])
    sx = (xs.max() - xs.min()) or 1; sy = (ys.max() - ys.min()) or 1
    return [[round(float((pos[u][0] - xs.min()) / sx), 4), round(float((pos[u][1] - ys.min()) / sy), 4)] for u in sorted(g.nodes)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--topology", default="Hibernia"); ap.add_argument("--scenario", default="diurnal")
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--out", default=str(ROOT / "outputs" / "demo"))
    a = ap.parse_args()
    f = ROOT / "data" / "real_topologies" / f"{a.topology}.gml"
    if not f.exists(): sys.exit(f"unknown topology {a.topology}")
    g, meta = load_zoo_topology(f)
    cfg = BenchConfig(seeds=1)
    st = derive_settings(g, cfg)
    p = B.Problem(g, st["engine"], PowerModel(), DelayConfig(st["bound_ms"]))
    C, K, n = st["capacity"], st["k_floor"], meta["n"]
    cover = len(B.greedy_cover(p, 1)); k_max = min(n, max(K, cover) + cfg.extra_pool)
    t0 = time.time()
    fr2 = B.nsga2_front(p, K, k_max, a.seed, False, cfg.nsga_pop, cfg.nsga_gens)
    fr3 = B.nsga2_front(p, K, k_max, a.seed, True, cfg.nsga_pop, cfg.nsga_gens)
    pick2, pick3 = select_min_energy(fr2), select_migration_aware(fr3, cfg.energy_slack)
    if pick2 is None or pick3 is None: sys.exit("no feasible placement found")
    trace = get_trace(a.scenario, a.seed, cfg.trace_len)
    pools = {"A": set(pick2.controllers), "B": set(pick3.controllers)}
    runs = {k: run_pool(p, v, C, trace) for k, v in pools.items()}
    print(f"phase 1+2 in {time.time()-t0:.0f}s; migrations NSGA-II {sum(s['migs'] for s in runs['A'])} vs GreenPlace {sum(s['migs'] for s in runs['B'])}")
    fpts = lambda fr, tag: [{"e": round(m.energy_w, 1), "d": round(m.worst_case_delay_ms, 2), "b": round(m.migration_burden, 2), "set": sorted(int(c) for c in m.controllers), "src": tag} for m in fr if m.feasible]
    R = json.loads((ROOT / "outputs" / "study3" / "main" / "results.json").read_text())
    T = next(t for t in R["tests_gp_vs_baselines_migrations"] if t["b"] == "nsga2_2obj")
    data = {"name": a.topology, "n": n, "m": meta["m"], "bound": round(st["bound_ms"], 2), "cap": C, "K": K, "scenario": a.scenario, "seed": a.seed,
            "pos": layout(g), "edges": [[int(u), int(v)] for u, v in g.edges], "labels": [str(g.nodes[u].get("name", u)) for u in sorted(g.nodes)],
            "trace": [round(float(x), 3) for x in trace], "A": runs["A"], "B": runs["B"], "poolA": sorted(int(c) for c in pools["A"]), "poolB": sorted(int(c) for c in pools["B"]),
            "front2": fpts(fr2, "A"), "front3": fpts(fr3, "B"), "pick2": sorted(int(c) for c in pick2.controllers), "pick3": sorted(int(c) for c in pick3.controllers),
            "study": {"pct": round(T["pct_mean"], 1), "lo": round(T["pct_ci"][0], 1), "hi": round(T["pct_ci"][1], 1), "n": R["n_topologies"], "seeds": R["n_seeds"], "wins": T["wins"], "losses": T["losses"]}}
    html = (Path(__file__).parent / "animation_template.html").read_text().replace("__DATA__", json.dumps(data))
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    (out / "animation.html").write_text(html); print("wrote", out / "animation.html")


if __name__ == "__main__":
    main()
