#!/usr/bin/env python3
"""Visualise every network the algorithms are tested on.

    python scripts/visualize_topologies.py          # -> outputs/topologies/gallery.html + contact_sheet_*.png

For each network of the study (read from outputs/study3/<tag>/rows_*.jsonl) it draws the map (real coordinates
where the Topology Zoo / SNDlib file has them, a spring layout otherwise), its size and delay model, the derived
test settings (delay bound, capacity, controller floor) and the measured outcome: migrations of GreenPlace
relative to the energy+delay NSGA-II on the daily-cycle scenario (green = fewer, red = more). Losses are shown
as prominently as wins.  Any file in data/real_topologies/ inside the node range that was *not* part of the study
run (e.g. a newly added janos-us.txt) is listed separately as "added, not yet run".
"""
import argparse, glob, html, json, math, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np, pandas as pd, networkx as nx  # noqa: E402
import matplotlib; matplotlib.use("Agg")  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from greenplace.topology import load_zoo_topology  # noqa: E402
from greenplace.benchmark import BenchConfig, derive_settings  # noqa: E402

GREEN, RED, GREY = "#1b6e5a", "#c1121f", "#8d99ae"


def layout(g):
    geo = all(g.nodes[u].get("Latitude") is not None and g.nodes[u].get("Longitude") is not None for u in g)
    if geo:
        lat0 = np.mean([g.nodes[u]["Latitude"] for u in g]); k = math.cos(math.radians(lat0))
        pos = {u: (g.nodes[u]["Longitude"] * k, g.nodes[u]["Latitude"]) for u in g}
    else:
        pos = {u: tuple(p) for u, p in nx.spring_layout(g, seed=3, iterations=200).items()}
    xs = np.array([p[0] for p in pos.values()]); ys = np.array([p[1] for p in pos.values()])
    w = (xs.max() - xs.min()) or 1; h = (ys.max() - ys.min()) or 1; s = max(w, h)
    return {u: ((pos[u][0] - xs.min()) / s, 1 - (pos[u][1] - ys.min()) / s) for u in g}, w / s, h / s, geo


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--tag", default="main"); ap.add_argument("--out", default=str(ROOT / "outputs" / "topologies"))
    a = ap.parse_args()
    d = ROOT / "outputs" / "study3" / a.tag
    rows = pd.concat([pd.read_json(f, lines=True) for f in sorted(glob.glob(str(d / "rows_shard*.jsonl")))], ignore_index=True)
    mig = rows[rows.method.isin(["greenplace", "nsga2_2obj"])].groupby(["name", "method"])["diurnal__migrations"].mean().unstack()
    energy = rows[rows.method.isin(["greenplace", "nsga2_2obj"])].groupby(["name", "method"])["diurnal__avg_energy_w"].mean().unstack()
    tested = sorted(rows.name.unique())
    files = {f.stem: f for f in list((ROOT / "data" / "real_topologies").glob("*.gml")) + list((ROOT / "data" / "real_topologies").glob("*.txt"))}
    cfg = BenchConfig()
    recs = []
    for name in tested:
        g, meta = load_zoo_topology(files[name]); st = derive_settings(g, cfg); pos, w, h, geo = layout(g)
        gp, n2 = float(mig.loc[name, "greenplace"]), float(mig.loc[name, "nsga2_2obj"])
        recs.append({"name": name, "n": meta["n"], "m": meta["m"], "geo": geo, "bound": round(st["bound_ms"], 2), "cap": st["capacity"], "K": st["k_floor"],
                     "gp": round(gp, 1), "n2": round(n2, 1), "pct": None if n2 == 0 else round((gp - n2) / n2 * 100, 0),
                     "de": round((float(energy.loc[name, "greenplace"]) / float(energy.loc[name, "nsga2_2obj"]) - 1) * 100, 1),
                     "pos": [[round(pos[u][0], 3), round(pos[u][1], 3)] for u in sorted(g.nodes)], "w": round(w, 3), "h": round(h, 3),
                     "edges": [[int(u), int(v)] for u, v in g.edges], "deg": [int(g.degree(u)) for u in sorted(g.nodes)]})
    new = []
    for stem, f in sorted(files.items()):
        if stem in tested: continue
        try:
            _, meta = load_zoo_topology(f)
        except Exception:
            continue
        if 10 <= meta["n"] <= 60: new.append({"name": stem, "n": meta["n"], "m": meta["m"]})
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    # ---- contact sheets (for slides / appendix)
    recs_sorted = sorted(recs, key=lambda r: (r["n"], r["name"]))
    per = 24; sheets = [recs_sorted[i:i + per] for i in range(0, len(recs_sorted), per)]
    for si, sh in enumerate(sheets, 1):
        cols = 6; rws = math.ceil(len(sh) / cols)
        fig, axs = plt.subplots(rws, cols, figsize=(cols * 2.3, rws * 2.5)); axs = np.atleast_2d(axs)
        for ax in axs.ravel(): ax.axis("off")
        for ax, r in zip(axs.ravel(), sh):
            col = GREY if r["pct"] is None or abs(r["pct"]) < 1 else (GREEN if r["pct"] < 0 else RED)
            for u, v in r["edges"]: ax.plot([r["pos"][u][0], r["pos"][v][0]], [r["pos"][u][1], r["pos"][v][1]], color="#b9c0c9", lw=.8, zorder=1)
            ax.scatter([p[0] for p in r["pos"]], [p[1] for p in r["pos"]], s=[6 + 3 * x for x in r["deg"]], color=col, zorder=2, edgecolor="white", lw=.4)
            ax.set_xlim(-.05, 1.05); ax.set_ylim(1.05, -.05); ax.set_aspect("equal")
            tag = "tie" if r["pct"] is None or abs(r["pct"]) < 1 else f"{r['pct']:+.0f}% migr."
            ax.set_title(f"{r['name']}\n{r['n']} nodes, {r['m']} links  |  {tag}", fontsize=7.2, color=col if col != GREY else "#333")
        fig.suptitle(f"Networks used in the study ({len(recs)} total), sheet {si}/{len(sheets)}: GreenPlace migrations vs NSGA-II (green = fewer, red = more)", fontsize=9)
        fig.tight_layout(rect=(0, 0, 1, .97)); fig.savefig(out / f"contact_sheet_{si}.png", dpi=170); plt.close(fig)

    # ---- interactive gallery
    page = (Path(__file__).parent / "gallery_template.html").read_text().replace("__DATA__", json.dumps({"nets": recs, "new": new, "nseeds": int(rows.seed.nunique())}))
    (out / "gallery.html").write_text(page)
    json.dump([{k: v for k, v in r.items() if k not in ("pos", "edges", "deg")} for r in recs], open(out / "topologies.json", "w"), indent=1)
    print(f"{len(recs)} tested networks; {len(new)} added-but-not-run; wrote {out}/gallery.html and {len(sheets)} contact sheets")


if __name__ == "__main__":
    main()
