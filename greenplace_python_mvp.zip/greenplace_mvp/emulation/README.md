# Emulation harness (Mininet + Ryu)  —  **UNTESTED**

> **Status: written but NOT executed.** The environment that produced this repository had no Mininet/Open vSwitch/Ryu
> (they need root, kernel namespaces and OVS). Treat the code as a starting point; expect to debug it. No result in the
> paper depends on it. The paper lists emulation as *future work*.

## What it is meant to validate
That the *model* assumptions behind the simulator hold in an SDN stack:
1. a placement from `scripts/place_on_topology.py` can be deployed as N Ryu controller processes;
2. switches can be re-assigned between controllers (`ovs-vsctl set-controller`) while traffic flows, and we can count
   the OpenFlow `ROLE_REQUEST`/re-association events (the "migration" in the simulator);
3. measured switch-to-controller latency stays within the delay bound.

## Files
* `mininet_topo.py` – builds a Mininet topology from a Zoo GML file with link delays from the delay model; starts
  one remote controller per entry of a placement JSON; replays a load trace by changing the iperf offered load and
  executes the sleep/wake + migration schedule produced by `RuntimeManager` (exported with `--export-schedule`).
* `ryu_counter.py` – minimal Ryu app that counts packet-in events and switch connect/disconnect per controller.

## Run (on a Linux VM with root)
```
sudo apt-get install mininet openvswitch-switch && pip install ryu
python scripts/place_on_topology.py --help      # produce placement.json
sudo python emulation/mininet_topo.py --gml data/real_topologies/Abilene.gml --placement placement.json
```
Known limitations: link delays use `TCLink` (netem) and are only accurate to ~1 ms; large Zoo topologies (>40 switches)
exceed what a laptop VM can emulate.
